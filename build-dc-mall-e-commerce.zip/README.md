# DC MALL — Your Trusted Online Shopping Mall

A production-ready, fullstack e-commerce platform for Ghana built with **Next.js (App Router) + TypeScript + Tailwind CSS + PostgreSQL (Drizzle ORM)**. All prices are in **Ghana Cedis (₵ / GHS)**.

## Features

**Customer:** registration/login (email or phone), password reset, profile & saved delivery address, product search with filters (price, category, rating, stock, sorting), product detail pages with SEO + structured data, verified-purchase reviews, cart with live stock validation, 3-step checkout (info → review → payment), Mobile Money payment with reference submission, order confirmation with unique order number (`DCM-YYYYMMDD-XXXX`), order history, public order tracking with visual timeline, in-app + email notifications, PWA (installable, offline fallback).

**Admin:** separate secured dashboard (role-based) with sales/orders/customer/inventory statistics, charts (daily sales, orders by status, best sellers), alerts (new orders, pending payments, low/out-of-stock, new customers), full product CRUD (images, discount, specs, SEO, status), category CRUD, order management (view all orders, confirm/reject payments, update status → customer tracking updates automatically, tracking number, delivery notes, cancel/refund with automatic stock restore), customer management (disable/reactivate), inventory monitoring with low-stock alerts and quick stock updates, review moderation, store settings (contact info, payment account, delivery fees per region), and a complete audit log.

**Payments:** manual MoMo to the official DC MALL account **+233 54 531 5419** with an admin verification workflow (orders are *never* auto-marked paid), plus optional automatic verification through **Paystack** (MoMo + cards, GHS) via callback + signed webhook. Customer MoMo PINs are never requested or stored.

## First-run setup

1. `.env` needs `DATABASE_URL` (already configured in this sandbox).
2. Apply schema: `npx drizzle-kit push`
3. Optional demo catalogue: `psql "$DATABASE_URL" -f scripts/seed.sql`
4. Visit **`/admin/setup`** to create the first administrator account (this page disables itself permanently once an admin exists; set `ADMIN_SETUP_KEY` env var to require a setup key as well). Admin role can never be obtained via public registration.
5. Log in at **`/admin/login`**.

### Test walkthrough
- Register a customer at `/register` → browse `/shop` → add to cart → `/checkout` → place order → note the order number → submit a MoMo reference on the pay page.
- In `/admin/orders`, open the order → **Confirm Payment** (after checking your MoMo statement) → advance status (Processing → Packed → Shipped → Out for Delivery → Delivered).
- Track publicly at `/track` with the order number + phone/email.
- The customer can now leave a **verified-purchase review** on the product page.

## Environment variables (production)

| Variable | Purpose |
|---|---|
| `DATABASE_URL` | PostgreSQL connection string (required) |
| `ADMIN_SETUP_KEY` | Optional key required by `/admin/setup` |
| `PAYSTACK_SECRET_KEY` | Enables automatic Paystack MoMo/card payments |
| `NEXT_PUBLIC_APP_URL` | Public base URL (payment callbacks, reset links) |
| `RESEND_API_KEY`, `EMAIL_FROM` | Enables transactional email notifications |

Point the Paystack dashboard webhook to `POST /api/payments/paystack/webhook`.

## Deployment

Any Node.js host (Vercel, Railway, Render, Fly.io, a VPS):

```bash
npm install
npx drizzle-kit push        # apply schema to the production PostgreSQL
npm run build
npm start
```

Use HTTPS in production (session cookies are `Secure` + `HttpOnly`), keep secrets only in environment variables, and back up the PostgreSQL database regularly.

## Security notes

- Passwords hashed with scrypt (salted); reset tokens are single-use and expire in 1 hour.
- DB-backed sessions in `HttpOnly`/`SameSite=Lax` cookies; disabled accounts lose sessions immediately.
- Role-based authorization on every admin action + middleware route guard; customers can only ever query their own cart/orders/notifications.
- All queries are parameterized via Drizzle (SQL-injection safe); React escapes output (XSS safe); server actions provide origin-bound CSRF protection; login/registration/payment endpoints are rate limited.
- Stock is reserved atomically at order time (no overselling) and restored on cancellation; `sold` counts only increase after a *confirmed* payment.
