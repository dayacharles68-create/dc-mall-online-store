"use client";

import { useActionState, useState } from "react";
import { submitPaymentReferenceAction } from "@/lib/actions/checkout";
import SubmitButton from "./SubmitButton";

export default function PaymentPanel({
  orderId,
  orderNumber,
  paystackEnabled,
  paymentStatus,
}: {
  orderId: number;
  orderNumber: string;
  paystackEnabled: boolean;
  paymentStatus: string;
}) {
  const [state, action] = useActionState(submitPaymentReferenceAction, null);
  const [loading, setLoading] = useState(false);
  const [payError, setPayError] = useState("");

  async function payWithPaystack() {
    setLoading(true);
    setPayError("");
    try {
      const res = await fetch("/api/payments/paystack/initialize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ orderId }),
      });
      const data = await res.json();
      if (data.authorizationUrl) {
        window.location.href = data.authorizationUrl;
      } else {
        setPayError(data.error || "Could not start payment. Please try again.");
        setLoading(false);
      }
    } catch {
      setPayError("Network error. Please check your connection and try again.");
      setLoading(false);
    }
  }

  if (paymentStatus === "paid") {
    return <p className="rounded-lg bg-emerald-50 px-4 py-3 text-sm font-semibold text-emerald-700 ring-1 ring-emerald-200">✓ Payment confirmed. Your order is being processed.</p>;
  }

  return (
    <div className="space-y-4">
      {paystackEnabled && (
        <div>
          <button
            onClick={payWithPaystack}
            disabled={loading}
            className="w-full rounded-lg bg-emerald-600 py-3 text-sm font-bold text-white hover:bg-emerald-500 disabled:opacity-50"
          >
            {loading ? "Connecting to Paystack…" : "💳 Pay Instantly (MoMo / Card via Paystack)"}
          </button>
          {payError && <p className="mt-2 rounded-lg bg-red-50 px-3 py-2 text-xs text-red-700">{payError}</p>}
          <p className="mt-2 text-center text-[11px] text-slate-400">Instant automatic verification via Paystack (MTN MoMo, Telecel Cash, AT Money &amp; cards).</p>
          <div className="my-4 flex items-center gap-3 text-xs text-slate-400"><span className="h-px flex-1 bg-slate-200" />OR pay manually<span className="h-px flex-1 bg-slate-200" /></div>
        </div>
      )}

      {paymentStatus === "processing" ? (
        <p className="rounded-lg bg-blue-50 px-4 py-3 text-sm text-blue-700 ring-1 ring-blue-200">
          ⏳ Your payment reference has been submitted and is awaiting verification by DC MALL. You will be notified once it is confirmed.
        </p>
      ) : (
        <form action={action} className="rounded-xl bg-white p-4 ring-1 ring-slate-200">
          <input type="hidden" name="orderId" value={orderId} />
          <p className="text-sm font-semibold text-slate-800">Already sent your MoMo payment?</p>
          <p className="mt-1 text-xs text-slate-500">
            Enter the <b>Transaction ID</b> from your MoMo receipt (SMS). Use order number <b>{orderNumber}</b> as your payment reference when sending.
          </p>
          <input
            name="reference"
            required
            minLength={4}
            placeholder="e.g. 8927465012"
            className="mt-3 w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm focus:border-slate-500 outline-none"
          />
          {state?.error && <p className="mt-2 rounded-lg bg-red-50 px-3 py-2 text-xs text-red-700">{state.error}</p>}
          {state?.success && <p className="mt-2 rounded-lg bg-emerald-50 px-3 py-2 text-xs text-emerald-700">{state.success}</p>}
          <SubmitButton pendingText="Submitting…" className="mt-3 w-full rounded-lg bg-slate-900 py-3 text-sm font-bold text-white hover:bg-slate-700">
            Submit Payment Reference for Verification
          </SubmitButton>
          <p className="mt-2 text-[11px] text-slate-400">
            ⚠ Your order is only confirmed after DC MALL verifies the transaction with the mobile money provider. Never share your MoMo PIN with anyone.
          </p>
        </form>
      )}
    </div>
  );
}
