export default function Stars({ rating, count, size = "text-sm" }: { rating: number; count?: number; size?: string }) {
  const rounded = Math.round(rating * 2) / 2;
  return (
    <span className={`inline-flex items-center gap-1 ${size}`}>
      <span className="text-amber-400 tracking-tight" aria-label={`${rating.toFixed(1)} out of 5 stars`}>
        {[1, 2, 3, 4, 5].map((i) => (
          <span key={i}>{rounded >= i ? "★" : rounded >= i - 0.5 ? "⯨" : "☆"}</span>
        ))}
      </span>
      {count !== undefined && <span className="text-xs text-slate-500">({count})</span>}
    </span>
  );
}
