"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

type Category = { id: number; name: string; slug: string };
type User = { name: string; role: string } | null;

export default function NavBar({
  user,
  cartCount,
  categories,
}: {
  user: User;
  cartCount: number;
  categories: Category[];
}) {
  const [open, setOpen] = useState(false);
  const [catOpen, setCatOpen] = useState(false);
  const router = useRouter();
  const params = useSearchParams();
  const [q, setQ] = useState(params.get("q") || "");

  function submitSearch(e: React.FormEvent) {
    e.preventDefault();
    setOpen(false);
    router.push(`/shop?q=${encodeURIComponent(q)}`);
  }

  const navLinks = [
    { href: "/", label: "Home" },
    { href: "/shop", label: "Shop" },
    { href: "/shop?sort=deals", label: "Deals" },
    { href: "/track", label: "Track Order" },
  ];

  return (
    <header className="sticky top-0 z-50 bg-slate-900 text-white shadow-lg">
      <div className="mx-auto max-w-7xl px-4">
        <div className="flex h-16 items-center gap-3">
          {/* Mobile menu button */}
          <button
            onClick={() => setOpen(!open)}
            className="lg:hidden rounded-lg p-2 hover:bg-slate-800"
            aria-label="Toggle menu"
          >
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              {open ? <path d="M6 6l12 12M18 6L6 18" /> : <path d="M4 6h16M4 12h16M4 18h16" />}
            </svg>
          </button>

          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-400 font-black text-slate-900 text-sm">
              DC
            </span>
            <span className="hidden sm:block leading-tight">
              <span className="block font-extrabold tracking-wide">DC MALL</span>
              <span className="block text-[10px] text-slate-400 -mt-0.5">Your Trusted Online Shopping Mall</span>
            </span>
          </Link>

          {/* Desktop nav */}
          <nav className="hidden lg:flex items-center gap-1 ml-4">
            {navLinks.map((l) => (
              <Link key={l.href} href={l.href} className="rounded-lg px-3 py-2 text-sm font-medium text-slate-200 hover:bg-slate-800 hover:text-white">
                {l.label}
              </Link>
            ))}
            <div className="relative">
              <button
                onClick={() => setCatOpen(!catOpen)}
                onBlur={() => setTimeout(() => setCatOpen(false), 150)}
                className="rounded-lg px-3 py-2 text-sm font-medium text-slate-200 hover:bg-slate-800 hover:text-white flex items-center gap-1"
              >
                Categories <span className="text-xs">▾</span>
              </button>
              {catOpen && (
                <div className="absolute left-0 top-full mt-1 w-56 rounded-xl bg-white py-2 shadow-xl ring-1 ring-slate-200 max-h-96 overflow-auto">
                  {categories.map((c) => (
                    <Link key={c.id} href={`/shop?category=${c.slug}`} className="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                      {c.name}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </nav>

          {/* Search */}
          <form onSubmit={submitSearch} className="hidden md:flex flex-1 max-w-md ml-auto">
            <div className="flex w-full overflow-hidden rounded-lg bg-slate-800 ring-1 ring-slate-700 focus-within:ring-amber-400">
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search products, brands…"
                className="w-full bg-transparent px-3 py-2 text-sm text-white placeholder-slate-400 outline-none"
              />
              <button type="submit" className="px-3 text-slate-300 hover:text-amber-400" aria-label="Search">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.35-4.35" /></svg>
              </button>
            </div>
          </form>

          {/* Right actions */}
          <div className="flex items-center gap-1 ml-auto md:ml-3">
            <Link href="/cart" className="relative rounded-lg p-2 hover:bg-slate-800" aria-label="Shopping cart">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="9" cy="21" r="1.5" /><circle cx="19" cy="21" r="1.5" />
                <path d="M2.5 3h3l2.4 12.2a2 2 0 0 0 2 1.8h8.4a2 2 0 0 0 2-1.6L22 8H6.1" />
              </svg>
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-amber-400 px-1 text-[11px] font-bold text-slate-900">
                  {cartCount > 99 ? "99+" : cartCount}
                </span>
              )}
            </Link>
            {user ? (
              <Link href={user.role === "admin" ? "/admin" : "/account"} className="flex items-center gap-2 rounded-lg px-3 py-2 hover:bg-slate-800">
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-slate-700 text-xs font-bold">
                  {user.name.charAt(0).toUpperCase()}
                </span>
                <span className="hidden sm:block text-sm font-medium max-w-[100px] truncate">{user.name.split(" ")[0]}</span>
              </Link>
            ) : (
              <div className="flex items-center gap-1">
                <Link href="/login" className="rounded-lg px-3 py-2 text-sm font-medium hover:bg-slate-800">Login</Link>
                <Link href="/register" className="hidden sm:block rounded-lg bg-amber-400 px-3 py-2 text-sm font-semibold text-slate-900 hover:bg-amber-300">
                  Register
                </Link>
              </div>
            )}
          </div>
        </div>

        {/* Mobile search */}
        <form onSubmit={submitSearch} className="md:hidden pb-3">
          <div className="flex overflow-hidden rounded-lg bg-slate-800 ring-1 ring-slate-700">
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search DC MALL…"
              className="w-full bg-transparent px-3 py-2 text-sm text-white placeholder-slate-400 outline-none"
            />
            <button type="submit" className="px-3 text-slate-300" aria-label="Search">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.35-4.35" /></svg>
            </button>
          </div>
        </form>
      </div>

      {/* Mobile menu */}
      {open && (
        <nav className="lg:hidden border-t border-slate-800 bg-slate-900 px-4 py-3 space-y-1">
          {navLinks.map((l) => (
            <Link key={l.href} href={l.href} onClick={() => setOpen(false)} className="block rounded-lg px-3 py-2.5 text-sm font-medium hover:bg-slate-800">
              {l.label}
            </Link>
          ))}
          <div className="pt-2 border-t border-slate-800">
            <p className="px-3 py-1 text-xs uppercase tracking-wide text-slate-500">Categories</p>
            {categories.map((c) => (
              <Link key={c.id} href={`/shop?category=${c.slug}`} onClick={() => setOpen(false)} className="block rounded-lg px-3 py-2 text-sm text-slate-300 hover:bg-slate-800">
                {c.name}
              </Link>
            ))}
          </div>
          {!user && (
            <div className="pt-2 border-t border-slate-800 flex gap-2">
              <Link href="/login" onClick={() => setOpen(false)} className="flex-1 rounded-lg bg-slate-800 px-3 py-2.5 text-center text-sm font-medium">Login</Link>
              <Link href="/register" onClick={() => setOpen(false)} className="flex-1 rounded-lg bg-amber-400 px-3 py-2.5 text-center text-sm font-semibold text-slate-900">Register</Link>
            </div>
          )}
        </nav>
      )}
    </header>
  );
}
