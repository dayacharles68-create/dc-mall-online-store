import { eq } from "drizzle-orm";
import { db } from "@/db";
import { categories } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { getCartCount } from "@/lib/actions/cart";
import NavBar from "./NavBar";

export default async function Header() {
  const user = await getSessionUser();
  const [cartCount, cats] = await Promise.all([
    user ? getCartCount(user.id) : Promise.resolve(0),
    db
      .select({ id: categories.id, name: categories.name, slug: categories.slug })
      .from(categories)
      .where(eq(categories.status, "active"))
      .orderBy(categories.name),
  ]);
  return (
    <NavBar
      user={user ? { name: user.name, role: user.role } : null}
      cartCount={cartCount}
      categories={cats}
    />
  );
}
