"use client";

import Link from "next/link";
import { useActionState } from "react";
import {
  forgotPasswordAction,
  loginAction,
  registerAction,
  resetPasswordAction,
  updateProfileAction,
} from "@/lib/actions/auth";
import { GHANA_REGIONS } from "@/lib/utils";
import SubmitButton from "./SubmitButton";

const input = "mt-1 w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm focus:border-slate-500 outline-none";

function Alert({ state }: { state: { error?: string; success?: string } | null }) {
  if (!state) return null;
  if (state.error) return <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700 ring-1 ring-red-100">{state.error}</p>;
  if (state.success) return <p className="rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-700 ring-1 ring-emerald-100">{state.success}</p>;
  return null;
}

export function LoginForm({ next, admin }: { next?: string; admin?: boolean }) {
  const [state, action] = useActionState(loginAction, null);
  return (
    <form action={action} className="space-y-4">
      {next && <input type="hidden" name="next" value={next} />}
      {admin && <input type="hidden" name="portal" value="admin" />}
      <label className="block text-sm">
        <span className="font-medium text-slate-700">Email or phone number</span>
        <input name="identifier" required className={input} placeholder="you@example.com or 054 000 0000" />
      </label>
      <label className="block text-sm">
        <span className="font-medium text-slate-700">Password</span>
        <input name="password" type="password" required className={input} placeholder="••••••••" />
      </label>
      <div className="flex items-center justify-between text-sm">
        <label className="flex items-center gap-2 text-slate-600">
          <input type="checkbox" name="remember" defaultChecked className="rounded" /> Remember me
        </label>
        {!admin && <Link href="/forgot-password" className="font-medium text-slate-700 hover:underline">Forgot password?</Link>}
      </div>
      <Alert state={state} />
      <SubmitButton pendingText="Signing in…" className="w-full rounded-lg bg-slate-900 py-3 text-sm font-bold text-white hover:bg-slate-700">
        {admin ? "Sign in to Admin" : "Login"}
      </SubmitButton>
    </form>
  );
}

export function RegisterForm({ next }: { next?: string }) {
  const [state, action] = useActionState(registerAction, null);
  return (
    <form action={action} className="space-y-4">
      {next && <input type="hidden" name="next" value={next} />}
      <label className="block text-sm">
        <span className="font-medium text-slate-700">Full name *</span>
        <input name="name" required className={input} placeholder="e.g. Ama Owusu" />
      </label>
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="block text-sm">
          <span className="font-medium text-slate-700">Email address *</span>
          <input name="email" type="email" required className={input} placeholder="you@example.com" />
        </label>
        <label className="block text-sm">
          <span className="font-medium text-slate-700">Phone number *</span>
          <input name="phone" inputMode="tel" required className={input} placeholder="054 000 0000" />
        </label>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="block text-sm">
          <span className="font-medium text-slate-700">Password * <span className="text-xs text-slate-400">(min 8 chars)</span></span>
          <input name="password" type="password" required minLength={8} className={input} />
        </label>
        <label className="block text-sm">
          <span className="font-medium text-slate-700">Confirm password *</span>
          <input name="confirm" type="password" required minLength={8} className={input} />
        </label>
      </div>
      <label className="block text-sm">
        <span className="font-medium text-slate-700">Delivery address <span className="text-xs text-slate-400">(optional)</span></span>
        <input name="address" className={input} placeholder="House number, street, landmark" />
      </label>
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="block text-sm">
          <span className="font-medium text-slate-700">City / Town</span>
          <input name="city" className={input} placeholder="e.g. Kumasi" />
        </label>
        <label className="block text-sm">
          <span className="font-medium text-slate-700">Region</span>
          <select name="region" className={input} defaultValue="">
            <option value="">Select region…</option>
            {GHANA_REGIONS.map((r) => <option key={r} value={r}>{r}</option>)}
          </select>
        </label>
      </div>
      <Alert state={state} />
      <SubmitButton pendingText="Creating account…" className="w-full rounded-lg bg-amber-400 py-3 text-sm font-bold text-slate-900 hover:bg-amber-300">
        Create My Account
      </SubmitButton>
    </form>
  );
}

export function ForgotForm() {
  const [state, action] = useActionState(forgotPasswordAction, null);
  return (
    <form action={action} className="space-y-4">
      <label className="block text-sm">
        <span className="font-medium text-slate-700">Email address</span>
        <input name="email" type="email" required className={input} placeholder="you@example.com" />
      </label>
      <Alert state={state} />
      <SubmitButton pendingText="Sending…" className="w-full rounded-lg bg-slate-900 py-3 text-sm font-bold text-white hover:bg-slate-700">
        Send Reset Link
      </SubmitButton>
    </form>
  );
}

export function ResetForm({ token }: { token: string }) {
  const [state, action] = useActionState(resetPasswordAction, null);
  return (
    <form action={action} className="space-y-4">
      <input type="hidden" name="token" value={token} />
      <label className="block text-sm">
        <span className="font-medium text-slate-700">New password</span>
        <input name="password" type="password" required minLength={8} className={input} />
      </label>
      <label className="block text-sm">
        <span className="font-medium text-slate-700">Confirm new password</span>
        <input name="confirm" type="password" required minLength={8} className={input} />
      </label>
      <Alert state={state} />
      {state?.success ? (
        <Link href="/login" className="block w-full rounded-lg bg-amber-400 py-3 text-center text-sm font-bold text-slate-900">Go to Login</Link>
      ) : (
        <SubmitButton pendingText="Resetting…" className="w-full rounded-lg bg-slate-900 py-3 text-sm font-bold text-white hover:bg-slate-700">
          Reset Password
        </SubmitButton>
      )}
    </form>
  );
}

export function ProfileForm({
  defaults,
}: {
  defaults: { name: string; phone: string; address: string; city: string; region: string };
}) {
  const [state, action] = useActionState(updateProfileAction, null);
  return (
    <form action={action} className="space-y-3">
      <label className="block text-sm">
        <span className="font-medium text-slate-700">Full name</span>
        <input name="name" defaultValue={defaults.name} required className={input} />
      </label>
      <label className="block text-sm">
        <span className="font-medium text-slate-700">Phone</span>
        <input name="phone" defaultValue={defaults.phone} required className={input} />
      </label>
      <label className="block text-sm">
        <span className="font-medium text-slate-700">Saved delivery address</span>
        <input name="address" defaultValue={defaults.address} className={input} />
      </label>
      <div className="grid grid-cols-2 gap-3">
        <label className="block text-sm">
          <span className="font-medium text-slate-700">City</span>
          <input name="city" defaultValue={defaults.city} className={input} />
        </label>
        <label className="block text-sm">
          <span className="font-medium text-slate-700">Region</span>
          <select name="region" defaultValue={defaults.region} className={input}>
            <option value="">Select…</option>
            {GHANA_REGIONS.map((r) => <option key={r} value={r}>{r}</option>)}
          </select>
        </label>
      </div>
      <Alert state={state} />
      <SubmitButton pendingText="Saving…" className="rounded-lg bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white hover:bg-slate-700">
        Save Profile
      </SubmitButton>
    </form>
  );
}
