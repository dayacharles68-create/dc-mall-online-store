"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";

const links = [
  { href: "/admin", label: "Dashboard", icon: "📊" },
  { href: "/admin/orders", label: "Orders", icon: "📦" },
  { href: "/admin/products", label: "Products", icon: "🏷️" },
  { href: "/admin/inventory", label: "Inventory", icon: "📋" },
  { href: "/admin/categories", label: "Categories", icon: "🗂️" },
  { href: "/admin/customers", label: "Customers", icon: "👥" },
  { href: "/admin/reviews", label: "Reviews", icon: "⭐" },
  { href: "/admin/audit", label: "Audit Log", icon: "🧾" },
  { href: "/admin/settings", label: "Settings", icon: "⚙️" },
];

export default function AdminSidebar({ adminName }: { adminName: string }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  const nav = (
    <nav className="space-y-1 p-3">
      {links.map((l) => {
        const active = l.href === "/admin" ? pathname === "/admin" : pathname.startsWith(l.href);
        return (
          <Link
            key={l.href}
            href={l.href}
            onClick={() => setOpen(false)}
            className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition ${
              active ? "bg-amber-400 text-slate-900" : "text-slate-300 hover:bg-slate-800 hover:text-white"
            }`}
          >
            <span>{l.icon}</span> {l.label}
          </Link>
        );
      })}
      <Link href="/" className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-slate-400 hover:bg-slate-800 hover:text-white">
        🏬 View Store
      </Link>
    </nav>
  );

  return (
    <>
      {/* Mobile top bar */}
      <div className="flex items-center justify-between bg-slate-900 px-4 py-3 text-white lg:hidden">
        <div className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-400 text-xs font-black text-slate-900">DC</span>
          <span className="font-bold">DC MALL Admin</span>
        </div>
        <button onClick={() => setOpen(!open)} className="rounded-lg p-2 hover:bg-slate-800" aria-label="Menu">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            {open ? <path d="M6 6l12 12M18 6L6 18" /> : <path d="M4 6h16M4 12h16M4 18h16" />}
          </svg>
        </button>
      </div>
      {open && <div className="bg-slate-900 lg:hidden">{nav}</div>}

      {/* Desktop sidebar */}
      <aside className="hidden lg:flex lg:w-60 lg:flex-col bg-slate-900 min-h-screen sticky top-0 max-h-screen">
        <div className="flex items-center gap-2 border-b border-slate-800 p-4">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-400 text-sm font-black text-slate-900">DC</span>
          <div>
            <p className="font-bold text-white leading-tight">DC MALL</p>
            <p className="text-[10px] text-slate-400">Admin Dashboard</p>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">{nav}</div>
        <div className="border-t border-slate-800 p-4 text-xs text-slate-400">
          Signed in as <span className="font-semibold text-white">{adminName}</span>
        </div>
      </aside>
    </>
  );
}
