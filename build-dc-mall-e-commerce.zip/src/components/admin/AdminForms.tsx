"use client";

import { useActionState } from "react";
import { createFirstAdminAction, saveCategoryAction, saveProductAction, saveSettingsAction } from "@/lib/actions/admin";
import SubmitButton from "@/components/SubmitButton";

const input = "mt-1 w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm focus:border-slate-500 outline-none";

function Alert({ state }: { state: { error?: string; success?: string } | null }) {
  if (!state) return null;
  if (state.error) return <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700 ring-1 ring-red-100">{state.error}</p>;
  if (state.success) return <p className="rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-700 ring-1 ring-emerald-100">{state.success}</p>;
  return null;
}

export function SetupForm({ needsKey }: { needsKey: boolean }) {
  const [state, action] = useActionState(createFirstAdminAction, null);
  return (
    <form action={action} className="space-y-4">
      <label className="block text-sm"><span className="font-medium text-slate-700">Administrator name *</span>
        <input name="name" required className={input} /></label>
      <label className="block text-sm"><span className="font-medium text-slate-700">Admin email *</span>
        <input name="email" type="email" required className={input} /></label>
      <label className="block text-sm"><span className="font-medium text-slate-700">Phone</span>
        <input name="phone" className={input} placeholder="+233 54 531 5419" /></label>
      <label className="block text-sm"><span className="font-medium text-slate-700">Password * <span className="text-xs text-slate-400">(min 10 characters)</span></span>
        <input name="password" type="password" required minLength={10} className={input} /></label>
      {needsKey && (
        <label className="block text-sm"><span className="font-medium text-slate-700">Setup key (ADMIN_SETUP_KEY) *</span>
          <input name="setupKey" required className={input} /></label>
      )}
      <Alert state={state} />
      <SubmitButton pendingText="Creating…" className="w-full rounded-lg bg-slate-900 py-3 text-sm font-bold text-white hover:bg-slate-700">
        Create Administrator Account
      </SubmitButton>
    </form>
  );
}

type Category = { id: number; name: string };
type ProductData = {
  id?: number; name?: string; description?: string; price?: number; discountPrice?: number | null;
  categoryId?: number | null; brand?: string | null; sku?: string | null; stock?: number;
  status?: string; specifications?: string | null; seoTitle?: string | null; seoDescription?: string | null;
  images?: string[];
};

export function ProductForm({ categories, product }: { categories: Category[]; product?: ProductData }) {
  const [state, action] = useActionState(saveProductAction, null);
  return (
    <form action={action} className="space-y-4">
      {product?.id && <input type="hidden" name="id" value={product.id} />}
      <div className="grid gap-4 md:grid-cols-2">
        <label className="block text-sm md:col-span-2"><span className="font-medium text-slate-700">Product name *</span>
          <input name="name" required defaultValue={product?.name} className={input} /></label>
        <label className="block text-sm md:col-span-2"><span className="font-medium text-slate-700">Description *</span>
          <textarea name="description" rows={4} required defaultValue={product?.description} className={input} /></label>
        <label className="block text-sm"><span className="font-medium text-slate-700">Price (₵) *</span>
          <input name="price" type="number" step="0.01" min="0.01" required defaultValue={product?.price} className={input} /></label>
        <label className="block text-sm"><span className="font-medium text-slate-700">Discount price (₵)</span>
          <input name="discountPrice" type="number" step="0.01" min="0" defaultValue={product?.discountPrice ?? ""} className={input} /></label>
        <label className="block text-sm"><span className="font-medium text-slate-700">Category</span>
          <select name="categoryId" defaultValue={product?.categoryId ?? ""} className={input}>
            <option value="">— None —</option>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select></label>
        <label className="block text-sm"><span className="font-medium text-slate-700">Brand</span>
          <input name="brand" defaultValue={product?.brand ?? ""} className={input} /></label>
        <label className="block text-sm"><span className="font-medium text-slate-700">SKU</span>
          <input name="sku" defaultValue={product?.sku ?? ""} className={input} /></label>
        <label className="block text-sm"><span className="font-medium text-slate-700">Stock quantity *</span>
          <input name="stock" type="number" min="0" required defaultValue={product?.stock ?? 0} className={input} /></label>
        <label className="block text-sm"><span className="font-medium text-slate-700">Status</span>
          <select name="status" defaultValue={product?.status ?? "active"} className={input}>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="out_of_stock">Out of Stock</option>
            <option value="draft">Draft</option>
          </select></label>
        <label className="block text-sm md:col-span-2"><span className="font-medium text-slate-700">Image URLs (one per line, first = main image)</span>
          <textarea name="images" rows={3} defaultValue={product?.images?.join("\n")} className={input} placeholder="https://…" /></label>
        <label className="block text-sm md:col-span-2"><span className="font-medium text-slate-700">Specifications (one per line, format “Key: Value”)</span>
          <textarea name="specifications" rows={3} defaultValue={product?.specifications ?? ""} className={input} placeholder="Color: Black&#10;Warranty: 12 months" /></label>
        <label className="block text-sm"><span className="font-medium text-slate-700">SEO title</span>
          <input name="seoTitle" defaultValue={product?.seoTitle ?? ""} className={input} /></label>
        <label className="block text-sm"><span className="font-medium text-slate-700">SEO meta description</span>
          <input name="seoDescription" defaultValue={product?.seoDescription ?? ""} className={input} /></label>
      </div>
      <Alert state={state} />
      <SubmitButton pendingText="Saving…" className="rounded-lg bg-slate-900 px-6 py-3 text-sm font-bold text-white hover:bg-slate-700">
        {product?.id ? "Save Changes" : "Add Product"}
      </SubmitButton>
    </form>
  );
}

export function CategoryForm({ category }: { category?: { id: number; name: string; description: string | null; image: string | null; status: string } }) {
  const [state, action] = useActionState(saveCategoryAction, null);
  return (
    <form action={action} className="space-y-3">
      {category && <input type="hidden" name="id" value={category.id} />}
      <label className="block text-sm"><span className="font-medium text-slate-700">Category name *</span>
        <input name="name" required defaultValue={category?.name} className={input} /></label>
      <label className="block text-sm"><span className="font-medium text-slate-700">Description</span>
        <input name="description" defaultValue={category?.description ?? ""} className={input} /></label>
      <label className="block text-sm"><span className="font-medium text-slate-700">Image URL</span>
        <input name="image" defaultValue={category?.image ?? ""} className={input} /></label>
      <label className="block text-sm"><span className="font-medium text-slate-700">Status</span>
        <select name="status" defaultValue={category?.status ?? "active"} className={input}>
          <option value="active">Active</option><option value="inactive">Inactive</option>
        </select></label>
      <Alert state={state} />
      <SubmitButton pendingText="Saving…" className="w-full rounded-lg bg-slate-900 py-2.5 text-sm font-bold text-white hover:bg-slate-700">
        {category ? "Save Category" : "Add Category"}
      </SubmitButton>
    </form>
  );
}

export function SettingsForm({ values }: { values: Record<string, string> }) {
  const [state, action] = useActionState(saveSettingsAction, null);
  const fields: [string, string, string?][] = [
    ["mall_name", "Mall name"],
    ["tagline", "Tagline"],
    ["contact_phone", "Contact phone"],
    ["contact_email", "Contact email"],
    ["business_address", "Business address"],
    ["payment_number", "MoMo payment account number", "The official DC MALL Mobile Money number shown to customers"],
    ["payment_account_name", "Payment account name"],
    ["currency", "Currency", "Default: GHS (Ghana Cedi ₵)"],
    ["delivery_fee_accra", "Delivery fee — Greater Accra (₵)"],
    ["delivery_fee_default", "Delivery fee — other regions (₵)"],
    ["low_stock_threshold", "Low-stock alert threshold"],
    ["order_prefix", "Order number prefix"],
  ];
  return (
    <form action={action} className="space-y-4">
      <div className="grid gap-4 md:grid-cols-2">
        {fields.map(([key, label, hint]) => (
          <label key={key} className="block text-sm">
            <span className="font-medium text-slate-700">{label}</span>
            <input name={key} defaultValue={values[key] || ""} className={input} />
            {hint && <span className="text-xs text-slate-400">{hint}</span>}
          </label>
        ))}
        <label className="block text-sm">
          <span className="font-medium text-slate-700">Email notifications</span>
          <select name="notify_email_enabled" defaultValue={values.notify_email_enabled || "1"} className={input}>
            <option value="1">Enabled (requires RESEND_API_KEY)</option>
            <option value="0">Disabled</option>
          </select>
        </label>
      </div>
      <Alert state={state} />
      <SubmitButton pendingText="Saving…" className="rounded-lg bg-slate-900 px-6 py-3 text-sm font-bold text-white hover:bg-slate-700">
        Save Settings
      </SubmitButton>
    </form>
  );
}
