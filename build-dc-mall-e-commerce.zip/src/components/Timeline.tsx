import { ORDER_FLOW, ORDER_STATUS_LABELS, formatDate } from "@/lib/utils";

type Event = { status: string; description: string | null; createdAt: Date };

export default function Timeline({
  orderStatus,
  paymentStatus,
  events,
}: {
  orderStatus: string;
  paymentStatus: string;
  events: Event[];
}) {
  const cancelled = orderStatus === "cancelled" || orderStatus === "refunded";
  const currentIdx = ORDER_FLOW.indexOf(orderStatus as (typeof ORDER_FLOW)[number]);

  const steps = [
    { key: "placed", label: "Order Placed" },
    { key: "payment_confirmed", label: "Payment Confirmed" },
    { key: "processing", label: "Processing" },
    { key: "packed", label: "Packed" },
    { key: "shipped", label: "Shipped" },
    { key: "out_for_delivery", label: "Out for Delivery" },
    { key: "delivered", label: "Delivered" },
  ];

  function stepDone(key: string): boolean {
    if (cancelled) return events.some((e) => e.status === key);
    if (key === "payment_confirmed") return paymentStatus === "paid" || paymentStatus === "refunded";
    const idx = ORDER_FLOW.indexOf(key as (typeof ORDER_FLOW)[number]);
    return idx >= 0 && currentIdx >= idx;
  }

  function stepTime(key: string): Date | null {
    const ev = [...events].reverse().find((e) => e.status === key);
    return ev ? ev.createdAt : null;
  }

  return (
    <div>
      {cancelled && (
        <div className="mb-4 rounded-lg bg-red-50 px-4 py-3 text-sm font-semibold text-red-700 ring-1 ring-red-100">
          This order has been {ORDER_STATUS_LABELS[orderStatus]?.toLowerCase() || orderStatus}.
        </div>
      )}
      <ol className="relative space-y-0">
        {steps.map((step, i) => {
          const done = stepDone(step.key);
          const time = stepTime(step.key);
          const isCurrent =
            !cancelled &&
            done &&
            (i === steps.length - 1 || !stepDone(steps[i + 1].key));
          return (
            <li key={step.key} className="relative flex gap-4 pb-6 last:pb-0">
              {i < steps.length - 1 && (
                <span className={`absolute left-[13px] top-7 h-full w-0.5 ${done && stepDone(steps[i + 1].key) ? "bg-emerald-500" : "bg-slate-200"}`} />
              )}
              <span
                className={`relative z-10 flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold ring-2 ${
                  done ? "bg-emerald-500 text-white ring-emerald-500" : "bg-white text-slate-400 ring-slate-300"
                } ${isCurrent ? "ring-4 ring-emerald-200" : ""}`}
              >
                {done ? "✓" : i + 1}
              </span>
              <div className="pt-0.5">
                <p className={`text-sm font-semibold ${done ? "text-slate-900" : "text-slate-400"}`}>
                  {step.label}
                  {isCurrent && <span className="ml-2 rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-700">CURRENT</span>}
                </p>
                {time && <p className="text-xs text-slate-500">{formatDate(time)}</p>}
              </div>
            </li>
          );
        })}
      </ol>
      <div className="mt-6 border-t border-slate-100 pt-4">
        <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-400">Full history</h4>
        <ul className="mt-2 space-y-2">
          {[...events].reverse().map((e, i) => (
            <li key={i} className="text-xs text-slate-600">
              <span className="font-semibold text-slate-800">{formatDate(e.createdAt)}</span> — {e.description || ORDER_STATUS_LABELS[e.status] || e.status}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
