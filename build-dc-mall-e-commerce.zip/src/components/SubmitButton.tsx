"use client";

import { useFormStatus } from "react-dom";
import type { ReactNode } from "react";

export default function SubmitButton({
  children,
  className,
  pendingText = "Please wait…",
}: {
  children: ReactNode;
  className?: string;
  pendingText?: string;
}) {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      disabled={pending}
      className={`${className || ""} ${pending ? "opacity-60 cursor-wait" : ""} transition`}
    >
      {pending ? pendingText : children}
    </button>
  );
}
