export default function BarChart({
  data,
  color = "bg-slate-900",
  valueFormat = (n: number) => n.toLocaleString(),
}: {
  data: { label: string; value: number }[];
  color?: string;
  valueFormat?: (n: number) => string;
}) {
  const max = Math.max(1, ...data.map((d) => d.value));
  return (
    <div className="flex h-44 items-end gap-1.5">
      {data.map((d, i) => (
        <div key={i} className="group relative flex flex-1 flex-col items-center justify-end h-full min-w-0">
          <span className="pointer-events-none absolute -top-6 hidden whitespace-nowrap rounded bg-slate-900 px-1.5 py-0.5 text-[10px] text-white group-hover:block z-10">
            {valueFormat(d.value)}
          </span>
          <div
            className={`w-full rounded-t ${color} opacity-80 group-hover:opacity-100 transition-all`}
            style={{ height: `${Math.max(2, (d.value / max) * 100)}%` }}
          />
          <span className="mt-1 w-full truncate text-center text-[9px] text-slate-500">{d.label}</span>
        </div>
      ))}
    </div>
  );
}
