"use client";

import { useActionState, useState } from "react";
import { submitReviewAction } from "@/lib/actions/reviews";
import SubmitButton from "./SubmitButton";

export default function ReviewForm({ productId, slug, loggedIn }: { productId: number; slug: string; loggedIn: boolean }) {
  const [state, action] = useActionState(submitReviewAction, null);
  const [rating, setRating] = useState(5);

  if (!loggedIn) {
    return (
      <p className="rounded-lg bg-slate-50 p-4 text-sm text-slate-600 ring-1 ring-slate-200">
        <a href={`/login?next=/product/${slug}`} className="font-semibold text-slate-900 underline">Log in</a> to review this product. Only verified purchasers can post reviews.
      </p>
    );
  }

  return (
    <form action={action} className="rounded-xl bg-slate-50 p-4 ring-1 ring-slate-200">
      <input type="hidden" name="productId" value={productId} />
      <input type="hidden" name="slug" value={slug} />
      <input type="hidden" name="rating" value={rating} />
      <p className="text-sm font-semibold text-slate-800">Write a review</p>
      <div className="mt-2 flex gap-1">
        {[1, 2, 3, 4, 5].map((i) => (
          <button key={i} type="button" onClick={() => setRating(i)} className={`text-2xl ${i <= rating ? "text-amber-400" : "text-slate-300"}`} aria-label={`${i} stars`}>
            ★
          </button>
        ))}
        <span className="ml-2 self-center text-xs text-slate-500">{rating}/5</span>
      </div>
      <textarea
        name="review"
        rows={3}
        maxLength={2000}
        placeholder="Share your experience with this product…"
        className="mt-3 w-full rounded-lg border border-slate-200 p-3 text-sm focus:border-slate-400 outline-none"
      />
      {state?.error && <p className="mt-2 rounded-lg bg-red-50 px-3 py-2 text-xs text-red-700">{state.error}</p>}
      {state?.success && <p className="mt-2 rounded-lg bg-emerald-50 px-3 py-2 text-xs text-emerald-700">{state.success}</p>}
      <SubmitButton className="mt-3 rounded-lg bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white hover:bg-slate-700" pendingText="Submitting…">
        Submit Review
      </SubmitButton>
    </form>
  );
}
