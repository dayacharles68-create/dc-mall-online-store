"use client";

import { useActionState, useState } from "react";
import { placeOrderAction } from "@/lib/actions/checkout";
import { cedis, GHANA_REGIONS } from "@/lib/utils";
import SubmitButton from "./SubmitButton";

type Item = { name: string; quantity: number; price: number; image: string | null };

export default function CheckoutForm({
  defaults,
  items,
  subtotal,
  fees,
  paymentNumber,
  paymentName,
}: {
  defaults: { name: string; phone: string; email: string; address: string; city: string; region: string };
  items: Item[];
  subtotal: number;
  fees: { accra: number; other: number };
  paymentNumber: string;
  paymentName: string;
}) {
  const [step, setStep] = useState(1);
  const [info, setInfo] = useState({ ...defaults, instructions: "" });
  const [state, action] = useActionState(placeOrderAction, null);

  const deliveryFee = info.region === "Greater Accra" ? fees.accra : fees.other;
  const total = subtotal + deliveryFee;

  const infoValid =
    info.name.trim().length >= 2 &&
    /^\+?[0-9 ()-]{9,16}$/.test(info.phone) &&
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(info.email) &&
    info.address.trim().length >= 5 &&
    info.city.trim().length >= 2 &&
    GHANA_REGIONS.includes(info.region);

  const set = (k: string, v: string) => setInfo((p) => ({ ...p, [k]: v }));
  const inputCls = "mt-1 w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm focus:border-slate-500 outline-none";

  return (
    <div>
      {/* Stepper */}
      <div className="flex items-center gap-2 text-xs sm:text-sm">
        {["Customer Information", "Order Review", "Payment"].map((label, i) => (
          <div key={label} className="flex items-center gap-2">
            <span className={`flex h-7 w-7 items-center justify-center rounded-full font-bold ${step > i ? "bg-slate-900 text-white" : "bg-slate-200 text-slate-500"}`}>
              {i + 1}
            </span>
            <span className={`hidden sm:block font-medium ${step > i ? "text-slate-900" : "text-slate-400"}`}>{label}</span>
            {i < 2 && <span className="h-px w-6 sm:w-10 bg-slate-300" />}
          </div>
        ))}
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_320px]">
        <div className="rounded-xl bg-white p-5 ring-1 ring-slate-200">
          {step === 1 && (
            <div className="space-y-4">
              <h2 className="font-bold text-slate-900">Step 1 — Customer Information</h2>
              <div className="grid gap-4 sm:grid-cols-2">
                <label className="block text-sm">
                  <span className="font-medium text-slate-700">Full name *</span>
                  <input value={info.name} onChange={(e) => set("name", e.target.value)} className={inputCls} placeholder="e.g. Kofi Mensah" />
                </label>
                <label className="block text-sm">
                  <span className="font-medium text-slate-700">Phone number *</span>
                  <input value={info.phone} onChange={(e) => set("phone", e.target.value)} inputMode="tel" className={inputCls} placeholder="e.g. 054 000 0000" />
                </label>
              </div>
              <label className="block text-sm">
                <span className="font-medium text-slate-700">Email *</span>
                <input value={info.email} onChange={(e) => set("email", e.target.value)} inputMode="email" className={inputCls} placeholder="you@example.com" />
              </label>
              <label className="block text-sm">
                <span className="font-medium text-slate-700">Delivery address *</span>
                <input value={info.address} onChange={(e) => set("address", e.target.value)} className={inputCls} placeholder="House number, street, landmark" />
              </label>
              <div className="grid gap-4 sm:grid-cols-2">
                <label className="block text-sm">
                  <span className="font-medium text-slate-700">Town / City *</span>
                  <input value={info.city} onChange={(e) => set("city", e.target.value)} className={inputCls} placeholder="e.g. Accra" />
                </label>
                <label className="block text-sm">
                  <span className="font-medium text-slate-700">Region *</span>
                  <select value={info.region} onChange={(e) => set("region", e.target.value)} className={inputCls}>
                    <option value="">Select region…</option>
                    {GHANA_REGIONS.map((r) => <option key={r} value={r}>{r}</option>)}
                  </select>
                </label>
              </div>
              <label className="block text-sm">
                <span className="font-medium text-slate-700">Additional delivery instructions (optional)</span>
                <textarea value={info.instructions} onChange={(e) => set("instructions", e.target.value)} rows={2} className={inputCls} placeholder="e.g. Call when you arrive at the junction" />
              </label>
              <button
                onClick={() => infoValid && setStep(2)}
                disabled={!infoValid}
                className="w-full rounded-lg bg-slate-900 py-3 text-sm font-bold text-white disabled:opacity-40 hover:bg-slate-700"
              >
                Continue to Order Review →
              </button>
              {!infoValid && <p className="text-xs text-slate-400 text-center">Fill in all required fields to continue.</p>}
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <h2 className="font-bold text-slate-900">Step 2 — Order Review</h2>
              <div className="divide-y divide-slate-100 rounded-lg ring-1 ring-slate-200">
                {items.map((it, i) => (
                  <div key={i} className="flex items-center gap-3 p-3">
                    {it.image ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={it.image} alt="" className="h-12 w-12 rounded-lg object-cover" />
                    ) : <span className="flex h-12 w-12 items-center justify-center rounded-lg bg-slate-100">🛍️</span>}
                    <div className="flex-1 min-w-0">
                      <p className="truncate text-sm font-medium text-slate-800">{it.name}</p>
                      <p className="text-xs text-slate-500">{it.quantity} × {cedis(it.price)}</p>
                    </div>
                    <span className="text-sm font-bold">{cedis(it.price * it.quantity)}</span>
                  </div>
                ))}
              </div>
              <div className="rounded-lg bg-slate-50 p-3 text-sm">
                <p className="font-semibold text-slate-800">Deliver to:</p>
                <p className="text-slate-600">{info.name} · {info.phone}</p>
                <p className="text-slate-600">{info.address}, {info.city}, {info.region}</p>
              </div>
              <div className="flex gap-3">
                <button onClick={() => setStep(1)} className="flex-1 rounded-lg bg-slate-100 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-200">← Edit Details</button>
                <button onClick={() => setStep(3)} className="flex-1 rounded-lg bg-slate-900 py-3 text-sm font-bold text-white hover:bg-slate-700">Continue to Payment →</button>
              </div>
            </div>
          )}

          {step === 3 && (
            <form action={action} className="space-y-4">
              {Object.entries(info).map(([k, v]) => <input key={k} type="hidden" name={k} value={v} />)}
              <h2 className="font-bold text-slate-900">Step 3 — Payment</h2>
              <div className="rounded-xl bg-amber-50 p-4 ring-1 ring-amber-200">
                <p className="text-sm font-bold text-slate-900">📱 Mobile Money (MoMo)</p>
                <p className="mt-1 text-sm text-slate-700">
                  Pay to the official DC MALL payment account:
                </p>
                <p className="mt-2 rounded-lg bg-white px-3 py-2 text-center text-lg font-extrabold tracking-wide text-slate-900 ring-1 ring-amber-300">
                  {paymentNumber}
                </p>
                <p className="mt-1 text-center text-xs font-semibold text-slate-600">Account name: {paymentName}</p>
                <ol className="mt-3 list-decimal space-y-1 pl-5 text-xs text-slate-600">
                  <li>Place your order below to receive your order number.</li>
                  <li>Send <b>{cedis(total)}</b> to the number above via MTN MoMo, Telecel Cash or AT Money.</li>
                  <li>Use your <b>order number</b> as the payment reference.</li>
                  <li>Submit your MoMo transaction ID on the payment page — DC MALL verifies every payment before processing.</li>
                </ol>
              </div>
              <p className="rounded-lg bg-slate-50 px-3 py-2 text-[11px] text-slate-500 ring-1 ring-slate-200">
                🔒 Never share your MoMo PIN. DC MALL will never ask for your PIN — payments are made from your own phone and verified against the provider record.
              </p>
              {state?.error && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700 ring-1 ring-red-100">{state.error}</p>}
              <div className="flex gap-3">
                <button type="button" onClick={() => setStep(2)} className="rounded-lg bg-slate-100 px-4 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-200">←</button>
                <SubmitButton pendingText="Placing your order…" className="flex-1 rounded-lg bg-amber-400 py-3 text-sm font-bold text-slate-900 hover:bg-amber-300">
                  Place Order — {cedis(total)}
                </SubmitButton>
              </div>
            </form>
          )}
        </div>

        {/* Summary sidebar */}
        <aside className="h-fit rounded-xl bg-white p-5 ring-1 ring-slate-200">
          <h2 className="font-bold text-slate-900">Summary</h2>
          <dl className="mt-3 space-y-2 text-sm">
            <div className="flex justify-between"><dt className="text-slate-500">Items ({items.reduce((s, i) => s + i.quantity, 0)})</dt><dd className="font-semibold">{cedis(subtotal)}</dd></div>
            <div className="flex justify-between"><dt className="text-slate-500">Delivery fee</dt><dd className="font-semibold">{info.region ? cedis(deliveryFee) : "—"}</dd></div>
            <div className="flex justify-between border-t border-slate-100 pt-2 text-base">
              <dt className="font-bold">Total</dt><dd className="font-extrabold">{info.region ? cedis(total) : cedis(subtotal) + " + delivery"}</dd>
            </div>
          </dl>
        </aside>
      </div>
    </div>
  );
}
