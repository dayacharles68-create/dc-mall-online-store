import Link from "next/link";
import { getSettings } from "@/lib/settings";

export default async function Footer() {
  const s = await getSettings();
  return (
    <footer className="mt-16 bg-slate-900 text-slate-300">
      <div className="mx-auto max-w-7xl px-4 py-12 grid grid-cols-2 gap-8 md:grid-cols-4 lg:grid-cols-5">
        <div className="col-span-2 lg:col-span-2">
          <div className="flex items-center gap-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-400 font-black text-slate-900 text-sm">DC</span>
            <span className="font-extrabold text-white text-lg">{s.mall_name}</span>
          </div>
          <p className="mt-2 text-sm text-slate-400">“{s.tagline}”</p>
          <div className="mt-4 space-y-1 text-sm text-slate-400">
            <p>📞 {s.contact_phone}</p>
            <p>✉️ {s.contact_email}</p>
            <p>📍 {s.business_address}</p>
          </div>
          <p className="mt-4 text-xs text-slate-500">
            Payments via Mobile Money (MoMo) to the official DC MALL account. We will never ask for your MoMo PIN.
          </p>
        </div>
        <div>
          <h3 className="font-semibold text-white text-sm uppercase tracking-wide">Customer Service</h3>
          <ul className="mt-3 space-y-2 text-sm">
            <li><Link className="hover:text-amber-400" href="/contact">Contact Us</Link></li>
            <li><Link className="hover:text-amber-400" href="/track">Track Order</Link></li>
            <li><Link className="hover:text-amber-400" href="/returns">Returns</Link></li>
            <li><Link className="hover:text-amber-400" href="/faqs">FAQs</Link></li>
          </ul>
        </div>
        <div>
          <h3 className="font-semibold text-white text-sm uppercase tracking-wide">Account</h3>
          <ul className="mt-3 space-y-2 text-sm">
            <li><Link className="hover:text-amber-400" href="/login">Login</Link></li>
            <li><Link className="hover:text-amber-400" href="/register">Register</Link></li>
            <li><Link className="hover:text-amber-400" href="/account/orders">My Orders</Link></li>
            <li><Link className="hover:text-amber-400" href="/cart">My Cart</Link></li>
          </ul>
        </div>
        <div>
          <h3 className="font-semibold text-white text-sm uppercase tracking-wide">Information</h3>
          <ul className="mt-3 space-y-2 text-sm">
            <li><Link className="hover:text-amber-400" href="/about">About DC MALL</Link></li>
            <li><Link className="hover:text-amber-400" href="/privacy">Privacy Policy</Link></li>
            <li><Link className="hover:text-amber-400" href="/terms">Terms &amp; Conditions</Link></li>
            <li><Link className="hover:text-amber-400" href="/delivery-policy">Delivery Policy</Link></li>
            <li><Link className="hover:text-amber-400" href="/refund-policy">Refund Policy</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-slate-800 py-4 text-center text-xs text-slate-500">
        © {new Date().getFullYear()} {s.mall_name} — Your Trusted Online Shopping Mall. All prices in Ghana Cedis (₵).
      </div>
    </footer>
  );
}
