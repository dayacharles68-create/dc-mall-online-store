import Link from "next/link";
import { addToCartAction } from "@/lib/actions/cart";
import { cedis, effectivePrice } from "@/lib/utils";
import Stars from "./Stars";
import SubmitButton from "./SubmitButton";

export type ProductCardData = {
  id: number;
  name: string;
  slug: string;
  price: number;
  discountPrice: number | null;
  stock: number;
  brand: string | null;
  image: string | null;
  rating: number;
  reviewCount: number;
};

export default function ProductCard({ product, backTo = "/shop" }: { product: ProductCardData; backTo?: string }) {
  const price = effectivePrice(product);
  const hasDiscount = product.discountPrice != null && product.discountPrice < product.price;
  const pct = hasDiscount ? Math.round((1 - price / product.price) * 100) : 0;

  return (
    <div className="group flex flex-col overflow-hidden rounded-xl bg-white ring-1 ring-slate-200 hover:shadow-lg hover:ring-slate-300 transition">
      <Link href={`/product/${product.slug}`} className="relative block aspect-square overflow-hidden bg-slate-100">
        {product.image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={product.image}
            alt={product.name}
            loading="lazy"
            className="h-full w-full object-cover group-hover:scale-105 transition duration-300"
          />
        ) : (
          <span className="flex h-full items-center justify-center text-4xl text-slate-300">🛍️</span>
        )}
        {hasDiscount && (
          <span className="absolute left-2 top-2 rounded-md bg-red-600 px-1.5 py-0.5 text-[11px] font-bold text-white">-{pct}%</span>
        )}
        {product.stock < 1 && (
          <span className="absolute inset-0 flex items-center justify-center bg-white/70 text-sm font-bold text-red-600">Out of Stock</span>
        )}
      </Link>
      <div className="flex flex-1 flex-col p-3">
        {product.brand && <p className="text-[11px] uppercase tracking-wide text-slate-400">{product.brand}</p>}
        <Link href={`/product/${product.slug}`} className="line-clamp-2 text-sm font-medium text-slate-800 hover:text-slate-900 min-h-[2.5rem]">
          {product.name}
        </Link>
        <Stars rating={product.rating} count={product.reviewCount} size="text-xs" />
        <div className="mt-1 flex items-baseline gap-2">
          <span className="text-base font-bold text-slate-900">{cedis(price)}</span>
          {hasDiscount && <span className="text-xs text-slate-400 line-through">{cedis(product.price)}</span>}
        </div>
        <p className={`text-[11px] ${product.stock > 5 ? "text-emerald-600" : product.stock > 0 ? "text-amber-600" : "text-red-600"}`}>
          {product.stock > 5 ? "In stock" : product.stock > 0 ? `Only ${product.stock} left` : "Out of stock"}
        </p>
        {product.stock > 0 && (
          <div className="mt-2 grid grid-cols-2 gap-2">
            <form action={addToCartAction}>
              <input type="hidden" name="productId" value={product.id} />
              <input type="hidden" name="backTo" value={backTo} />
              <SubmitButton pendingText="…" className="w-full rounded-lg bg-slate-900 px-2 py-2 text-xs font-semibold text-white hover:bg-slate-700">
                Add to Cart
              </SubmitButton>
            </form>
            <form action={addToCartAction}>
              <input type="hidden" name="productId" value={product.id} />
              <input type="hidden" name="buyNow" value="1" />
              <input type="hidden" name="backTo" value={backTo} />
              <SubmitButton pendingText="…" className="w-full rounded-lg bg-amber-400 px-2 py-2 text-xs font-semibold text-slate-900 hover:bg-amber-300">
                Buy Now
              </SubmitButton>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
