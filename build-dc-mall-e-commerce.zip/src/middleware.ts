import { NextResponse, type NextRequest } from "next/server";

// First line of defence: unauthenticated visitors are redirected away from
// protected areas. Full role/session validation happens server-side in
// layouts and actions (requireUser / requireAdmin).
export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const hasSession = Boolean(req.cookies.get("dcm_session")?.value);

  if (pathname.startsWith("/admin")) {
    if (pathname === "/admin/login" || pathname === "/admin/setup") return NextResponse.next();
    if (!hasSession) {
      return NextResponse.redirect(new URL("/admin/login", req.url));
    }
    return NextResponse.next();
  }

  if (pathname.startsWith("/account") || pathname.startsWith("/checkout") || pathname.startsWith("/pay")) {
    if (!hasSession) {
      const login = new URL("/login", req.url);
      login.searchParams.set("next", pathname);
      return NextResponse.redirect(login);
    }
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/:path*", "/account/:path*", "/checkout", "/pay/:path*"],
};
