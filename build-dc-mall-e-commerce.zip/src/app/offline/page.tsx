export const metadata = { title: "You are offline" };

export default function OfflinePage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-slate-900 px-4 text-center text-white">
      <span className="flex h-14 w-14 items-center justify-center rounded-xl bg-amber-400 text-xl font-black text-slate-900">DC</span>
      <h1 className="mt-4 text-2xl font-bold">You&apos;re offline</h1>
      <p className="mt-2 max-w-sm text-sm text-slate-400">
        DC MALL needs an internet connection to show live products, prices and orders.
        Please check your connection and try again.
      </p>
      <a href="/" className="mt-6 rounded-lg bg-amber-400 px-6 py-3 text-sm font-bold text-slate-900">Retry</a>
    </div>
  );
}
