import { redirect } from "next/navigation";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { cartItems, products } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { effectivePrice } from "@/lib/utils";
import CheckoutForm from "@/components/CheckoutForm";

export const dynamic = "force-dynamic";
export const metadata = { title: "Checkout" };

export default async function CheckoutPage() {
  const user = await requireUser("/checkout");
  const items = await db
    .select({
      quantity: cartItems.quantity,
      product: products,
      image: sql<string | null>`(select pi.image_url from product_images pi where pi.product_id = ${products.id} order by pi.sort_order limit 1)`,
    })
    .from(cartItems)
    .innerJoin(products, eq(cartItems.productId, products.id))
    .where(eq(cartItems.userId, user.id));

  if (items.length === 0) redirect("/cart");
  const settings = await getSettings();
  const subtotal = items.reduce((s, it) => s + effectivePrice(it.product) * it.quantity, 0);

  return (
    <div className="mx-auto max-w-5xl px-4 py-6">
      <h1 className="text-xl font-bold text-slate-900 sm:text-2xl">Secure Checkout</h1>
      <p className="text-sm text-slate-500">DC MALL — Your Trusted Online Shopping Mall</p>
      <div className="mt-6">
        <CheckoutForm
          defaults={{
            name: user.name,
            phone: user.phone,
            email: user.email,
            address: user.address || "",
            city: user.city || "",
            region: user.region || "",
          }}
          items={items.map((it) => ({
            name: it.product.name,
            quantity: it.quantity,
            price: effectivePrice(it.product),
            image: it.image,
          }))}
          subtotal={subtotal}
          fees={{
            accra: Number(settings.delivery_fee_accra) || 25,
            other: Number(settings.delivery_fee_default) || 45,
          }}
          paymentNumber={settings.payment_number}
          paymentName={settings.payment_account_name}
        />
      </div>
    </div>
  );
}
