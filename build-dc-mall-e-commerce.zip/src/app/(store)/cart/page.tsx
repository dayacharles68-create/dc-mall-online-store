import Link from "next/link";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { cartItems, products } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { removeCartItemAction, setCartQtyAction } from "@/lib/actions/cart";
import { deliveryFeeFor, getSettings } from "@/lib/settings";
import { cedis, effectivePrice } from "@/lib/utils";
import SubmitButton from "@/components/SubmitButton";

export const dynamic = "force-dynamic";
export const metadata = { title: "Shopping Cart" };

export default async function CartPage() {
  const user = await getSessionUser();
  if (!user) {
    return (
      <div className="mx-auto max-w-lg px-4 py-16 text-center">
        <p className="text-5xl">🛒</p>
        <h1 className="mt-3 text-xl font-bold text-slate-900">Your Shopping Cart</h1>
        <p className="mt-2 text-sm text-slate-500">Please log in to view and manage your cart.</p>
        <div className="mt-6 flex justify-center gap-3">
          <Link href="/login?next=/cart" className="rounded-lg bg-slate-900 px-6 py-3 text-sm font-semibold text-white">Login</Link>
          <Link href="/register" className="rounded-lg bg-amber-400 px-6 py-3 text-sm font-semibold text-slate-900">Register</Link>
        </div>
      </div>
    );
  }

  const items = await db
    .select({
      id: cartItems.id,
      quantity: cartItems.quantity,
      product: products,
      image: sql<string | null>`(select pi.image_url from product_images pi where pi.product_id = ${products.id} order by pi.sort_order limit 1)`,
    })
    .from(cartItems)
    .innerJoin(products, eq(cartItems.productId, products.id))
    .where(eq(cartItems.userId, user.id))
    .orderBy(cartItems.createdAt);

  const settings = await getSettings();
  const subtotal = items.reduce((s, it) => s + effectivePrice(it.product) * it.quantity, 0);
  const estRegion = user.region || "";
  const deliveryFee = deliveryFeeFor(estRegion, settings);
  const hasIssues = items.some((it) => it.product.stock < it.quantity || it.product.status !== "active");

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-lg px-4 py-16 text-center">
        <p className="text-5xl">🛒</p>
        <h1 className="mt-3 text-xl font-bold text-slate-900">Your cart is empty</h1>
        <p className="mt-2 text-sm text-slate-500">Browse DC MALL and add products you love.</p>
        <Link href="/shop" className="mt-6 inline-block rounded-lg bg-amber-400 px-8 py-3 text-sm font-bold text-slate-900">Shop Now</Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-6">
      <h1 className="text-xl font-bold text-slate-900 sm:text-2xl">Shopping Cart ({items.length})</h1>
      <div className="mt-5 grid gap-6 lg:grid-cols-[1fr_320px]">
        <div className="space-y-3">
          {items.map((it) => {
            const price = effectivePrice(it.product);
            const problem = it.product.status !== "active"
              ? "This product is no longer available."
              : it.product.stock < 1
                ? "Out of stock."
                : it.product.stock < it.quantity
                  ? `Only ${it.product.stock} left — please reduce quantity.`
                  : null;
            return (
              <div key={it.id} className="flex gap-3 rounded-xl bg-white p-3 ring-1 ring-slate-200">
                <Link href={`/product/${it.product.slug}`} className="h-24 w-24 shrink-0 overflow-hidden rounded-lg bg-slate-100">
                  {it.image ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={it.image} alt={it.product.name} className="h-full w-full object-cover" />
                  ) : <span className="flex h-full items-center justify-center text-2xl">🛍️</span>}
                </Link>
                <div className="flex flex-1 flex-col min-w-0">
                  <Link href={`/product/${it.product.slug}`} className="text-sm font-medium text-slate-800 line-clamp-2">{it.product.name}</Link>
                  <p className="mt-0.5 text-sm font-bold text-slate-900">{cedis(price)} <span className="text-xs font-normal text-slate-400">each</span></p>
                  {problem && <p className="mt-1 text-xs font-medium text-red-600">⚠ {problem}</p>}
                  <div className="mt-auto flex items-center justify-between pt-2">
                    <div className="flex items-center rounded-lg ring-1 ring-slate-200">
                      <form action={setCartQtyAction}>
                        <input type="hidden" name="itemId" value={it.id} />
                        <input type="hidden" name="quantity" value={it.quantity - 1} />
                        <SubmitButton pendingText="·" className="px-3 py-1.5 text-slate-600 hover:bg-slate-50 font-bold">−</SubmitButton>
                      </form>
                      <span className="min-w-8 text-center text-sm font-semibold">{it.quantity}</span>
                      <form action={setCartQtyAction}>
                        <input type="hidden" name="itemId" value={it.id} />
                        <input type="hidden" name="quantity" value={it.quantity + 1} />
                        <SubmitButton pendingText="·" className="px-3 py-1.5 text-slate-600 hover:bg-slate-50 font-bold">+</SubmitButton>
                      </form>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-bold text-slate-900">{cedis(price * it.quantity)}</span>
                      <form action={removeCartItemAction}>
                        <input type="hidden" name="itemId" value={it.id} />
                        <SubmitButton pendingText="…" className="text-xs text-red-600 hover:underline">Remove</SubmitButton>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
          <Link href="/shop" className="inline-block text-sm font-semibold text-slate-600 hover:text-slate-900">← Continue Shopping</Link>
        </div>

        <aside className="h-fit rounded-xl bg-white p-5 ring-1 ring-slate-200">
          <h2 className="font-bold text-slate-900">Order Summary</h2>
          <dl className="mt-3 space-y-2 text-sm">
            <div className="flex justify-between"><dt className="text-slate-500">Subtotal</dt><dd className="font-semibold">{cedis(subtotal)}</dd></div>
            <div className="flex justify-between">
              <dt className="text-slate-500">Delivery fee {estRegion ? `(${estRegion})` : "(estimate)"}</dt>
              <dd className="font-semibold">{cedis(deliveryFee)}</dd>
            </div>
            <div className="flex justify-between border-t border-slate-100 pt-2 text-base">
              <dt className="font-bold text-slate-900">Total</dt>
              <dd className="font-extrabold text-slate-900">{cedis(subtotal + deliveryFee)}</dd>
            </div>
          </dl>
          <p className="mt-2 text-[11px] text-slate-400">Final delivery fee is confirmed at checkout based on your delivery region.</p>
          {hasIssues ? (
            <p className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-xs text-red-700">Please fix the stock issues above before checkout.</p>
          ) : (
            <Link href="/checkout" className="mt-4 block rounded-lg bg-amber-400 py-3 text-center text-sm font-bold text-slate-900 hover:bg-amber-300">
              Proceed to Checkout →
            </Link>
          )}
          <p className="mt-3 text-center text-[11px] text-slate-400">🔒 Secure checkout · Pay with Mobile Money</p>
        </aside>
      </div>
    </div>
  );
}
