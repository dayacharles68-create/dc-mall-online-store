import Link from "next/link";
import ProductCard from "@/components/ProductCard";
import { getActiveCategories, searchProducts } from "@/lib/products";

export const dynamic = "force-dynamic";

const CAT_EMOJI: [RegExp, string][] = [
  [/electronic/i, "📺"], [/phone/i, "📱"], [/computer|laptop/i, "💻"], [/fashion|cloth/i, "👗"],
  [/shoe/i, "👟"], [/beauty|cosmetic/i, "💄"], [/home|kitchen/i, "🍳"], [/grocer/i, "🛒"],
  [/baby/i, "🍼"], [/sport/i, "⚽"],
];
function catEmoji(name: string) {
  return CAT_EMOJI.find(([re]) => re.test(name))?.[1] || "🛍️";
}

export default async function HomePage() {
  const [cats, featured, deals, best] = await Promise.all([
    getActiveCategories(),
    searchProducts({ sort: "newest", pageSize: 8 }),
    searchProducts({ sort: "deals", pageSize: 4 }),
    searchProducts({ sort: "best", pageSize: 4 }),
  ]);

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-slate-900">
        <div className="absolute inset-0">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/images/hero.jpg" alt="" className="h-full w-full object-cover opacity-40" />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950/90 via-slate-900/70 to-transparent" />
        </div>
        <div className="relative mx-auto max-w-7xl px-4 py-20 sm:py-28">
          <p className="inline-flex items-center gap-2 rounded-full bg-amber-400/10 px-3 py-1 text-xs font-semibold text-amber-300 ring-1 ring-amber-400/30">
            ✓ Secure MoMo Payments · Nationwide Delivery
          </p>
          <h1 className="mt-4 max-w-2xl text-4xl font-extrabold tracking-tight text-white sm:text-6xl">
            DC MALL
          </h1>
          <p className="mt-2 max-w-xl text-lg font-medium text-amber-300 sm:text-2xl">
            Your Trusted Online Shopping Mall
          </p>
          <p className="mt-3 max-w-xl text-sm text-slate-300 sm:text-base">
            Quality electronics, fashion, beauty and home essentials delivered across Ghana.
            Shop with confidence, pay with Mobile Money and track every order to your door.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/shop" className="rounded-lg bg-amber-400 px-8 py-3.5 text-sm font-bold text-slate-900 shadow-lg hover:bg-amber-300 transition">
              Shop Now
            </Link>
            <Link href="/track" className="rounded-lg bg-white/10 px-8 py-3.5 text-sm font-semibold text-white ring-1 ring-white/30 hover:bg-white/20 transition">
              Track My Order
            </Link>
          </div>
        </div>
      </section>

      {/* Trust strip */}
      <section className="border-b border-slate-200 bg-white">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-4 px-4 py-6 text-center sm:grid-cols-4">
          {[
            ["🚚", "Nationwide Delivery", "All 16 regions of Ghana"],
            ["📱", "Mobile Money", "Safe & convenient payments"],
            ["🔒", "Secure Shopping", "Your data is protected"],
            ["📦", "Order Tracking", "Follow your order live"],
          ].map(([icon, title, sub]) => (
            <div key={title} className="flex flex-col items-center gap-1">
              <span className="text-2xl">{icon}</span>
              <p className="text-sm font-semibold text-slate-800">{title}</p>
              <p className="text-xs text-slate-500">{sub}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Categories */}
      <section className="mx-auto max-w-7xl px-4 py-10">
        <div className="flex items-end justify-between">
          <h2 className="text-xl font-bold text-slate-900 sm:text-2xl">Shop by Category</h2>
          <Link href="/shop" className="text-sm font-semibold text-slate-600 hover:text-slate-900">View all →</Link>
        </div>
        <div className="mt-5 grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-6">
          {cats.map((c) => (
            <Link
              key={c.id}
              href={`/shop?category=${c.slug}`}
              className="flex flex-col items-center gap-2 rounded-xl bg-white p-4 ring-1 ring-slate-200 hover:shadow-md hover:ring-amber-300 transition text-center"
            >
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-slate-100 text-2xl">
                {catEmoji(c.name)}
              </span>
              <span className="text-xs font-medium text-slate-700 line-clamp-2">{c.name}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Deals */}
      {deals.items.length > 0 && (
        <section className="bg-slate-900 py-10">
          <div className="mx-auto max-w-7xl px-4">
            <div className="flex items-end justify-between">
              <h2 className="text-xl font-bold text-white sm:text-2xl">🔥 Today&apos;s Deals</h2>
              <Link href="/shop?sort=deals" className="text-sm font-semibold text-amber-400 hover:text-amber-300">All deals →</Link>
            </div>
            <div className="mt-5 grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-4">
              {deals.items.map((p) => <ProductCard key={p.id} product={p} backTo="/" />)}
            </div>
          </div>
        </section>
      )}

      {/* Featured */}
      <section className="mx-auto max-w-7xl px-4 py-10">
        <div className="flex items-end justify-between">
          <h2 className="text-xl font-bold text-slate-900 sm:text-2xl">Featured Products</h2>
          <Link href="/shop" className="text-sm font-semibold text-slate-600 hover:text-slate-900">View all →</Link>
        </div>
        <div className="mt-5 grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-4">
          {featured.items.map((p) => <ProductCard key={p.id} product={p} backTo="/" />)}
        </div>
        {featured.items.length === 0 && (
          <p className="mt-6 rounded-xl bg-white p-8 text-center text-sm text-slate-500 ring-1 ring-slate-200">
            Products are being added to DC MALL. Check back soon!
          </p>
        )}
      </section>

      {/* Best sellers */}
      {best.items.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 pb-4">
          <div className="flex items-end justify-between">
            <h2 className="text-xl font-bold text-slate-900 sm:text-2xl">Best Sellers</h2>
            <Link href="/shop?sort=best" className="text-sm font-semibold text-slate-600 hover:text-slate-900">View all →</Link>
          </div>
          <div className="mt-5 grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-4">
            {best.items.map((p) => <ProductCard key={p.id} product={p} backTo="/" />)}
          </div>
        </section>
      )}
    </div>
  );
}
