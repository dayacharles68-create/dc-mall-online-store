import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { and, desc, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { categories, productImages, products, reviews, users } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { addToCartAction } from "@/lib/actions/cart";
import { cedis, effectivePrice } from "@/lib/utils";
import { productCardSelect } from "@/lib/products";
import ProductCard from "@/components/ProductCard";
import ReviewForm from "@/components/ReviewForm";
import Stars from "@/components/Stars";
import SubmitButton from "@/components/SubmitButton";

export const dynamic = "force-dynamic";

async function getProduct(slug: string) {
  const [product] = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
  return product;
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProduct(slug);
  if (!product) return { title: "Product not found" };
  return {
    title: product.seoTitle || product.name,
    description: product.seoDescription || product.description.slice(0, 160),
  };
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = await getProduct(slug);
  if (!product || product.status === "draft") notFound();

  const [images, category, reviewRows, related, user] = await Promise.all([
    db.select().from(productImages).where(eq(productImages.productId, product.id)).orderBy(productImages.sortOrder),
    product.categoryId
      ? db.select().from(categories).where(eq(categories.id, product.categoryId)).limit(1).then((r) => r[0])
      : Promise.resolve(undefined),
    db
      .select({ id: reviews.id, rating: reviews.rating, review: reviews.review, verified: reviews.verifiedPurchase, createdAt: reviews.createdAt, userName: users.name })
      .from(reviews)
      .innerJoin(users, eq(reviews.userId, users.id))
      .where(and(eq(reviews.productId, product.id), eq(reviews.status, "visible")))
      .orderBy(desc(reviews.createdAt))
      .limit(20),
    product.categoryId
      ? db.select(productCardSelect).from(products)
          .where(and(eq(products.categoryId, product.categoryId), eq(products.status, "active"), ne(products.id, product.id)))
          .limit(4)
      : Promise.resolve([]),
    getSessionUser(),
  ]);

  const price = effectivePrice(product);
  const hasDiscount = product.discountPrice != null && product.discountPrice < product.price;
  const avgRating = reviewRows.length ? reviewRows.reduce((s, r) => s + r.rating, 0) / reviewRows.length : 0;
  const available = product.status === "active" && product.stock > 0;

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.name,
    description: product.description.slice(0, 300),
    image: images.map((i) => i.imageUrl),
    brand: product.brand || undefined,
    sku: product.sku || undefined,
    offers: {
      "@type": "Offer",
      priceCurrency: "GHS",
      price: price.toFixed(2),
      availability: available ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
    },
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <nav className="text-xs text-slate-500">
        <Link href="/" className="hover:text-slate-800">Home</Link> ›{" "}
        <Link href="/shop" className="hover:text-slate-800">Shop</Link>
        {category && <> › <Link href={`/shop?category=${category.slug}`} className="hover:text-slate-800">{category.name}</Link></>}
        {" "}› <span className="text-slate-700">{product.name}</span>
      </nav>

      <div className="mt-4 grid gap-8 lg:grid-cols-2">
        {/* Images */}
        <div>
          <div className="overflow-hidden rounded-xl bg-white ring-1 ring-slate-200 aspect-square">
            {images[0] ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={images[0].imageUrl} alt={product.name} className="h-full w-full object-cover" />
            ) : (
              <span className="flex h-full items-center justify-center text-6xl text-slate-200">🛍️</span>
            )}
          </div>
          {images.length > 1 && (
            <div className="mt-3 grid grid-cols-5 gap-2">
              {images.slice(0, 5).map((img) => (
                // eslint-disable-next-line @next/next/no-img-element
                <img key={img.id} src={img.imageUrl} alt="" loading="lazy" className="aspect-square rounded-lg object-cover ring-1 ring-slate-200" />
              ))}
            </div>
          )}
        </div>

        {/* Details */}
        <div>
          {product.brand && <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">{product.brand}</p>}
          <h1 className="mt-1 text-2xl font-bold text-slate-900 sm:text-3xl">{product.name}</h1>
          <div className="mt-2 flex items-center gap-3">
            <Stars rating={avgRating} count={reviewRows.length} />
            {product.sku && <span className="text-xs text-slate-400">SKU: {product.sku}</span>}
          </div>

          <div className="mt-4 flex items-baseline gap-3">
            <span className="text-3xl font-extrabold text-slate-900">{cedis(price)}</span>
            {hasDiscount && (
              <>
                <span className="text-lg text-slate-400 line-through">{cedis(product.price)}</span>
                <span className="rounded-md bg-red-100 px-2 py-0.5 text-xs font-bold text-red-700">
                  Save {cedis(product.price - price)}
                </span>
              </>
            )}
          </div>

          <p className={`mt-2 text-sm font-medium ${available ? (product.stock > 5 ? "text-emerald-600" : "text-amber-600") : "text-red-600"}`}>
            {available ? (product.stock > 5 ? `✓ In stock (${product.stock} available)` : `⚠ Only ${product.stock} left in stock`) : "✗ Currently unavailable"}
          </p>

          {available && (
            <div className="mt-6 space-y-3">
              <form action={addToCartAction} className="flex flex-wrap items-end gap-3">
                <input type="hidden" name="productId" value={product.id} />
                <input type="hidden" name="backTo" value={`/product/${product.slug}`} />
                <label className="block">
                  <span className="text-xs font-semibold text-slate-600">Quantity</span>
                  <select name="quantity" className="mt-1 block w-24 rounded-lg border border-slate-300 px-3 py-2.5 text-sm">
                    {Array.from({ length: Math.min(10, product.stock) }, (_, i) => (
                      <option key={i + 1} value={i + 1}>{i + 1}</option>
                    ))}
                  </select>
                </label>
                <SubmitButton pendingText="Adding…" className="flex-1 min-w-[140px] rounded-lg bg-slate-900 px-6 py-3 text-sm font-bold text-white hover:bg-slate-700">
                  🛒 Add to Cart
                </SubmitButton>
              </form>
              <form action={addToCartAction}>
                <input type="hidden" name="productId" value={product.id} />
                <input type="hidden" name="buyNow" value="1" />
                <input type="hidden" name="backTo" value={`/product/${product.slug}`} />
                <SubmitButton pendingText="Processing…" className="w-full rounded-lg bg-amber-400 px-6 py-3 text-sm font-bold text-slate-900 hover:bg-amber-300">
                  ⚡ Buy Now
                </SubmitButton>
              </form>
            </div>
          )}

          <div className="mt-8">
            <h2 className="font-semibold text-slate-900">Description</h2>
            <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-slate-600">{product.description}</p>
          </div>

          {product.specifications && (
            <div className="mt-6">
              <h2 className="font-semibold text-slate-900">Specifications</h2>
              <div className="mt-2 overflow-hidden rounded-lg ring-1 ring-slate-200">
                {product.specifications.split("\n").filter(Boolean).map((line, i) => {
                  const [k, ...rest] = line.split(":");
                  return (
                    <div key={i} className={`flex text-sm ${i % 2 ? "bg-white" : "bg-slate-50"}`}>
                      <span className="w-1/3 px-3 py-2 font-medium text-slate-700">{k.trim()}</span>
                      <span className="flex-1 px-3 py-2 text-slate-600">{rest.join(":").trim()}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Reviews */}
      <section className="mt-12 grid gap-6 lg:grid-cols-2">
        <div>
          <h2 className="text-lg font-bold text-slate-900">Customer Reviews ({reviewRows.length})</h2>
          <div className="mt-4 space-y-4">
            {reviewRows.length === 0 && <p className="text-sm text-slate-500">No reviews yet. Be the first to review this product.</p>}
            {reviewRows.map((r) => (
              <div key={r.id} className="rounded-xl bg-white p-4 ring-1 ring-slate-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-slate-800">{r.userName}</span>
                    {r.verified && <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-semibold text-emerald-700 ring-1 ring-emerald-200">✓ Verified Purchase</span>}
                  </div>
                  <Stars rating={r.rating} size="text-xs" />
                </div>
                {r.review && <p className="mt-2 text-sm text-slate-600">{r.review}</p>}
              </div>
            ))}
          </div>
        </div>
        <div>
          <h2 className="text-lg font-bold text-slate-900">Leave a Review</h2>
          <div className="mt-4">
            <ReviewForm productId={product.id} slug={product.slug} loggedIn={!!user} />
          </div>
        </div>
      </section>

      {/* Related */}
      {related.length > 0 && (
        <section className="mt-12">
          <h2 className="text-lg font-bold text-slate-900">Related Products</h2>
          <div className="mt-4 grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-4">
            {related.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </section>
      )}
    </div>
  );
}
