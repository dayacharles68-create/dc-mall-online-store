import Link from "next/link";
import { ForgotForm } from "@/components/AuthForms";

export const metadata = { title: "Forgot Password" };

export default function ForgotPasswordPage() {
  return (
    <div className="mx-auto max-w-md px-4 py-12">
      <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200 sm:p-8">
        <h1 className="text-xl font-bold text-slate-900">Forgot your password?</h1>
        <p className="mt-1 text-sm text-slate-500">
          Enter your email and we&apos;ll send you a secure link to reset your password.
        </p>
        <div className="mt-6"><ForgotForm /></div>
        <p className="mt-5 text-center text-sm text-slate-500">
          <Link href="/login" className="font-semibold text-slate-900 hover:underline">← Back to login</Link>
        </p>
      </div>
    </div>
  );
}
