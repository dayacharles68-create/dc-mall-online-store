import { trackOrderLookup } from "@/lib/actions/admin";
import { cedis, ORDER_STATUS_COLORS, ORDER_STATUS_LABELS, PAYMENT_STATUS_COLORS, PAYMENT_STATUS_LABELS, shortDate } from "@/lib/utils";
import Timeline from "@/components/Timeline";

export const dynamic = "force-dynamic";
export const metadata = { title: "Track My Order", description: "Track your DC MALL order status in real time." };

export default async function TrackPage({
  searchParams,
}: {
  searchParams: Promise<{ order?: string; contact?: string }>;
}) {
  const sp = await searchParams;
  const orderNumber = (sp.order || "").trim();
  const contact = (sp.contact || "").trim();
  const result = orderNumber && contact ? await trackOrderLookup(orderNumber, contact) : null;
  const attempted = Boolean(orderNumber && contact);

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <div className="text-center">
        <h1 className="text-2xl font-bold text-slate-900">Track My Order</h1>
        <p className="mt-1 text-sm text-slate-500">Enter your order number and the phone or email used at checkout.</p>
      </div>

      <form method="GET" className="mt-6 grid gap-3 rounded-xl bg-white p-5 ring-1 ring-slate-200 sm:grid-cols-[1fr_1fr_auto]">
        <input
          name="order"
          defaultValue={orderNumber}
          required
          placeholder="Order number, e.g. DCM-20260903-0001"
          className="rounded-lg border border-slate-300 px-3 py-2.5 text-sm focus:border-slate-500 outline-none"
        />
        <input
          name="contact"
          defaultValue={contact}
          required
          placeholder="Phone or email used at checkout"
          className="rounded-lg border border-slate-300 px-3 py-2.5 text-sm focus:border-slate-500 outline-none"
        />
        <button className="rounded-lg bg-amber-400 px-6 py-2.5 text-sm font-bold text-slate-900 hover:bg-amber-300">Track</button>
      </form>

      {attempted && !result && (
        <div className="mt-6 rounded-xl bg-red-50 p-5 text-center ring-1 ring-red-100">
          <p className="font-semibold text-red-700">Order not found</p>
          <p className="mt-1 text-sm text-red-600">
            We couldn&apos;t match that order number with the phone/email provided. Please check your details and try again.
          </p>
        </div>
      )}

      {result && (
        <div className="mt-6 space-y-4">
          <div className="rounded-xl bg-white p-5 ring-1 ring-slate-200">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="text-xs text-slate-500">Order</p>
                <p className="text-lg font-extrabold text-slate-900">{result.order.orderNumber}</p>
                <p className="text-xs text-slate-500">Placed {shortDate(result.order.createdAt)} · {cedis(result.order.total)}</p>
              </div>
              <div className="flex flex-col items-end gap-1.5">
                <span className={`rounded-full px-3 py-1 text-xs font-bold ${ORDER_STATUS_COLORS[result.order.orderStatus]}`}>
                  {ORDER_STATUS_LABELS[result.order.orderStatus]}
                </span>
                <span className={`rounded-full px-3 py-1 text-xs font-semibold ${PAYMENT_STATUS_COLORS[result.order.paymentStatus]}`}>
                  {PAYMENT_STATUS_LABELS[result.order.paymentStatus]}
                </span>
              </div>
            </div>
            {result.order.trackingNumber && (
              <p className="mt-2 text-xs text-slate-500">Courier tracking number: <b>{result.order.trackingNumber}</b></p>
            )}
            <ul className="mt-3 border-t border-slate-100 pt-3 text-sm text-slate-600">
              {result.items.map((it) => (
                <li key={it.id}>{it.quantity} × {it.productName}</li>
              ))}
            </ul>
          </div>
          <div className="rounded-xl bg-white p-5 ring-1 ring-slate-200">
            <h2 className="mb-4 font-bold text-slate-900">Delivery Progress</h2>
            <Timeline
              orderStatus={result.order.orderStatus}
              paymentStatus={result.order.paymentStatus}
              events={result.events}
            />
          </div>
        </div>
      )}
    </div>
  );
}
