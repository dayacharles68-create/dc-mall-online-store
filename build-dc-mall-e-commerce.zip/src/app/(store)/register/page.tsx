import Link from "next/link";
import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { RegisterForm } from "@/components/AuthForms";

export const metadata = { title: "Create Account" };

export default async function RegisterPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string }>;
}) {
  const sp = await searchParams;
  const user = await getSessionUser();
  if (user) redirect(sp.next || "/account");

  return (
    <div className="mx-auto max-w-xl px-4 py-12">
      <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200 sm:p-8">
        <h1 className="text-xl font-bold text-slate-900">Create your DC MALL account</h1>
        <p className="mt-1 text-sm text-slate-500">Join Ghana&apos;s trusted online shopping mall. It&apos;s free.</p>
        <div className="mt-6">
          <RegisterForm next={sp.next} />
        </div>
        <p className="mt-5 text-center text-sm text-slate-500">
          Already have an account?{" "}
          <Link href="/login" className="font-semibold text-slate-900 hover:underline">Login</Link>
        </p>
      </div>
    </div>
  );
}
