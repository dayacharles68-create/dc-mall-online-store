import { notFound } from "next/navigation";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

const PAGES: Record<string, { title: string; body: string[] }> = {
  about: {
    title: "About DC MALL",
    body: [
      "DC MALL is Ghana's trusted online shopping mall, bringing quality electronics, phones, computers, fashion, beauty, home & kitchen essentials, groceries and more to customers in all 16 regions.",
      "We combine secure Mobile Money payments, verified sellers and reliable nationwide delivery so you can shop with total confidence — from Accra to Tamale.",
      "Every order is tracked from the moment it is placed until it arrives at your doorstep, and every payment is verified before your order is processed.",
    ],
  },
  privacy: {
    title: "Privacy Policy",
    body: [
      "DC MALL collects only the information needed to process your orders: your name, contact details and delivery address. We never sell your personal data to third parties.",
      "Passwords are stored using strong one-way cryptographic hashing. We never store Mobile Money PINs and we will never ask for your PIN — payments are always authorized on your own phone.",
      "You may request the deletion of your account and personal data at any time by contacting our support team.",
    ],
  },
  terms: {
    title: "Terms & Conditions",
    body: [
      "By using DC MALL you agree to provide accurate account and delivery information and to use the platform lawfully.",
      "Orders are confirmed only after payment has been verified through our payment provider or by the DC MALL payments team. Prices are displayed in Ghana Cedis (GHS ₵) and include applicable charges except delivery fees, which are shown at checkout.",
      "DC MALL reserves the right to cancel orders where stock is unavailable or payment cannot be verified. In such cases any amount received is fully refunded.",
    ],
  },
  "delivery-policy": {
    title: "Delivery Policy",
    body: [
      "We deliver to all 16 regions of Ghana. Orders within Greater Accra typically arrive within 1–3 working days; other regions within 2–5 working days.",
      "Delivery fees depend on your region and are shown clearly before you place your order. Your order can be tracked at any time on the Track My Order page.",
      "Please ensure someone is available at the delivery address and that the delivery phone number is reachable.",
    ],
  },
  "refund-policy": {
    title: "Refund Policy",
    body: [
      "If your order is cancelled before shipment, or an item is unavailable, you will receive a full refund to your Mobile Money account within 3–5 working days.",
      "Damaged or wrong items must be reported within 48 hours of delivery with photos. Once approved, we will replace the item or refund your payment.",
      "Refunds are always sent to the same Mobile Money number that made the payment.",
    ],
  },
  returns: {
    title: "Returns",
    body: [
      "Items can be returned within 7 days of delivery if unused and in their original packaging.",
      "To start a return, contact DC MALL support with your order number and reason for return. Our team will arrange pickup or advise the nearest drop-off point.",
      "Once the returned item is inspected, your refund or replacement is processed within 3–5 working days.",
    ],
  },
  faqs: {
    title: "Frequently Asked Questions",
    body: [
      "How do I pay? — We accept Mobile Money (MTN MoMo, Telecel Cash, AT Money) sent to the official DC MALL payment account, and instant gateway payments where available. Never share your MoMo PIN.",
      "How long does delivery take? — 1–3 working days in Greater Accra, 2–5 working days elsewhere in Ghana.",
      "How do I track my order? — Use the Track My Order page with your order number and the phone/email used at checkout, or view it in your account dashboard.",
      "Is my payment safe? — Yes. Every payment is verified against the provider record before your order is processed, and your money is refunded in full if an order cannot be fulfilled.",
    ],
  },
};

export default async function InfoPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;

  if (slug === "contact") {
    const s = await getSettings();
    return (
      <div className="mx-auto max-w-2xl px-4 py-12">
        <h1 className="text-2xl font-bold text-slate-900">Contact Us</h1>
        <p className="mt-2 text-sm text-slate-500">We&apos;re here to help, 7 days a week.</p>
        <div className="mt-6 space-y-3">
          <div className="rounded-xl bg-white p-5 ring-1 ring-slate-200"><p className="text-xs uppercase tracking-wide text-slate-400">Phone / WhatsApp</p><p className="mt-1 text-lg font-bold text-slate-900">{s.contact_phone}</p></div>
          <div className="rounded-xl bg-white p-5 ring-1 ring-slate-200"><p className="text-xs uppercase tracking-wide text-slate-400">Email</p><p className="mt-1 text-lg font-bold text-slate-900">{s.contact_email}</p></div>
          <div className="rounded-xl bg-white p-5 ring-1 ring-slate-200"><p className="text-xs uppercase tracking-wide text-slate-400">Address</p><p className="mt-1 text-lg font-bold text-slate-900">{s.business_address}</p></div>
          <div className="rounded-xl bg-slate-900 p-5 text-white"><p className="text-xs uppercase tracking-wide text-slate-400">Official MoMo payment account</p><p className="mt-1 text-lg font-bold text-amber-400">{s.payment_number}</p><p className="text-xs text-slate-400">Account name: {s.payment_account_name}. This is the ONLY number to pay for DC MALL orders.</p></div>
        </div>
      </div>
    );
  }

  const page = PAGES[slug];
  if (!page) notFound();
  return (
    <div className="mx-auto max-w-2xl px-4 py-12">
      <h1 className="text-2xl font-bold text-slate-900">{page.title}</h1>
      <p className="text-xs text-slate-400">DC MALL — Your Trusted Online Shopping Mall</p>
      <div className="mt-6 space-y-4">
        {page.body.map((p, i) => (
          <p key={i} className="text-sm leading-relaxed text-slate-600">{p}</p>
        ))}
      </div>
    </div>
  );
}
