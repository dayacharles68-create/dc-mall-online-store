import Link from "next/link";
import { notFound } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { orderItems, orders, orderTracking, payments } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import Timeline from "@/components/Timeline";
import { cedis, formatDate, ORDER_STATUS_COLORS, ORDER_STATUS_LABELS, PAYMENT_STATUS_COLORS, PAYMENT_STATUS_LABELS } from "@/lib/utils";

export const dynamic = "force-dynamic";
export const metadata = { title: "Order Details" };

export default async function OrderDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await requireUser("/account/orders");
  const [order] = await db
    .select()
    .from(orders)
    .where(and(eq(orders.id, Number(id) || 0), eq(orders.userId, user.id)))
    .limit(1);
  if (!order) notFound();

  const [items, events, payment] = await Promise.all([
    db.select().from(orderItems).where(eq(orderItems.orderId, order.id)),
    db.select().from(orderTracking).where(eq(orderTracking.orderId, order.id)).orderBy(orderTracking.createdAt),
    db.select().from(payments).where(eq(payments.orderId, order.id)).limit(1).then((r) => r[0]),
  ]);

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <Link href="/account/orders" className="text-sm font-semibold text-slate-600 hover:text-slate-900">← Back to My Orders</Link>
      <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">{order.orderNumber}</h1>
          <p className="text-sm text-slate-500">Placed {formatDate(order.createdAt)}</p>
        </div>
        <div className="flex gap-2">
          <span className={`rounded-full px-3 py-1.5 text-xs font-bold ${PAYMENT_STATUS_COLORS[order.paymentStatus]}`}>{PAYMENT_STATUS_LABELS[order.paymentStatus]}</span>
          <span className={`rounded-full px-3 py-1.5 text-xs font-bold ${ORDER_STATUS_COLORS[order.orderStatus]}`}>{ORDER_STATUS_LABELS[order.orderStatus]}</span>
        </div>
      </div>

      {order.paymentStatus === "pending" && (
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-xl bg-amber-50 p-4 ring-1 ring-amber-200">
          <p className="text-sm text-amber-800">⚠ This order is awaiting payment. Complete payment to begin processing.</p>
          <Link href={`/pay/${order.orderNumber}`} className="rounded-lg bg-amber-400 px-5 py-2.5 text-sm font-bold text-slate-900">Complete Payment</Link>
        </div>
      )}

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <div className="space-y-4">
          <section className="rounded-xl bg-white p-5 ring-1 ring-slate-200">
            <h2 className="font-bold text-slate-900">Items</h2>
            <ul className="mt-3 divide-y divide-slate-100">
              {items.map((it) => (
                <li key={it.id} className="flex items-center gap-3 py-2.5">
                  {it.productImage ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={it.productImage} alt="" className="h-12 w-12 rounded-lg object-cover" />
                  ) : <span className="flex h-12 w-12 items-center justify-center rounded-lg bg-slate-100">🛍️</span>}
                  <div className="flex-1 min-w-0">
                    <p className="truncate text-sm font-medium text-slate-800">{it.productName}</p>
                    <p className="text-xs text-slate-500">{it.quantity} × {cedis(it.price)}</p>
                  </div>
                  <span className="text-sm font-bold">{cedis(it.price * it.quantity)}</span>
                </li>
              ))}
            </ul>
            <dl className="mt-2 space-y-1 border-t border-slate-100 pt-3 text-sm">
              <div className="flex justify-between"><dt className="text-slate-500">Subtotal</dt><dd>{cedis(order.subtotal)}</dd></div>
              <div className="flex justify-between"><dt className="text-slate-500">Delivery fee</dt><dd>{cedis(order.deliveryFee)}</dd></div>
              <div className="flex justify-between text-base font-extrabold"><dt>Total</dt><dd>{cedis(order.total)}</dd></div>
            </dl>
          </section>

          <section className="rounded-xl bg-white p-5 ring-1 ring-slate-200 text-sm">
            <h2 className="font-bold text-slate-900">Delivery Information</h2>
            <p className="mt-2 text-slate-600">{order.deliveryName} · {order.deliveryPhone}</p>
            <p className="text-slate-600">{order.deliveryAddress}, {order.city}, {order.region}</p>
            {order.instructions && <p className="mt-1 text-xs text-slate-500">Instructions: {order.instructions}</p>}
            {order.trackingNumber && <p className="mt-2 text-xs text-slate-500">Courier tracking #: <b>{order.trackingNumber}</b></p>}
          </section>

          {payment && (
            <section className="rounded-xl bg-white p-5 ring-1 ring-slate-200 text-sm">
              <h2 className="font-bold text-slate-900">Payment</h2>
              <dl className="mt-2 space-y-1 text-slate-600">
                <div className="flex justify-between"><dt>Method</dt><dd className="font-medium">{payment.paymentMethod === "paystack" ? "Paystack" : "Mobile Money (MoMo)"}</dd></div>
                <div className="flex justify-between"><dt>Amount</dt><dd className="font-medium">{cedis(payment.amount)}</dd></div>
                {payment.paymentReference && <div className="flex justify-between"><dt>Your reference</dt><dd className="font-medium">{payment.paymentReference}</dd></div>}
                {payment.transactionId && <div className="flex justify-between"><dt>Transaction ID</dt><dd className="font-medium">{payment.transactionId}</dd></div>}
                <div className="flex justify-between"><dt>Status</dt><dd className="font-medium">{PAYMENT_STATUS_LABELS[payment.paymentStatus]}</dd></div>
              </dl>
            </section>
          )}
        </div>

        <section className="rounded-xl bg-white p-5 ring-1 ring-slate-200 h-fit">
          <h2 className="mb-4 font-bold text-slate-900">Order Tracking</h2>
          <Timeline orderStatus={order.orderStatus} paymentStatus={order.paymentStatus} events={events} />
        </section>
      </div>
    </div>
  );
}
