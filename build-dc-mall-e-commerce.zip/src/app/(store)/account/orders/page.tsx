import Link from "next/link";
import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { orderItems, orders } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { cedis, ORDER_STATUS_COLORS, ORDER_STATUS_LABELS, PAYMENT_STATUS_COLORS, PAYMENT_STATUS_LABELS, shortDate } from "@/lib/utils";

export const dynamic = "force-dynamic";
export const metadata = { title: "My Orders" };

export default async function OrdersPage() {
  const user = await requireUser("/account/orders");
  const rows = await db
    .select({
      order: orders,
      itemCount: sql<number>`(select coalesce(sum(quantity),0) from ${orderItems} where ${orderItems.orderId} = ${orders.id})::int`,
    })
    .from(orders)
    .where(eq(orders.userId, user.id))
    .orderBy(desc(orders.createdAt))
    .limit(100);

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <h1 className="text-2xl font-bold text-slate-900">My Orders</h1>
      <p className="text-sm text-slate-500">All orders you have placed with DC MALL.</p>
      {rows.length === 0 ? (
        <div className="mt-8 rounded-xl bg-white p-10 text-center ring-1 ring-slate-200">
          <p className="text-4xl">📦</p>
          <p className="mt-2 text-sm text-slate-500">No orders yet.</p>
          <Link href="/shop" className="mt-4 inline-block rounded-lg bg-amber-400 px-6 py-2.5 text-sm font-bold text-slate-900">Shop Now</Link>
        </div>
      ) : (
        <div className="mt-6 space-y-3">
          {rows.map(({ order: o, itemCount }) => (
            <div key={o.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-white p-4 ring-1 ring-slate-200">
              <div>
                <p className="font-bold text-slate-900">{o.orderNumber}</p>
                <p className="text-xs text-slate-500">{shortDate(o.createdAt)} · {itemCount} item{itemCount === 1 ? "" : "s"} · <b>{cedis(o.total)}</b></p>
                <div className="mt-1.5 flex gap-2">
                  <span className={`rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${PAYMENT_STATUS_COLORS[o.paymentStatus]}`}>{PAYMENT_STATUS_LABELS[o.paymentStatus]}</span>
                  <span className={`rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${ORDER_STATUS_COLORS[o.orderStatus]}`}>{ORDER_STATUS_LABELS[o.orderStatus]}</span>
                </div>
              </div>
              <div className="flex gap-2">
                {o.paymentStatus === "pending" && (
                  <Link href={`/pay/${o.orderNumber}`} className="rounded-lg bg-amber-400 px-4 py-2 text-xs font-bold text-slate-900">Pay Now</Link>
                )}
                <Link href={`/account/orders/${o.id}`} className="rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white">View / Track</Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
