import Link from "next/link";
import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { notifications, orders } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { logoutAction } from "@/lib/actions/auth";
import { ProfileForm } from "@/components/AuthForms";
import { cedis, formatDate, ORDER_STATUS_COLORS, ORDER_STATUS_LABELS, PAYMENT_STATUS_COLORS, PAYMENT_STATUS_LABELS, shortDate } from "@/lib/utils";

export const dynamic = "force-dynamic";
export const metadata = { title: "My Account" };

export default async function AccountPage() {
  const user = await requireUser("/account");
  const [recentOrders, notes, stats] = await Promise.all([
    db.select().from(orders).where(eq(orders.userId, user.id)).orderBy(desc(orders.createdAt)).limit(5),
    db.select().from(notifications).where(eq(notifications.userId, user.id)).orderBy(desc(notifications.createdAt)).limit(8),
    db
      .select({
        total: sql<number>`count(*)::int`,
        active: sql<number>`count(*) filter (where order_status not in ('delivered','cancelled','refunded'))::int`,
        spent: sql<number>`coalesce(sum(total) filter (where payment_status = 'paid'), 0)::float`,
      })
      .from(orders)
      .where(eq(orders.userId, user.id))
      .then((r) => r[0]),
  ]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Hello, {user.name.split(" ")[0]} 👋</h1>
          <p className="text-sm text-slate-500">{user.email} · {user.phone}</p>
        </div>
        <form action={logoutAction}>
          <button className="rounded-lg bg-white px-4 py-2 text-sm font-semibold text-red-600 ring-1 ring-slate-200 hover:bg-red-50">Logout</button>
        </form>
      </div>

      <div className="mt-6 grid grid-cols-3 gap-3">
        {[
          ["Total orders", String(stats.total)],
          ["Active orders", String(stats.active)],
          ["Total purchases", cedis(stats.spent)],
        ].map(([label, value]) => (
          <div key={label} className="rounded-xl bg-white p-4 text-center ring-1 ring-slate-200">
            <p className="text-lg font-extrabold text-slate-900">{value}</p>
            <p className="text-xs text-slate-500">{label}</p>
          </div>
        ))}
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_360px]">
        <div className="space-y-6">
          <section className="rounded-xl bg-white p-5 ring-1 ring-slate-200">
            <div className="flex items-center justify-between">
              <h2 className="font-bold text-slate-900">Recent Orders</h2>
              <Link href="/account/orders" className="text-sm font-semibold text-slate-600 hover:text-slate-900">View all →</Link>
            </div>
            {recentOrders.length === 0 ? (
              <div className="mt-4 rounded-lg bg-slate-50 p-6 text-center">
                <p className="text-sm text-slate-500">You haven&apos;t placed any orders yet.</p>
                <Link href="/shop" className="mt-3 inline-block rounded-lg bg-amber-400 px-5 py-2.5 text-sm font-bold text-slate-900">Start Shopping</Link>
              </div>
            ) : (
              <ul className="mt-3 divide-y divide-slate-100">
                {recentOrders.map((o) => (
                  <li key={o.id} className="flex flex-wrap items-center justify-between gap-2 py-3">
                    <div>
                      <Link href={`/account/orders/${o.id}`} className="text-sm font-bold text-slate-900 hover:underline">{o.orderNumber}</Link>
                      <p className="text-xs text-slate-500">{shortDate(o.createdAt)} · {cedis(o.total)}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`rounded-full px-2.5 py-1 text-[11px] font-semibold ${PAYMENT_STATUS_COLORS[o.paymentStatus]}`}>{PAYMENT_STATUS_LABELS[o.paymentStatus]}</span>
                      <span className={`rounded-full px-2.5 py-1 text-[11px] font-semibold ${ORDER_STATUS_COLORS[o.orderStatus]}`}>{ORDER_STATUS_LABELS[o.orderStatus]}</span>
                      <Link href={`/account/orders/${o.id}`} className="rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-semibold text-white">Track</Link>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="rounded-xl bg-white p-5 ring-1 ring-slate-200">
            <h2 className="font-bold text-slate-900">Notifications</h2>
            {notes.length === 0 ? (
              <p className="mt-3 text-sm text-slate-500">No notifications yet.</p>
            ) : (
              <ul className="mt-3 space-y-2">
                {notes.map((n) => (
                  <li key={n.id} className="rounded-lg bg-slate-50 px-3 py-2.5 ring-1 ring-slate-100">
                    <p className="text-sm font-semibold text-slate-800">{n.title}</p>
                    <p className="text-xs text-slate-600">{n.message}</p>
                    <p className="mt-0.5 text-[10px] text-slate-400">{formatDate(n.createdAt)}</p>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>

        <aside className="space-y-6">
          <section className="rounded-xl bg-white p-5 ring-1 ring-slate-200">
            <h2 className="font-bold text-slate-900">Profile & Delivery Address</h2>
            <div className="mt-3">
              <ProfileForm defaults={{ name: user.name, phone: user.phone, address: user.address || "", city: user.city || "", region: user.region || "" }} />
            </div>
          </section>
          <section className="rounded-xl bg-white p-5 ring-1 ring-slate-200 text-sm space-y-2">
            <h2 className="font-bold text-slate-900">Quick Links</h2>
            <Link href="/cart" className="block rounded-lg bg-slate-50 px-3 py-2.5 font-medium text-slate-700 hover:bg-slate-100">🛒 My Cart</Link>
            <Link href="/account/orders" className="block rounded-lg bg-slate-50 px-3 py-2.5 font-medium text-slate-700 hover:bg-slate-100">📦 Order History</Link>
            <Link href="/track" className="block rounded-lg bg-slate-50 px-3 py-2.5 font-medium text-slate-700 hover:bg-slate-100">🚚 Track an Order</Link>
            <Link href="/shop" className="block rounded-lg bg-slate-50 px-3 py-2.5 font-medium text-slate-700 hover:bg-slate-100">🛍️ Continue Shopping</Link>
          </section>
        </aside>
      </div>
    </div>
  );
}
