import Link from "next/link";
import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { LoginForm } from "@/components/AuthForms";

export const metadata = { title: "Login" };

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string; msg?: string }>;
}) {
  const sp = await searchParams;
  const user = await getSessionUser();
  if (user) redirect(sp.next || "/account");

  return (
    <div className="mx-auto max-w-md px-4 py-12">
      <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200 sm:p-8">
        <h1 className="text-xl font-bold text-slate-900">Welcome back to DC MALL</h1>
        <p className="mt-1 text-sm text-slate-500">Log in to shop, view your orders and track deliveries.</p>
        {sp.msg === "login-to-shop" && (
          <p className="mt-3 rounded-lg bg-amber-50 px-3 py-2 text-sm text-amber-800 ring-1 ring-amber-200">
            Please log in or create a free account to add items to your cart.
          </p>
        )}
        <div className="mt-6">
          <LoginForm next={sp.next} />
        </div>
        <p className="mt-5 text-center text-sm text-slate-500">
          New to DC MALL?{" "}
          <Link href={`/register${sp.next ? `?next=${encodeURIComponent(sp.next)}` : ""}`} className="font-semibold text-slate-900 hover:underline">
            Create an account
          </Link>
        </p>
      </div>
    </div>
  );
}
