import Link from "next/link";
import type { Metadata } from "next";
import ProductCard from "@/components/ProductCard";
import { getActiveCategories, searchProducts } from "@/lib/products";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Shop All Products",
  description: "Browse and search all products at DC MALL — Ghana's trusted online shopping mall.",
};

type SP = { [key: string]: string | string[] | undefined };
const str = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) || "";

export default async function ShopPage({ searchParams }: { searchParams: Promise<SP> }) {
  const sp = await searchParams;
  const q = str(sp.q);
  const category = str(sp.category);
  const sort = str(sp.sort) || "newest";
  const minPrice = str(sp.min) ? Number(str(sp.min)) : undefined;
  const maxPrice = str(sp.max) ? Number(str(sp.max)) : undefined;
  const inStock = str(sp.stock) === "1";
  const minRating = str(sp.rating) ? Number(str(sp.rating)) : undefined;
  const page = Math.max(1, Number(str(sp.page)) || 1);

  const [cats, result] = await Promise.all([
    getActiveCategories(),
    searchProducts({ q, category, sort, minPrice, maxPrice, inStock, minRating, page, pageSize: 12 }),
  ]);
  const totalPages = Math.max(1, Math.ceil(result.total / result.pageSize));
  const activeCat = cats.find((c) => c.slug === category);

  const qs = (overrides: Record<string, string | number | undefined>) => {
    const params = new URLSearchParams();
    const all: Record<string, string> = { q, category, sort, min: str(sp.min), max: str(sp.max), stock: str(sp.stock), rating: str(sp.rating) };
    for (const [k, v] of Object.entries({ ...all, ...overrides })) {
      if (v !== undefined && v !== "") params.set(k, String(v));
    }
    return `/shop?${params.toString()}`;
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 sm:text-2xl">
            {activeCat ? activeCat.name : q ? `Search: “${q}”` : sort === "deals" ? "Today's Deals" : "Shop All Products"}
          </h1>
          <p className="text-sm text-slate-500">{result.total} product{result.total === 1 ? "" : "s"} found</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500">Sort:</span>
          {[
            ["newest", "Newest"], ["best", "Best Selling"], ["price-asc", "Price ↑"],
            ["price-desc", "Price ↓"], ["rating", "Top Rated"], ["deals", "Deals"],
          ].map(([val, label]) => (
            <Link key={val} href={qs({ sort: val, page: undefined })}
              className={`rounded-full px-3 py-1.5 text-xs font-medium ring-1 transition ${sort === val ? "bg-slate-900 text-white ring-slate-900" : "bg-white text-slate-600 ring-slate-200 hover:ring-slate-400"}`}>
              {label}
            </Link>
          ))}
        </div>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[240px_1fr]">
        {/* Filters */}
        <aside className="rounded-xl bg-white p-4 ring-1 ring-slate-200 h-fit">
          <h2 className="text-sm font-bold text-slate-900">Filters</h2>
          <form className="mt-3 space-y-4" action="/shop" method="GET">
            {q && <input type="hidden" name="q" value={q} />}
            {sort && <input type="hidden" name="sort" value={sort} />}
            <div>
              <label className="text-xs font-semibold text-slate-600">Category</label>
              <select name="category" defaultValue={category} className="mt-1 w-full rounded-lg border border-slate-200 px-2 py-2 text-sm">
                <option value="">All categories</option>
                {cats.map((c) => <option key={c.id} value={c.slug}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-600">Price range (₵)</label>
              <div className="mt-1 flex gap-2">
                <input name="min" type="number" min={0} placeholder="Min" defaultValue={str(sp.min)} className="w-1/2 rounded-lg border border-slate-200 px-2 py-2 text-sm" />
                <input name="max" type="number" min={0} placeholder="Max" defaultValue={str(sp.max)} className="w-1/2 rounded-lg border border-slate-200 px-2 py-2 text-sm" />
              </div>
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-600">Minimum rating</label>
              <select name="rating" defaultValue={str(sp.rating)} className="mt-1 w-full rounded-lg border border-slate-200 px-2 py-2 text-sm">
                <option value="">Any rating</option>
                <option value="4">4★ & above</option>
                <option value="3">3★ & above</option>
              </select>
            </div>
            <label className="flex items-center gap-2 text-sm text-slate-700">
              <input type="checkbox" name="stock" value="1" defaultChecked={inStock} className="rounded" />
              In stock only
            </label>
            <button type="submit" className="w-full rounded-lg bg-slate-900 py-2.5 text-sm font-semibold text-white hover:bg-slate-700">
              Apply Filters
            </button>
            <Link href="/shop" className="block text-center text-xs text-slate-500 hover:text-slate-800">Clear all</Link>
          </form>
        </aside>

        {/* Grid */}
        <div>
          {result.items.length === 0 ? (
            <div className="rounded-xl bg-white p-12 text-center ring-1 ring-slate-200">
              <p className="text-4xl">🔍</p>
              <h3 className="mt-2 font-semibold text-slate-800">No products found</h3>
              <p className="mt-1 text-sm text-slate-500">Try adjusting your search or filters.</p>
              <Link href="/shop" className="mt-4 inline-block rounded-lg bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white">Browse all products</Link>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3 xl:grid-cols-4">
              {result.items.map((p) => <ProductCard key={p.id} product={p} backTo="/shop" />)}
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="mt-8 flex items-center justify-center gap-2">
              {page > 1 && <Link href={qs({ page: page - 1 })} className="rounded-lg bg-white px-4 py-2 text-sm ring-1 ring-slate-200 hover:ring-slate-400">← Prev</Link>}
              <span className="text-sm text-slate-600">Page {page} of {totalPages}</span>
              {page < totalPages && <Link href={qs({ page: page + 1 })} className="rounded-lg bg-white px-4 py-2 text-sm ring-1 ring-slate-200 hover:ring-slate-400">Next →</Link>}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
