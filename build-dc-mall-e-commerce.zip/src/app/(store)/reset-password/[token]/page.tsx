import { ResetForm } from "@/components/AuthForms";

export const metadata = { title: "Reset Password" };

export default async function ResetPasswordPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  return (
    <div className="mx-auto max-w-md px-4 py-12">
      <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200 sm:p-8">
        <h1 className="text-xl font-bold text-slate-900">Set a new password</h1>
        <p className="mt-1 text-sm text-slate-500">Choose a strong password for your DC MALL account.</p>
        <div className="mt-6"><ResetForm token={token} /></div>
      </div>
    </div>
  );
}
