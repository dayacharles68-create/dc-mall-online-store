import Link from "next/link";
import { notFound } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { orderItems, orders } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { cedis, PAYMENT_STATUS_COLORS, PAYMENT_STATUS_LABELS, shortDate } from "@/lib/utils";
import PaymentPanel from "@/components/PaymentPanel";

export const dynamic = "force-dynamic";
export const metadata = { title: "Complete Payment" };

export default async function PayPage({ params }: { params: Promise<{ orderNumber: string }> }) {
  const { orderNumber } = await params;
  const user = await requireUser(`/pay/${orderNumber}`);
  const [order] = await db
    .select()
    .from(orders)
    .where(and(eq(orders.orderNumber, orderNumber.toUpperCase()), eq(orders.userId, user.id)))
    .limit(1);
  if (!order) notFound();

  const [items, settings] = await Promise.all([
    db.select().from(orderItems).where(eq(orderItems.orderId, order.id)),
    getSettings(),
  ]);
  const paystackEnabled = !!process.env.PAYSTACK_SECRET_KEY;

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <div className="rounded-xl bg-emerald-50 p-4 text-center ring-1 ring-emerald-200">
        <p className="text-3xl">🎉</p>
        <h1 className="mt-1 text-lg font-bold text-slate-900">Order placed successfully!</h1>
        <p className="text-sm text-slate-600">Your order number is</p>
        <p className="mt-1 text-2xl font-extrabold tracking-wide text-slate-900">{order.orderNumber}</p>
        <p className="mt-1 text-xs text-slate-500">Placed on {shortDate(order.createdAt)} · Expected delivery: 1–3 working days (Greater Accra) or 2–5 working days (other regions)</p>
      </div>

      <div className="mt-6 grid gap-6 md:grid-cols-2">
        <div className="rounded-xl bg-white p-5 ring-1 ring-slate-200">
          <h2 className="font-bold text-slate-900">Order Summary</h2>
          <ul className="mt-3 space-y-2 text-sm">
            {items.map((it) => (
              <li key={it.id} className="flex justify-between gap-2">
                <span className="text-slate-600">{it.quantity} × {it.productName}</span>
                <span className="font-semibold">{cedis(it.price * it.quantity)}</span>
              </li>
            ))}
          </ul>
          <dl className="mt-3 space-y-1 border-t border-slate-100 pt-3 text-sm">
            <div className="flex justify-between"><dt className="text-slate-500">Subtotal</dt><dd>{cedis(order.subtotal)}</dd></div>
            <div className="flex justify-between"><dt className="text-slate-500">Delivery ({order.region})</dt><dd>{cedis(order.deliveryFee)}</dd></div>
            <div className="flex justify-between text-base font-extrabold"><dt>Total due</dt><dd>{cedis(order.total)}</dd></div>
          </dl>
          <p className="mt-3 text-xs text-slate-500">Deliver to: {order.deliveryName}, {order.deliveryAddress}, {order.city}, {order.region}</p>
          <span className={`mt-3 inline-block rounded-full px-3 py-1 text-xs font-semibold ${PAYMENT_STATUS_COLORS[order.paymentStatus]}`}>
            {PAYMENT_STATUS_LABELS[order.paymentStatus]}
          </span>
        </div>

        <div>
          <div className="rounded-xl bg-slate-900 p-5 text-white">
            <h2 className="font-bold">📱 Pay with Mobile Money</h2>
            <p className="mt-1 text-sm text-slate-300">Send <b className="text-amber-400">{cedis(order.total)}</b> to the official DC MALL payment account:</p>
            <p className="mt-3 rounded-lg bg-white/10 px-3 py-2.5 text-center text-xl font-extrabold tracking-wider text-amber-400 ring-1 ring-white/20">
              {settings.payment_number}
            </p>
            <p className="mt-1 text-center text-xs text-slate-400">Account name: {settings.payment_account_name}</p>
            <p className="mt-3 text-xs text-slate-400">Use <b className="text-white">{order.orderNumber}</b> as your payment reference.</p>
          </div>
          <div className="mt-4">
            <PaymentPanel
              orderId={order.id}
              orderNumber={order.orderNumber}
              paystackEnabled={paystackEnabled}
              paymentStatus={order.paymentStatus}
            />
          </div>
        </div>
      </div>

      <div className="mt-6 flex flex-wrap justify-center gap-3 text-sm">
        <Link href={`/account/orders/${order.id}`} className="rounded-lg bg-slate-900 px-5 py-2.5 font-semibold text-white">View Order Details</Link>
        <Link href="/track" className="rounded-lg bg-white px-5 py-2.5 font-semibold ring-1 ring-slate-200">Track Order</Link>
        <Link href="/shop" className="rounded-lg bg-white px-5 py-2.5 font-semibold ring-1 ring-slate-200">Continue Shopping</Link>
      </div>
    </div>
  );
}
