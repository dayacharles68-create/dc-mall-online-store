import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import SWRegister from "@/components/SWRegister";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "DC MALL — Your Trusted Online Shopping Mall",
    template: "%s | DC MALL",
  },
  description:
    "DC MALL is Ghana's trusted online shopping mall. Shop electronics, phones, fashion, beauty, home & kitchen and more — pay securely with Mobile Money and track your order to your doorstep.",
  manifest: "/manifest.json",
  icons: { icon: "/icons/icon-512.png", apple: "/icons/icon-512.png" },
  appleWebApp: { capable: true, title: "DC MALL", statusBarStyle: "black-translucent" },
};

export const viewport: Viewport = {
  themeColor: "#0f172a",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-50 text-slate-900 antialiased">
        {children}
        <SWRegister />
      </body>
    </html>
  );
}
