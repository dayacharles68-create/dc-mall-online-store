import Link from "next/link";
import { and, desc, eq, ilike, or, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { cedis, ORDER_STATUS_COLORS, ORDER_STATUS_LABELS, PAYMENT_STATUS_COLORS, PAYMENT_STATUS_LABELS, formatDate } from "@/lib/utils";

export const dynamic = "force-dynamic";
export const metadata = { title: "Orders — Admin" };

export default async function AdminOrdersPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string; payment?: string; q?: string }>;
}) {
  const sp = await searchParams;
  const conditions: SQL[] = [];
  if (sp.status) conditions.push(eq(orders.orderStatus, sp.status));
  if (sp.payment) conditions.push(eq(orders.paymentStatus, sp.payment));
  if (sp.q) {
    const term = `%${sp.q.trim()}%`;
    conditions.push(or(ilike(orders.orderNumber, term), ilike(orders.deliveryName, term), ilike(orders.deliveryPhone, term), ilike(orders.deliveryEmail, term))!);
  }
  const rows = await db
    .select()
    .from(orders)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(orders.createdAt))
    .limit(200);

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900">Orders ({rows.length})</h1>
      <p className="text-sm text-slate-500">Every order made through DC MALL</p>

      <form method="GET" className="mt-4 flex flex-wrap gap-2">
        <input name="q" defaultValue={sp.q || ""} placeholder="Search order #, name, phone, email…" className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm w-64" />
        <select name="status" defaultValue={sp.status || ""} className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm">
          <option value="">All order statuses</option>
          {Object.entries(ORDER_STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </select>
        <select name="payment" defaultValue={sp.payment || ""} className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm">
          <option value="">All payment statuses</option>
          {Object.entries(PAYMENT_STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </select>
        <button className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white">Filter</button>
        <Link href="/admin/orders" className="self-center text-xs text-slate-500 hover:underline">Clear</Link>
      </form>

      <div className="mt-4 overflow-x-auto rounded-xl bg-white ring-1 ring-slate-200">
        <table className="w-full min-w-[820px] text-sm">
          <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-4 py-3">Order</th>
              <th className="px-4 py-3">Customer</th>
              <th className="px-4 py-3">Location</th>
              <th className="px-4 py-3">Amount</th>
              <th className="px-4 py-3">Payment</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((o) => (
              <tr key={o.id} className="hover:bg-slate-50">
                <td className="px-4 py-3">
                  <Link href={`/admin/orders/${o.id}`} className="font-bold text-slate-900 hover:underline">{o.orderNumber}</Link>
                  <p className="text-xs text-slate-400">{formatDate(o.createdAt)}</p>
                </td>
                <td className="px-4 py-3">
                  <p className="font-medium text-slate-800">{o.deliveryName}</p>
                  <p className="text-xs text-slate-500">{o.deliveryPhone}</p>
                </td>
                <td className="px-4 py-3 text-slate-600">{o.city}, {o.region}</td>
                <td className="px-4 py-3 font-bold">{cedis(o.total)}</td>
                <td className="px-4 py-3">
                  <span className={`rounded-full px-2.5 py-1 text-[11px] font-semibold ${PAYMENT_STATUS_COLORS[o.paymentStatus]}`}>{PAYMENT_STATUS_LABELS[o.paymentStatus]}</span>
                </td>
                <td className="px-4 py-3">
                  <span className={`rounded-full px-2.5 py-1 text-[11px] font-semibold ${ORDER_STATUS_COLORS[o.orderStatus]}`}>{ORDER_STATUS_LABELS[o.orderStatus]}</span>
                </td>
                <td className="px-4 py-3 text-right">
                  <Link href={`/admin/orders/${o.id}`} className="rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-semibold text-white">Manage</Link>
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={7} className="px-4 py-10 text-center text-slate-400">No orders found.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
