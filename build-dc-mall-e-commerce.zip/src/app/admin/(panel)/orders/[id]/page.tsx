import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { orderItems, orders, orderTracking, payments, users } from "@/db/schema";
import { updateOrderStatusAction, verifyPaymentAction } from "@/lib/actions/admin";
import Timeline from "@/components/Timeline";
import ConfirmSubmit from "@/components/admin/ConfirmSubmit";
import { cedis, formatDate, ORDER_STATUS_LABELS, PAYMENT_STATUS_COLORS, PAYMENT_STATUS_LABELS } from "@/lib/utils";

export const dynamic = "force-dynamic";
export const metadata = { title: "Order Details — Admin" };

export default async function AdminOrderDetail({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ saved?: string; error?: string }>;
}) {
  const { id } = await params;
  const sp = await searchParams;
  const [order] = await db.select().from(orders).where(eq(orders.id, Number(id) || 0)).limit(1);
  if (!order) notFound();

  const [items, events, payment, customer] = await Promise.all([
    db.select().from(orderItems).where(eq(orderItems.orderId, order.id)),
    db.select().from(orderTracking).where(eq(orderTracking.orderId, order.id)).orderBy(orderTracking.createdAt),
    db.select().from(payments).where(eq(payments.orderId, order.id)).limit(1).then((r) => r[0]),
    db.select().from(users).where(eq(users.id, order.userId)).limit(1).then((r) => r[0]),
  ]);

  const input = "mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white";

  return (
    <div>
      <Link href="/admin/orders" className="text-sm font-semibold text-slate-600 hover:text-slate-900">← Back to Orders</Link>
      <div className="mt-2 flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-bold text-slate-900">{order.orderNumber}</h1>
        <span className={`rounded-full px-3 py-1.5 text-xs font-bold ${PAYMENT_STATUS_COLORS[order.paymentStatus]}`}>{PAYMENT_STATUS_LABELS[order.paymentStatus]}</span>
      </div>
      {sp.saved && <p className="mt-3 rounded-lg bg-emerald-50 px-4 py-2 text-sm text-emerald-700 ring-1 ring-emerald-100">Order updated successfully.</p>}
      {sp.error && <p className="mt-3 rounded-lg bg-red-50 px-4 py-2 text-sm text-red-700 ring-1 ring-red-100">Action failed: {sp.error}</p>}

      <div className="mt-5 grid gap-6 xl:grid-cols-3">
        {/* Left: order info */}
        <div className="space-y-4 xl:col-span-2">
          <section className="rounded-xl bg-white p-5 ring-1 ring-slate-200">
            <h2 className="font-bold text-slate-900">Items</h2>
            <ul className="mt-3 divide-y divide-slate-100">
              {items.map((it) => (
                <li key={it.id} className="flex items-center gap-3 py-2.5">
                  {it.productImage ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={it.productImage} alt="" className="h-11 w-11 rounded-lg object-cover" />
                  ) : <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-slate-100">🛍️</span>}
                  <div className="flex-1"><p className="text-sm font-medium">{it.productName}</p><p className="text-xs text-slate-500">{it.quantity} × {cedis(it.price)}</p></div>
                  <span className="font-bold text-sm">{cedis(it.price * it.quantity)}</span>
                </li>
              ))}
            </ul>
            <dl className="mt-2 space-y-1 border-t border-slate-100 pt-3 text-sm">
              <div className="flex justify-between"><dt className="text-slate-500">Subtotal</dt><dd>{cedis(order.subtotal)}</dd></div>
              <div className="flex justify-between"><dt className="text-slate-500">Delivery fee</dt><dd>{cedis(order.deliveryFee)}</dd></div>
              <div className="flex justify-between text-base font-extrabold"><dt>Total</dt><dd>{cedis(order.total)}</dd></div>
            </dl>
          </section>

          <div className="grid gap-4 sm:grid-cols-2">
            <section className="rounded-xl bg-white p-5 ring-1 ring-slate-200 text-sm">
              <h2 className="font-bold text-slate-900">Customer</h2>
              <p className="mt-2 font-medium">{customer?.name}</p>
              <p className="text-slate-600">{customer?.email}</p>
              <p className="text-slate-600">{customer?.phone}</p>
              <Link href={`/admin/customers?q=${encodeURIComponent(customer?.email || "")}`} className="mt-2 inline-block text-xs font-semibold text-slate-600 underline">View customer</Link>
            </section>
            <section className="rounded-xl bg-white p-5 ring-1 ring-slate-200 text-sm">
              <h2 className="font-bold text-slate-900">Delivery</h2>
              <p className="mt-2">{order.deliveryName} · {order.deliveryPhone}</p>
              <p className="text-slate-600">{order.deliveryAddress}</p>
              <p className="text-slate-600">{order.city}, {order.region}</p>
              {order.instructions && <p className="mt-1 text-xs text-slate-500">📝 {order.instructions}</p>}
              {order.trackingNumber && <p className="mt-1 text-xs">Tracking #: <b>{order.trackingNumber}</b></p>}
              {order.deliveryNotes && <p className="mt-1 text-xs text-slate-500">Notes: {order.deliveryNotes}</p>}
            </section>
          </div>

          <section className="rounded-xl bg-white p-5 ring-1 ring-slate-200">
            <h2 className="font-bold text-slate-900">Payment Record</h2>
            {payment ? (
              <dl className="mt-2 grid gap-x-6 gap-y-1 text-sm sm:grid-cols-2">
                <div className="flex justify-between"><dt className="text-slate-500">Amount</dt><dd className="font-semibold">{cedis(payment.amount)}</dd></div>
                <div className="flex justify-between"><dt className="text-slate-500">Method</dt><dd className="font-semibold">{payment.paymentMethod}</dd></div>
                <div className="flex justify-between"><dt className="text-slate-500">Status</dt><dd className="font-semibold">{PAYMENT_STATUS_LABELS[payment.paymentStatus]}</dd></div>
                <div className="flex justify-between"><dt className="text-slate-500">Customer reference</dt><dd className="font-semibold">{payment.paymentReference || "—"}</dd></div>
                <div className="flex justify-between"><dt className="text-slate-500">Transaction ID</dt><dd className="font-semibold">{payment.transactionId || "—"}</dd></div>
                <div className="flex justify-between"><dt className="text-slate-500">Last update</dt><dd className="font-semibold">{formatDate(payment.updatedAt)}</dd></div>
              </dl>
            ) : <p className="mt-2 text-sm text-slate-400">No payment record.</p>}

            {order.paymentStatus !== "paid" && order.paymentStatus !== "refunded" && (
              <div className="mt-4 rounded-lg bg-amber-50 p-4 ring-1 ring-amber-200">
                <p className="text-sm font-bold text-slate-900">Verify payment</p>
                <p className="mt-1 text-xs text-slate-600">
                  Confirm this ONLY after checking your MoMo statement / provider dashboard for the customer&apos;s reference
                  {payment?.paymentReference ? <> (<b>{payment.paymentReference}</b>)</> : null} and amount <b>{cedis(order.total)}</b>.
                </p>
                <form action={verifyPaymentAction} className="mt-3 space-y-2">
                  <input type="hidden" name="orderId" value={order.id} />
                  <input name="transactionId" placeholder="Provider transaction ID (optional — auto-generated if blank)" className={input} />
                  <div className="flex gap-2">
                    <ConfirmSubmit message="Confirm that this payment has been verified against the provider record?" className="flex-1 rounded-lg bg-emerald-600 py-2.5 text-sm font-bold text-white hover:bg-emerald-500">
                      ✓ Confirm Payment
                    </ConfirmSubmit>
                    <button type="submit" name="decision" value="reject" className="rounded-lg bg-red-50 px-4 py-2.5 text-sm font-semibold text-red-600 ring-1 ring-red-200 hover:bg-red-100">
                      ✗ Mark Failed
                    </button>
                    <input type="hidden" name="decision" value="approve" />
                  </div>
                </form>
              </div>
            )}
          </section>

          <section className="rounded-xl bg-white p-5 ring-1 ring-slate-200">
            <h2 className="font-bold text-slate-900">Update Order / Delivery Status</h2>
            <form action={updateOrderStatusAction} className="mt-3 grid gap-3 sm:grid-cols-2">
              <input type="hidden" name="orderId" value={order.id} />
              <label className="block text-sm"><span className="font-medium text-slate-700">New status</span>
                <select name="status" defaultValue={order.orderStatus} className={input}>
                  {Object.entries(ORDER_STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select></label>
              <label className="block text-sm"><span className="font-medium text-slate-700">Courier tracking number</span>
                <input name="trackingNumber" defaultValue={order.trackingNumber || ""} className={input} /></label>
              <label className="block text-sm sm:col-span-2"><span className="font-medium text-slate-700">Delivery note (visible to customer in tracking)</span>
                <input name="deliveryNotes" placeholder="e.g. Handed to Speedaf courier" className={input} /></label>
              <div className="sm:col-span-2">
                <ConfirmSubmit message="Update this order's status? The customer will be notified." className="rounded-lg bg-slate-900 px-6 py-2.5 text-sm font-bold text-white hover:bg-slate-700">
                  Update Status
                </ConfirmSubmit>
              </div>
            </form>
          </section>
        </div>

        {/* Right: timeline */}
        <section className="rounded-xl bg-white p-5 ring-1 ring-slate-200 h-fit">
          <h2 className="mb-4 font-bold text-slate-900">Tracking Timeline</h2>
          <Timeline orderStatus={order.orderStatus} paymentStatus={order.paymentStatus} events={events} />
        </section>
      </div>
    </div>
  );
}
