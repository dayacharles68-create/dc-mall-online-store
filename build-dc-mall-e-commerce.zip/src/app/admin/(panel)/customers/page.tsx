import { and, desc, eq, ilike, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { toggleCustomerStatusAction } from "@/lib/actions/admin";
import { cedis, shortDate } from "@/lib/utils";
import ConfirmSubmit from "@/components/admin/ConfirmSubmit";
import Link from "next/link";

export const dynamic = "force-dynamic";
export const metadata = { title: "Customers — Admin" };

export default async function AdminCustomersPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; saved?: string }>;
}) {
  const sp = await searchParams;
  const q = (sp.q || "").trim();
  const rows = await db
    .select({
      u: users,
      orderCount: sql<number>`(select count(*) from orders o where o.user_id = ${users.id})::int`,
      totalSpent: sql<number>`coalesce((select sum(o.total) from orders o where o.user_id = ${users.id} and o.payment_status = 'paid'), 0)::float`,
    })
    .from(users)
    .where(
      and(
        eq(users.role, "customer"),
        q ? or(ilike(users.name, `%${q}%`), ilike(users.email, `%${q}%`), ilike(users.phone, `%${q}%`)) : undefined
      )
    )
    .orderBy(desc(users.createdAt))
    .limit(200);

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900">Customers ({rows.length})</h1>
      <p className="text-sm text-slate-500">Registered DC MALL customer accounts</p>
      {sp.saved && <p className="mt-3 rounded-lg bg-emerald-50 px-4 py-2 text-sm text-emerald-700 ring-1 ring-emerald-100">Customer updated.</p>}
      <form method="GET" className="mt-4">
        <input name="q" defaultValue={q} placeholder="Search name, email, phone…" className="w-full max-w-sm rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm" />
      </form>
      <div className="mt-4 overflow-x-auto rounded-xl bg-white ring-1 ring-slate-200">
        <table className="w-full min-w-[760px] text-sm">
          <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-4 py-3">Customer</th>
              <th className="px-4 py-3">Contact</th>
              <th className="px-4 py-3">Registered</th>
              <th className="px-4 py-3">Orders</th>
              <th className="px-4 py-3">Total Purchases</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map(({ u, orderCount, totalSpent }) => (
              <tr key={u.id} className="hover:bg-slate-50">
                <td className="px-4 py-3">
                  <p className="font-medium text-slate-800">{u.name}</p>
                  <p className="text-xs text-slate-400">{u.city ? `${u.city}, ${u.region || ""}` : "—"}</p>
                </td>
                <td className="px-4 py-3 text-slate-600"><p>{u.email}</p><p className="text-xs">{u.phone}</p></td>
                <td className="px-4 py-3 text-slate-600">{shortDate(u.createdAt)}</td>
                <td className="px-4 py-3 font-semibold">{orderCount}</td>
                <td className="px-4 py-3 font-semibold">{cedis(totalSpent)}</td>
                <td className="px-4 py-3">
                  <span className={`rounded-full px-2.5 py-1 text-[11px] font-semibold ${u.status === "active" ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`}>
                    {u.status}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-2">
                    <Link href={`/admin/orders?q=${encodeURIComponent(u.email)}`} className="rounded-lg bg-slate-100 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-200">Orders</Link>
                    <form action={toggleCustomerStatusAction}>
                      <input type="hidden" name="id" value={u.id} />
                      <ConfirmSubmit
                        message={u.status === "active" ? `Disable ${u.name}'s account? They will be logged out immediately.` : `Reactivate ${u.name}'s account?`}
                        className={`rounded-lg px-3 py-1.5 text-xs font-semibold ${u.status === "active" ? "bg-red-50 text-red-600 hover:bg-red-100" : "bg-emerald-50 text-emerald-700 hover:bg-emerald-100"}`}
                      >
                        {u.status === "active" ? "Disable" : "Reactivate"}
                      </ConfirmSubmit>
                    </form>
                  </div>
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={7} className="px-4 py-10 text-center text-slate-400">No customers found.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
