import { asc } from "drizzle-orm";
import { db } from "@/db";
import { products } from "@/db/schema";
import { updateStockAction } from "@/lib/actions/admin";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";
export const metadata = { title: "Inventory — Admin" };

export default async function AdminInventoryPage({
  searchParams,
}: {
  searchParams: Promise<{ saved?: string }>;
}) {
  const sp = await searchParams;
  const settings = await getSettings();
  const threshold = Number(settings.low_stock_threshold) || 5;
  const rows = await db.select().from(products).orderBy(asc(products.stock)).limit(300);
  const low = rows.filter((p) => p.stock > 0 && p.stock <= threshold).length;
  const out = rows.filter((p) => p.stock === 0).length;

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900">Inventory Monitoring</h1>
      <p className="text-sm text-slate-500">Stock is automatically reduced when orders are placed and restored when orders are cancelled.</p>
      {sp.saved && <p className="mt-3 rounded-lg bg-emerald-50 px-4 py-2 text-sm text-emerald-700 ring-1 ring-emerald-100">Stock updated.</p>}

      <div className="mt-4 grid grid-cols-3 gap-3 max-w-lg">
        <div className="rounded-xl bg-white p-4 text-center ring-1 ring-slate-200"><p className="text-xl font-extrabold">{rows.length}</p><p className="text-xs text-slate-500">Products</p></div>
        <div className="rounded-xl bg-amber-50 p-4 text-center ring-1 ring-amber-200"><p className="text-xl font-extrabold text-amber-700">{low}</p><p className="text-xs text-amber-700">Low stock (≤{threshold})</p></div>
        <div className="rounded-xl bg-red-50 p-4 text-center ring-1 ring-red-200"><p className="text-xl font-extrabold text-red-700">{out}</p><p className="text-xs text-red-700">Out of stock</p></div>
      </div>

      <div className="mt-4 overflow-x-auto rounded-xl bg-white ring-1 ring-slate-200">
        <table className="w-full min-w-[680px] text-sm">
          <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-4 py-3">Product</th>
              <th className="px-4 py-3">SKU</th>
              <th className="px-4 py-3">Available</th>
              <th className="px-4 py-3">Sold</th>
              <th className="px-4 py-3">Alert</th>
              <th className="px-4 py-3 text-right">Update Stock</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((p) => (
              <tr key={p.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 font-medium text-slate-800">{p.name}</td>
                <td className="px-4 py-3 text-slate-500">{p.sku || "—"}</td>
                <td className={`px-4 py-3 font-bold ${p.stock === 0 ? "text-red-600" : p.stock <= threshold ? "text-amber-600" : "text-slate-800"}`}>{p.stock}</td>
                <td className="px-4 py-3 text-slate-600">{p.sold}</td>
                <td className="px-4 py-3">
                  {p.stock === 0 ? (
                    <span className="rounded-full bg-red-50 px-2.5 py-1 text-[11px] font-bold text-red-700">OUT OF STOCK</span>
                  ) : p.stock <= threshold ? (
                    <span className="rounded-full bg-amber-50 px-2.5 py-1 text-[11px] font-bold text-amber-700">LOW STOCK</span>
                  ) : (
                    <span className="rounded-full bg-emerald-50 px-2.5 py-1 text-[11px] font-semibold text-emerald-700">OK</span>
                  )}
                </td>
                <td className="px-4 py-3">
                  <form action={updateStockAction} className="flex justify-end gap-2">
                    <input type="hidden" name="id" value={p.id} />
                    <input name="stock" type="number" min={0} defaultValue={p.stock} className="w-20 rounded-lg border border-slate-300 px-2 py-1.5 text-sm" />
                    <button className="rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-semibold text-white hover:bg-slate-700">Save</button>
                  </form>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
