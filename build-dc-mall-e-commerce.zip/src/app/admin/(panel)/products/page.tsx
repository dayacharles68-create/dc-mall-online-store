import Link from "next/link";
import { desc, ilike, sql } from "drizzle-orm";
import { db } from "@/db";
import { products } from "@/db/schema";
import { deleteProductAction } from "@/lib/actions/admin";
import { cedis } from "@/lib/utils";
import ConfirmSubmit from "@/components/admin/ConfirmSubmit";

export const dynamic = "force-dynamic";
export const metadata = { title: "Products — Admin" };

const STATUS_BADGE: Record<string, string> = {
  active: "bg-emerald-50 text-emerald-700",
  inactive: "bg-slate-100 text-slate-600",
  out_of_stock: "bg-red-50 text-red-700",
  draft: "bg-amber-50 text-amber-700",
};

export default async function AdminProductsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; saved?: string; deleted?: string }>;
}) {
  const sp = await searchParams;
  const q = (sp.q || "").trim();
  const rows = await db
    .select({
      p: products,
      image: sql<string | null>`(select image_url from product_images pi where pi.product_id = ${products.id} order by sort_order limit 1)`,
      catName: sql<string | null>`(select name from categories c where c.id = ${products.categoryId})`,
    })
    .from(products)
    .where(q ? ilike(products.name, `%${q}%`) : undefined)
    .orderBy(desc(products.createdAt))
    .limit(200);

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Products ({rows.length})</h1>
          <p className="text-sm text-slate-500">Manage your DC MALL catalogue</p>
        </div>
        <Link href="/admin/products/new" className="rounded-lg bg-slate-900 px-5 py-2.5 text-sm font-bold text-white hover:bg-slate-700">+ Add Product</Link>
      </div>
      {sp.saved && <p className="mt-3 rounded-lg bg-emerald-50 px-4 py-2 text-sm text-emerald-700 ring-1 ring-emerald-100">Product saved successfully.</p>}
      {sp.deleted && <p className="mt-3 rounded-lg bg-red-50 px-4 py-2 text-sm text-red-700 ring-1 ring-red-100">Product deleted.</p>}

      <form className="mt-4" method="GET">
        <input name="q" defaultValue={q} placeholder="Search products…" className="w-full max-w-sm rounded-lg border border-slate-300 px-3 py-2.5 text-sm bg-white" />
      </form>

      <div className="mt-4 overflow-x-auto rounded-xl bg-white ring-1 ring-slate-200">
        <table className="w-full min-w-[760px] text-sm">
          <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-4 py-3">Product</th>
              <th className="px-4 py-3">Category</th>
              <th className="px-4 py-3">Price</th>
              <th className="px-4 py-3">Stock</th>
              <th className="px-4 py-3">Sold</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map(({ p, image, catName }) => (
              <tr key={p.id} className="hover:bg-slate-50">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    {image ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={image} alt="" className="h-10 w-10 rounded-lg object-cover" />
                    ) : <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-100">🛍️</span>}
                    <div>
                      <p className="font-medium text-slate-800 line-clamp-1">{p.name}</p>
                      <p className="text-xs text-slate-400">{p.sku || p.brand || `#${p.id}`}</p>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 text-slate-600">{catName || "—"}</td>
                <td className="px-4 py-3">
                  <p className="font-semibold">{cedis(p.discountPrice ?? p.price)}</p>
                  {p.discountPrice != null && <p className="text-xs text-slate-400 line-through">{cedis(p.price)}</p>}
                </td>
                <td className={`px-4 py-3 font-semibold ${p.stock === 0 ? "text-red-600" : p.stock <= 5 ? "text-amber-600" : "text-slate-700"}`}>{p.stock}</td>
                <td className="px-4 py-3 text-slate-600">{p.sold}</td>
                <td className="px-4 py-3">
                  <span className={`rounded-full px-2.5 py-1 text-[11px] font-semibold ${STATUS_BADGE[p.status]}`}>{p.status.replace(/_/g, " ")}</span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-2">
                    <Link href={`/admin/products/${p.id}`} className="rounded-lg bg-slate-100 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-200">Edit</Link>
                    <form action={deleteProductAction}>
                      <input type="hidden" name="id" value={p.id} />
                      <ConfirmSubmit message={`Delete "${p.name}" permanently? This cannot be undone.`} className="rounded-lg bg-red-50 px-3 py-1.5 text-xs font-semibold text-red-600 hover:bg-red-100">
                        Delete
                      </ConfirmSubmit>
                    </form>
                  </div>
                </td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr><td colSpan={7} className="px-4 py-10 text-center text-slate-400">No products found.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
