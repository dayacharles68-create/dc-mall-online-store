import Link from "next/link";
import { db } from "@/db";
import { categories } from "@/db/schema";
import { ProductForm } from "@/components/admin/AdminForms";

export const dynamic = "force-dynamic";
export const metadata = { title: "Add Product — Admin" };

export default async function NewProductPage() {
  const cats = await db.select({ id: categories.id, name: categories.name }).from(categories).orderBy(categories.name);
  return (
    <div className="max-w-3xl">
      <Link href="/admin/products" className="text-sm font-semibold text-slate-600 hover:text-slate-900">← Back to Products</Link>
      <h1 className="mt-2 text-2xl font-bold text-slate-900">Add Product</h1>
      <div className="mt-5 rounded-xl bg-white p-6 ring-1 ring-slate-200">
        <ProductForm categories={cats} />
      </div>
    </div>
  );
}
