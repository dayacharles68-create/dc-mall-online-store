import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { categories, productImages, products } from "@/db/schema";
import { ProductForm } from "@/components/admin/AdminForms";

export const dynamic = "force-dynamic";
export const metadata = { title: "Edit Product — Admin" };

export default async function EditProductPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [product] = await db.select().from(products).where(eq(products.id, Number(id) || 0)).limit(1);
  if (!product) notFound();
  const [cats, images] = await Promise.all([
    db.select({ id: categories.id, name: categories.name }).from(categories).orderBy(categories.name),
    db.select().from(productImages).where(eq(productImages.productId, product.id)).orderBy(productImages.sortOrder),
  ]);

  return (
    <div className="max-w-3xl">
      <Link href="/admin/products" className="text-sm font-semibold text-slate-600 hover:text-slate-900">← Back to Products</Link>
      <h1 className="mt-2 text-2xl font-bold text-slate-900">Edit Product #{product.id}</h1>
      <div className="mt-5 rounded-xl bg-white p-6 ring-1 ring-slate-200">
        <ProductForm
          categories={cats}
          product={{ ...product, images: images.map((i) => i.imageUrl) }}
        />
      </div>
    </div>
  );
}
