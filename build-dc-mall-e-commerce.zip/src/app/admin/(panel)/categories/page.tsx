import Link from "next/link";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { categories } from "@/db/schema";
import { deleteCategoryAction } from "@/lib/actions/admin";
import { CategoryForm } from "@/components/admin/AdminForms";
import ConfirmSubmit from "@/components/admin/ConfirmSubmit";

export const dynamic = "force-dynamic";
export const metadata = { title: "Categories — Admin" };

export default async function AdminCategoriesPage({
  searchParams,
}: {
  searchParams: Promise<{ edit?: string; saved?: string; deleted?: string }>;
}) {
  const sp = await searchParams;
  const rows = await db
    .select({
      c: categories,
      productCount: sql<number>`(select count(*) from products p where p.category_id = ${categories.id})::int`,
    })
    .from(categories)
    .orderBy(categories.name);
  const editing = sp.edit ? rows.find((r) => r.c.id === Number(sp.edit))?.c : undefined;

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900">Categories ({rows.length})</h1>
      {sp.saved && <p className="mt-3 rounded-lg bg-emerald-50 px-4 py-2 text-sm text-emerald-700 ring-1 ring-emerald-100">Category saved.</p>}
      {sp.deleted && <p className="mt-3 rounded-lg bg-red-50 px-4 py-2 text-sm text-red-700 ring-1 ring-red-100">Category deleted.</p>}
      <div className="mt-5 grid gap-6 lg:grid-cols-[1fr_340px]">
        <div className="overflow-x-auto rounded-xl bg-white ring-1 ring-slate-200 h-fit">
          <table className="w-full min-w-[520px] text-sm">
            <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
              <tr>
                <th className="px-4 py-3">Category</th>
                <th className="px-4 py-3">Products</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rows.map(({ c, productCount }) => (
                <tr key={c.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3">
                    <p className="font-medium text-slate-800">{c.name}</p>
                    <p className="text-xs text-slate-400">{c.description || c.slug}</p>
                  </td>
                  <td className="px-4 py-3">
                    <Link href={`/shop?category=${c.slug}`} className="font-semibold text-slate-700 underline">{productCount}</Link>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`rounded-full px-2.5 py-1 text-[11px] font-semibold ${c.status === "active" ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-600"}`}>{c.status}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-2">
                      <Link href={`/admin/categories?edit=${c.id}`} className="rounded-lg bg-slate-100 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-200">Edit</Link>
                      <form action={deleteCategoryAction}>
                        <input type="hidden" name="id" value={c.id} />
                        <ConfirmSubmit message={`Delete category "${c.name}"? Products in it will become uncategorised.`} className="rounded-lg bg-red-50 px-3 py-1.5 text-xs font-semibold text-red-600 hover:bg-red-100">
                          Delete
                        </ConfirmSubmit>
                      </form>
                    </div>
                  </td>
                </tr>
              ))}
              {rows.length === 0 && <tr><td colSpan={4} className="px-4 py-10 text-center text-slate-400">No categories yet.</td></tr>}
            </tbody>
          </table>
        </div>
        <div className="rounded-xl bg-white p-5 ring-1 ring-slate-200 h-fit">
          <div className="flex items-center justify-between">
            <h2 className="font-bold text-slate-900">{editing ? `Edit: ${editing.name}` : "Add Category"}</h2>
            {editing && <Link href="/admin/categories" className="text-xs text-slate-500 hover:underline">+ New instead</Link>}
          </div>
          <div className="mt-3">
            <CategoryForm key={editing?.id ?? "new"} category={editing} />
          </div>
        </div>
      </div>
    </div>
  );
}
