import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { products, reviews, users } from "@/db/schema";
import { moderateReviewAction } from "@/lib/actions/admin";
import ConfirmSubmit from "@/components/admin/ConfirmSubmit";
import Stars from "@/components/Stars";
import { formatDate } from "@/lib/utils";

export const dynamic = "force-dynamic";
export const metadata = { title: "Reviews — Admin" };

export default async function AdminReviewsPage({
  searchParams,
}: {
  searchParams: Promise<{ saved?: string }>;
}) {
  const sp = await searchParams;
  const rows = await db
    .select({ r: reviews, productName: products.name, userName: users.name })
    .from(reviews)
    .innerJoin(products, eq(reviews.productId, products.id))
    .innerJoin(users, eq(reviews.userId, users.id))
    .orderBy(desc(reviews.createdAt))
    .limit(200);

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900">Review Moderation ({rows.length})</h1>
      {sp.saved && <p className="mt-3 rounded-lg bg-emerald-50 px-4 py-2 text-sm text-emerald-700 ring-1 ring-emerald-100">Review updated.</p>}
      <div className="mt-5 space-y-3">
        {rows.map(({ r, productName, userName }) => (
          <div key={r.id} className="rounded-xl bg-white p-4 ring-1 ring-slate-200">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm font-bold text-slate-900">{productName}</p>
                <p className="text-xs text-slate-500">
                  by {userName} · {formatDate(r.createdAt)}
                  {r.verifiedPurchase && <span className="ml-2 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-semibold text-emerald-700">Verified</span>}
                  {r.status === "hidden" && <span className="ml-2 rounded-full bg-red-50 px-2 py-0.5 text-[10px] font-semibold text-red-700">Hidden</span>}
                </p>
              </div>
              <Stars rating={r.rating} />
            </div>
            {r.review && <p className="mt-2 text-sm text-slate-600">{r.review}</p>}
            <div className="mt-3 flex gap-2">
              <form action={moderateReviewAction}>
                <input type="hidden" name="id" value={r.id} />
                <input type="hidden" name="action" value={r.status === "hidden" ? "show" : "hide"} />
                <button className="rounded-lg bg-slate-100 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-200">
                  {r.status === "hidden" ? "Unhide" : "Hide"}
                </button>
              </form>
              <form action={moderateReviewAction}>
                <input type="hidden" name="id" value={r.id} />
                <input type="hidden" name="action" value="delete" />
                <ConfirmSubmit message="Permanently delete this review?" className="rounded-lg bg-red-50 px-3 py-1.5 text-xs font-semibold text-red-600 hover:bg-red-100">
                  Delete
                </ConfirmSubmit>
              </form>
            </div>
          </div>
        ))}
        {rows.length === 0 && <p className="rounded-xl bg-white p-10 text-center text-sm text-slate-400 ring-1 ring-slate-200">No reviews yet.</p>}
      </div>
    </div>
  );
}
