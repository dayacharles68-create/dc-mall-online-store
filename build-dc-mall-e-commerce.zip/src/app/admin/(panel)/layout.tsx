import type { ReactNode } from "react";
import { requireAdmin } from "@/lib/auth";
import { logoutAction } from "@/lib/actions/auth";
import AdminSidebar from "@/components/admin/AdminSidebar";

export const dynamic = "force-dynamic";

export default async function AdminPanelLayout({ children }: { children: ReactNode }) {
  const admin = await requireAdmin();
  return (
    <div className="min-h-screen bg-slate-100 lg:flex">
      <AdminSidebar adminName={admin.name} />
      <div className="flex-1 min-w-0">
        <div className="hidden lg:flex items-center justify-between border-b border-slate-200 bg-white px-6 py-3">
          <p className="text-sm text-slate-500">DC MALL — Admin Dashboard</p>
          <form action={logoutAction}>
            <button className="rounded-lg px-3 py-1.5 text-sm font-semibold text-red-600 hover:bg-red-50">Logout</button>
          </form>
        </div>
        <div className="p-4 sm:p-6">{children}</div>
      </div>
    </div>
  );
}
