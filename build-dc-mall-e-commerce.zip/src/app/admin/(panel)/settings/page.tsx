import { getSettings } from "@/lib/settings";
import { SettingsForm } from "@/components/admin/AdminForms";

export const dynamic = "force-dynamic";
export const metadata = { title: "Settings — Admin" };

export default async function AdminSettingsPage() {
  const values = await getSettings();
  return (
    <div className="max-w-3xl">
      <h1 className="text-2xl font-bold text-slate-900">Store Settings</h1>
      <p className="text-sm text-slate-500">Configure DC MALL business information, payments and delivery fees. Currency defaults to Ghana Cedi (GHS ₵).</p>
      <div className="mt-5 rounded-xl bg-white p-6 ring-1 ring-slate-200">
        <SettingsForm values={values} />
      </div>
      <div className="mt-4 rounded-xl bg-slate-900 p-5 text-sm text-slate-300">
        <h2 className="font-bold text-white">Payment gateway integration</h2>
        <p className="mt-1 text-xs leading-relaxed">
          To enable automatic Mobile Money / card verification via <b>Paystack</b>, set the environment variables
          <code className="mx-1 rounded bg-slate-800 px-1.5 py-0.5">PAYSTACK_SECRET_KEY</code> and
          <code className="mx-1 rounded bg-slate-800 px-1.5 py-0.5">NEXT_PUBLIC_APP_URL</code>, and point the Paystack
          webhook to <code className="rounded bg-slate-800 px-1.5 py-0.5">/api/payments/paystack/webhook</code>.
          Without a gateway, manual MoMo payments to the official account are verified from this dashboard.
          Email notifications require <code className="rounded bg-slate-800 px-1.5 py-0.5">RESEND_API_KEY</code>.
        </p>
      </div>
    </div>
  );
}
