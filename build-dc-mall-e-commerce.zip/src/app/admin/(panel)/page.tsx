import Link from "next/link";
import { desc, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { orders, products, users } from "@/db/schema";
import { getSettings } from "@/lib/settings";
import { cedis, ORDER_STATUS_COLORS, ORDER_STATUS_LABELS, shortDate } from "@/lib/utils";
import BarChart from "@/components/BarChart";

export const dynamic = "force-dynamic";
export const metadata = { title: "Admin Dashboard" };

export default async function AdminDashboard() {
  const settings = await getSettings();
  const lowStock = Number(settings.low_stock_threshold) || 5;
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const weekStart = new Date(todayStart.getTime() - 6 * 86400000);
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const dayAgo = new Date(Date.now() - 86400000);

  const [orderStats, salesStats, customerStats, productStats, daily, byStatus, topProducts, recentOrders] =
    await Promise.all([
      db.select({
        total: sql<number>`count(*)::int`,
        pending: sql<number>`count(*) filter (where order_status in ('placed','processing','packed','shipped','out_for_delivery'))::int`,
        completed: sql<number>`count(*) filter (where order_status = 'delivered')::int`,
        cancelled: sql<number>`count(*) filter (where order_status = 'cancelled')::int`,
        pendingPayments: sql<number>`count(*) filter (where payment_status in ('pending','processing'))::int`,
        awaitingVerification: sql<number>`count(*) filter (where payment_status = 'processing')::int`,
        newToday: sql<number>`count(*) filter (where created_at >= ${dayAgo})::int`,
      }).from(orders).then((r) => r[0]),
      db.select({
        totalRevenue: sql<number>`coalesce(sum(total) filter (where payment_status = 'paid'), 0)::float`,
        today: sql<number>`coalesce(sum(total) filter (where payment_status = 'paid' and created_at >= ${todayStart}), 0)::float`,
        week: sql<number>`coalesce(sum(total) filter (where payment_status = 'paid' and created_at >= ${weekStart}), 0)::float`,
        month: sql<number>`coalesce(sum(total) filter (where payment_status = 'paid' and created_at >= ${monthStart}), 0)::float`,
        aov: sql<number>`coalesce(avg(total) filter (where payment_status = 'paid'), 0)::float`,
      }).from(orders).then((r) => r[0]),
      db.select({
        total: sql<number>`count(*) filter (where role = 'customer')::int`,
        newToday: sql<number>`count(*) filter (where role = 'customer' and created_at >= ${dayAgo})::int`,
        returning: sql<number>`(select count(*) from (select user_id from orders group by user_id having count(*) > 1) t)::int`,
      }).from(users).then((r) => r[0]),
      db.select({
        total: sql<number>`count(*)::int`,
        low: sql<number>`count(*) filter (where stock > 0 and stock <= ${lowStock})::int`,
        out: sql<number>`count(*) filter (where stock = 0)::int`,
      }).from(products).then((r) => r[0]),
      db.select({
        day: sql<string>`to_char(created_at, 'DD Mon')`,
        dayKey: sql<string>`to_char(created_at, 'YYYY-MM-DD')`,
        value: sql<number>`coalesce(sum(total) filter (where payment_status = 'paid'), 0)::float`,
      }).from(orders).where(gte(orders.createdAt, new Date(Date.now() - 13 * 86400000)))
        .groupBy(sql`to_char(created_at, 'DD Mon'), to_char(created_at, 'YYYY-MM-DD')`)
        .orderBy(sql`to_char(created_at, 'YYYY-MM-DD')`),
      db.select({
        status: orders.orderStatus,
        value: sql<number>`count(*)::int`,
      }).from(orders).groupBy(orders.orderStatus),
      db.select({ name: products.name, sold: products.sold }).from(products).orderBy(desc(products.sold)).limit(6),
      db.select().from(orders).orderBy(desc(orders.createdAt)).limit(8),
    ]);

  const alerts: { icon: string; text: string; href: string; tone: string }[] = [];
  if (orderStats.newToday) alerts.push({ icon: "🆕", text: `${orderStats.newToday} new order(s) in the last 24 hours`, href: "/admin/orders", tone: "bg-blue-50 text-blue-800 ring-blue-100" });
  if (orderStats.awaitingVerification) alerts.push({ icon: "💳", text: `${orderStats.awaitingVerification} payment(s) awaiting verification`, href: "/admin/orders?payment=processing", tone: "bg-amber-50 text-amber-800 ring-amber-200" });
  if (customerStats.newToday) alerts.push({ icon: "👤", text: `${customerStats.newToday} new customer(s) registered today`, href: "/admin/customers", tone: "bg-emerald-50 text-emerald-800 ring-emerald-100" });
  if (productStats.low) alerts.push({ icon: "⚠️", text: `${productStats.low} product(s) low on stock`, href: "/admin/inventory", tone: "bg-orange-50 text-orange-800 ring-orange-100" });
  if (productStats.out) alerts.push({ icon: "🚫", text: `${productStats.out} product(s) out of stock`, href: "/admin/inventory", tone: "bg-red-50 text-red-800 ring-red-100" });
  if (orderStats.cancelled) alerts.push({ icon: "❌", text: `${orderStats.cancelled} cancelled order(s) total`, href: "/admin/orders?status=cancelled", tone: "bg-slate-50 text-slate-700 ring-slate-200" });

  const stats = [
    ["Total Sales (paid)", cedis(salesStats.totalRevenue)],
    ["Today's Sales", cedis(salesStats.today)],
    ["This Week", cedis(salesStats.week)],
    ["This Month", cedis(salesStats.month)],
    ["Avg. Order Value", cedis(salesStats.aov)],
    ["Total Orders", String(orderStats.total)],
    ["Pending Orders", String(orderStats.pending)],
    ["Completed Orders", String(orderStats.completed)],
    ["Pending Payments", String(orderStats.pendingPayments)],
    ["Customers", `${customerStats.total} (${customerStats.returning} returning)`],
    ["Products", String(productStats.total)],
    ["Low / Out of Stock", `${productStats.low} / ${productStats.out}`],
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Dashboard</h1>
        <p className="text-sm text-slate-500">Business overview for DC MALL</p>
      </div>

      {alerts.length > 0 && (
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {alerts.map((a, i) => (
            <Link key={i} href={a.href} className={`flex items-center gap-2 rounded-xl px-4 py-3 text-sm font-medium ring-1 ${a.tone} hover:opacity-80`}>
              <span>{a.icon}</span> {a.text}
            </Link>
          ))}
        </div>
      )}

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-4">
        {stats.map(([label, value]) => (
          <div key={label} className="rounded-xl bg-white p-4 ring-1 ring-slate-200">
            <p className="text-xs text-slate-500">{label}</p>
            <p className="mt-1 text-lg font-extrabold text-slate-900 truncate">{value}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-xl bg-white p-5 ring-1 ring-slate-200">
          <h2 className="font-bold text-slate-900">Daily Sales — last 14 days (paid)</h2>
          <div className="mt-4">
            {daily.length ? (
              <BarChart data={daily.map((d) => ({ label: d.day, value: d.value }))} color="bg-emerald-500" valueFormat={cedis} />
            ) : <p className="text-sm text-slate-400 py-10 text-center">No sales data yet.</p>}
          </div>
        </div>
        <div className="rounded-xl bg-white p-5 ring-1 ring-slate-200">
          <h2 className="font-bold text-slate-900">Orders by Status</h2>
          <div className="mt-4">
            {byStatus.length ? (
              <BarChart data={byStatus.map((d) => ({ label: ORDER_STATUS_LABELS[d.status] || d.status, value: d.value }))} color="bg-slate-800" />
            ) : <p className="text-sm text-slate-400 py-10 text-center">No orders yet.</p>}
          </div>
        </div>
        <div className="rounded-xl bg-white p-5 ring-1 ring-slate-200">
          <h2 className="font-bold text-slate-900">Best-Selling Products (units sold)</h2>
          <div className="mt-4">
            {topProducts.some((p) => p.sold > 0) ? (
              <BarChart data={topProducts.map((p) => ({ label: p.name.slice(0, 14), value: p.sold }))} color="bg-amber-400" />
            ) : <p className="text-sm text-slate-400 py-10 text-center">No confirmed sales yet.</p>}
          </div>
        </div>
        <div className="rounded-xl bg-white p-5 ring-1 ring-slate-200">
          <div className="flex items-center justify-between">
            <h2 className="font-bold text-slate-900">Latest Orders</h2>
            <Link href="/admin/orders" className="text-sm font-semibold text-slate-600 hover:text-slate-900">All orders →</Link>
          </div>
          <ul className="mt-3 divide-y divide-slate-100">
            {recentOrders.map((o) => (
              <li key={o.id} className="flex items-center justify-between gap-2 py-2.5">
                <div className="min-w-0">
                  <Link href={`/admin/orders/${o.id}`} className="text-sm font-bold text-slate-900 hover:underline">{o.orderNumber}</Link>
                  <p className="text-xs text-slate-500 truncate">{o.deliveryName} · {shortDate(o.createdAt)}</p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-sm font-bold">{cedis(o.total)}</span>
                  <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${ORDER_STATUS_COLORS[o.orderStatus]}`}>{ORDER_STATUS_LABELS[o.orderStatus]}</span>
                </div>
              </li>
            ))}
            {recentOrders.length === 0 && <p className="py-6 text-center text-sm text-slate-400">No orders yet.</p>}
          </ul>
        </div>
      </div>
    </div>
  );
}
