import { desc } from "drizzle-orm";
import { db } from "@/db";
import { auditLogs } from "@/db/schema";
import { formatDate } from "@/lib/utils";

export const dynamic = "force-dynamic";
export const metadata = { title: "Audit Log — Admin" };

export default async function AdminAuditPage() {
  const rows = await db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(300);
  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900">Administrative Audit Log</h1>
      <p className="text-sm text-slate-500">A record of important administrative actions.</p>
      <div className="mt-5 overflow-x-auto rounded-xl bg-white ring-1 ring-slate-200">
        <table className="w-full min-w-[640px] text-sm">
          <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-4 py-3">Date / Time</th>
              <th className="px-4 py-3">Admin</th>
              <th className="px-4 py-3">Action</th>
              <th className="px-4 py-3">Details</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((log) => (
              <tr key={log.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 whitespace-nowrap text-slate-600">{formatDate(log.createdAt)}</td>
                <td className="px-4 py-3 font-medium text-slate-800">{log.adminName || "—"}</td>
                <td className="px-4 py-3"><span className="rounded-full bg-slate-100 px-2.5 py-1 text-[11px] font-semibold text-slate-700">{log.action}</span></td>
                <td className="px-4 py-3 text-slate-600">{log.details}</td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={4} className="px-4 py-10 text-center text-slate-400">No admin activity recorded yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
