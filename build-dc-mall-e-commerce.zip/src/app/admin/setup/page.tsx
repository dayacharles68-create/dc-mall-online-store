import { redirect } from "next/navigation";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { SetupForm } from "@/components/admin/AdminForms";

export const dynamic = "force-dynamic";
export const metadata = { title: "Admin Setup", robots: { index: false } };

export default async function AdminSetupPage() {
  const [row] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(users)
    .where(eq(users.role, "admin"));
  if ((row?.count || 0) > 0) redirect("/admin/login");

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-900 px-4 py-10">
      <div className="w-full max-w-md rounded-2xl bg-white p-8 shadow-2xl">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-900 font-black text-amber-400">DC</span>
          <div>
            <h1 className="font-bold text-slate-900">First-Time Setup</h1>
            <p className="text-xs text-slate-500">Create the DC MALL administrator account</p>
          </div>
        </div>
        <p className="mt-4 rounded-lg bg-amber-50 px-3 py-2 text-xs text-amber-800 ring-1 ring-amber-200">
          This page is only available while no administrator exists. Once the first admin is created,
          it is permanently disabled. {process.env.ADMIN_SETUP_KEY ? "A setup key is required." : "Tip: set ADMIN_SETUP_KEY in your environment for extra protection."}
        </p>
        <div className="mt-6"><SetupForm needsKey={!!process.env.ADMIN_SETUP_KEY} /></div>
      </div>
    </div>
  );
}
