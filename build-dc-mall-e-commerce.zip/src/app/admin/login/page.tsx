import Link from "next/link";
import { redirect } from "next/navigation";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { LoginForm } from "@/components/AuthForms";

export const dynamic = "force-dynamic";
export const metadata = { title: "Admin Login", robots: { index: false } };

export default async function AdminLoginPage() {
  const user = await getSessionUser();
  if (user?.role === "admin") redirect("/admin");
  const [row] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(users)
    .where(eq(users.role, "admin"));
  if ((row?.count || 0) === 0) redirect("/admin/setup");

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-900 px-4">
      <div className="w-full max-w-md rounded-2xl bg-white p-8 shadow-2xl">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-900 font-black text-amber-400">DC</span>
          <div>
            <h1 className="font-bold text-slate-900">DC MALL Administration</h1>
            <p className="text-xs text-slate-500">Authorized personnel only</p>
          </div>
        </div>
        <div className="mt-6"><LoginForm admin /></div>
        <p className="mt-5 text-center text-xs text-slate-400">
          <Link href="/" className="hover:underline">← Back to DC MALL store</Link>
        </p>
      </div>
    </div>
  );
}
