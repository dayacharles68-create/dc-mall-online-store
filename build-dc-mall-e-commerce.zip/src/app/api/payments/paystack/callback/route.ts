import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { confirmPaidOrder } from "@/lib/payments";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const reference = url.searchParams.get("reference") || url.searchParams.get("trxref");
  const secret = process.env.PAYSTACK_SECRET_KEY;
  if (!reference || !secret) return NextResponse.redirect(new URL("/account/orders", url.origin));

  // The order number is the reference prefix: DCM-YYYYMMDD-XXXX-<timestamp>
  const orderNumber = reference.split("-").slice(0, 3).join("-");
  const [order] = await db.select().from(orders).where(eq(orders.orderNumber, orderNumber)).limit(1);
  if (!order) return NextResponse.redirect(new URL("/account/orders", url.origin));

  try {
    const res = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
      headers: { Authorization: `Bearer ${secret}` },
    });
    const data = await res.json();
    const tx = data?.data;
    if (
      res.ok &&
      tx?.status === "success" &&
      Number(tx.amount) >= Math.round(order.total * 100) &&
      (tx.currency === "GHS" || !tx.currency)
    ) {
      await confirmPaidOrder(order.id, String(tx.id || reference), "paystack");
      return NextResponse.redirect(new URL(`/account/orders/${order.id}?paid=1`, url.origin));
    }
  } catch (err) {
    console.error("Paystack verify failed:", err);
  }
  return NextResponse.redirect(new URL(`/pay/${order.orderNumber}?gateway=failed`, url.origin));
}
