import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { orders, payments } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { rateLimit } from "@/lib/ratelimit";

export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Please log in to pay." }, { status: 401 });
  if (!rateLimit(`paystack-init:${user.id}`, 10, 10 * 60 * 1000))
    return NextResponse.json({ error: "Too many attempts. Please wait a moment." }, { status: 429 });

  const secret = process.env.PAYSTACK_SECRET_KEY;
  if (!secret)
    return NextResponse.json(
      { error: "Online gateway payment is not configured. Please use manual MoMo payment." },
      { status: 503 }
    );

  let orderId = 0;
  try {
    const body = await req.json();
    orderId = Number(body.orderId);
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }

  const [order] = await db
    .select()
    .from(orders)
    .where(and(eq(orders.id, orderId), eq(orders.userId, user.id)))
    .limit(1);
  if (!order) return NextResponse.json({ error: "Order not found." }, { status: 404 });
  if (order.paymentStatus === "paid")
    return NextResponse.json({ error: "This order has already been paid." }, { status: 400 });

  const reference = `${order.orderNumber}-${Date.now()}`;
  const base = process.env.NEXT_PUBLIC_APP_URL || new URL(req.url).origin;

  const res = await fetch("https://api.paystack.co/transaction/initialize", {
    method: "POST",
    headers: { Authorization: `Bearer ${secret}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      email: order.deliveryEmail,
      amount: Math.round(order.total * 100), // pesewas
      currency: "GHS",
      reference,
      callback_url: `${base}/api/payments/paystack/callback`,
      metadata: { orderId: order.id, orderNumber: order.orderNumber },
      channels: ["mobile_money", "card"],
    }),
  });
  const data = await res.json();
  if (!res.ok || !data?.data?.authorization_url) {
    console.error("Paystack init failed:", data);
    return NextResponse.json({ error: "Could not start gateway payment. Please try manual MoMo payment." }, { status: 502 });
  }

  await db
    .update(payments)
    .set({ paymentMethod: "paystack", paymentReference: reference, updatedAt: new Date() })
    .where(eq(payments.orderId, order.id));

  return NextResponse.json({ authorizationUrl: data.data.authorization_url });
}
