import { and, desc, asc, eq, gte, ilike, lte, or, sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { categories, products } from "@/db/schema";
import type { ProductCardData } from "@/components/ProductCard";

const imageSql = sql<string | null>`(select pi.image_url from product_images pi where pi.product_id = ${products.id} order by pi.sort_order asc limit 1)`;
const ratingSql = sql<number>`coalesce((select avg(r.rating)::float from reviews r where r.product_id = ${products.id} and r.status = 'visible'), 0)`;
const reviewCountSql = sql<number>`(select count(*)::int from reviews r where r.product_id = ${products.id} and r.status = 'visible')`;

export const productCardSelect = {
  id: products.id,
  name: products.name,
  slug: products.slug,
  price: products.price,
  discountPrice: products.discountPrice,
  stock: products.stock,
  brand: products.brand,
  image: imageSql,
  rating: ratingSql,
  reviewCount: reviewCountSql,
};

export type ShopFilters = {
  q?: string;
  category?: string;
  minPrice?: number;
  maxPrice?: number;
  inStock?: boolean;
  minRating?: number;
  sort?: string;
  page?: number;
  pageSize?: number;
};

export async function searchProducts(filters: ShopFilters): Promise<{
  items: ProductCardData[];
  total: number;
  page: number;
  pageSize: number;
}> {
  const page = Math.max(1, filters.page || 1);
  const pageSize = Math.min(48, filters.pageSize || 12);
  const conditions: SQL[] = [eq(products.status, "active")];

  if (filters.q) {
    const term = `%${filters.q.trim()}%`;
    conditions.push(
      or(
        ilike(products.name, term),
        ilike(products.description, term),
        ilike(products.brand, term)
      )!
    );
  }
  if (filters.category) {
    conditions.push(
      sql`${products.categoryId} in (select id from categories where slug = ${filters.category})`
    );
  }
  if (filters.minPrice !== undefined)
    conditions.push(gte(sql`coalesce(${products.discountPrice}, ${products.price})`, filters.minPrice));
  if (filters.maxPrice !== undefined)
    conditions.push(lte(sql`coalesce(${products.discountPrice}, ${products.price})`, filters.maxPrice));
  if (filters.inStock) conditions.push(gte(products.stock, 1));
  if (filters.minRating) conditions.push(gte(ratingSql, filters.minRating));
  if (filters.sort === "deals")
    conditions.push(sql`${products.discountPrice} is not null and ${products.discountPrice} < ${products.price}`);

  const where = and(...conditions);

  const orderBy =
    filters.sort === "price-asc"
      ? asc(sql`coalesce(${products.discountPrice}, ${products.price})`)
      : filters.sort === "price-desc"
        ? desc(sql`coalesce(${products.discountPrice}, ${products.price})`)
        : filters.sort === "best"
          ? desc(products.sold)
          : filters.sort === "rating"
            ? desc(ratingSql)
            : desc(products.createdAt);

  const [items, totalRow] = await Promise.all([
    db
      .select(productCardSelect)
      .from(products)
      .where(where)
      .orderBy(orderBy)
      .limit(pageSize)
      .offset((page - 1) * pageSize),
    db.select({ count: sql<number>`count(*)::int` }).from(products).where(where),
  ]);

  return { items, total: totalRow[0]?.count || 0, page, pageSize };
}

export async function getActiveCategories() {
  return db.select().from(categories).where(eq(categories.status, "active")).orderBy(categories.name);
}
