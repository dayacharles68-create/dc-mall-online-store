import "server-only";
import { randomBytes } from "crypto";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";

const COOKIE_NAME = "dcm_session";
const SESSION_DAYS = 30;

export type SessionUser = {
  id: number;
  name: string;
  email: string;
  phone: string;
  role: string;
  address: string | null;
  city: string | null;
  region: string | null;
  status: string;
};

export async function createSession(userId: number, remember = true) {
  const token = randomBytes(32).toString("hex");
  const days = remember ? SESSION_DAYS : 1;
  const expiresAt = new Date(Date.now() + days * 24 * 60 * 60 * 1000);
  await db.insert(sessions).values({ token, userId, expiresAt });
  const store = await cookies();
  store.set(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: expiresAt,
  });
}

export async function getSessionUser(): Promise<SessionUser | null> {
  const store = await cookies();
  const token = store.get(COOKIE_NAME)?.value;
  if (!token) return null;
  const rows = await db
    .select({
      id: users.id,
      name: users.name,
      email: users.email,
      phone: users.phone,
      role: users.role,
      address: users.address,
      city: users.city,
      region: users.region,
      status: users.status,
      expiresAt: sessions.expiresAt,
    })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(eq(sessions.token, token))
    .limit(1);
  const row = rows[0];
  if (!row) return null;
  if (row.expiresAt < new Date() || row.status !== "active") {
    await db.delete(sessions).where(eq(sessions.token, token));
    return null;
  }
  const { expiresAt: _e, ...user } = row;
  return user;
}

export async function destroySession() {
  const store = await cookies();
  const token = store.get(COOKIE_NAME)?.value;
  if (token) {
    await db.delete(sessions).where(eq(sessions.token, token));
  }
  store.delete(COOKIE_NAME);
}

export async function requireUser(next?: string): Promise<SessionUser> {
  const user = await getSessionUser();
  if (!user) redirect(`/login${next ? `?next=${encodeURIComponent(next)}` : ""}`);
  return user;
}

export async function requireAdmin(): Promise<SessionUser> {
  const user = await getSessionUser();
  if (!user || user.role !== "admin") redirect("/admin/login");
  return user;
}

export async function findUserByIdentifier(identifier: string) {
  const clean = identifier.trim().toLowerCase();
  const byEmail = await db.select().from(users).where(eq(users.email, clean)).limit(1);
  if (byEmail[0]) return byEmail[0];
  const byPhone = await db
    .select()
    .from(users)
    .where(and(eq(users.phone, identifier.trim())))
    .limit(1);
  return byPhone[0] ?? null;
}
