import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { orderItems, orders, orderTracking, payments, products } from "@/db/schema";
import { notifyUser } from "@/lib/notify";

/**
 * Marks an order as paid after a REAL confirmation from the payment provider
 * (Paystack verify API / webhook). Idempotent.
 */
export async function confirmPaidOrder(orderId: number, transactionId: string, method: string) {
  const [order] = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
  if (!order || order.paymentStatus === "paid") return order;

  await db
    .update(payments)
    .set({ paymentStatus: "paid", transactionId, paymentMethod: method, updatedAt: new Date() })
    .where(eq(payments.orderId, orderId));
  await db
    .update(orders)
    .set({
      paymentStatus: "paid",
      orderStatus: order.orderStatus === "placed" ? "processing" : order.orderStatus,
      updatedAt: new Date(),
    })
    .where(eq(orders.id, orderId));

  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
  for (const it of items) {
    if (it.productId)
      await db
        .update(products)
        .set({ sold: sql`${products.sold} + ${it.quantity}` })
        .where(eq(products.id, it.productId));
  }
  await db.insert(orderTracking).values({
    orderId,
    status: "payment_confirmed",
    description: `Payment confirmed by payment provider. Transaction ID: ${transactionId}`,
  });
  if (order.orderStatus === "placed")
    await db.insert(orderTracking).values({
      orderId,
      status: "processing",
      description: "Your order has moved to processing.",
    });
  await notifyUser(
    order.userId,
    "Payment confirmed",
    `Payment for order ${order.orderNumber} has been confirmed. Your order is now being processed.`,
    order.deliveryEmail
  );
  return order;
}
