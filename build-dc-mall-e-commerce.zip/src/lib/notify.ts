import { db } from "@/db";
import { notifications } from "@/db/schema";

/**
 * Sends an email if an email provider is configured (RESEND_API_KEY).
 * Structured so SMS/WhatsApp providers can be added later behind the same API.
 */
export async function sendEmail(to: string, subject: string, html: string) {
  const key = process.env.RESEND_API_KEY;
  if (!key) return; // no email provider configured — skip silently
  try {
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: process.env.EMAIL_FROM || "DC MALL <noreply@dcmall.com.gh>",
        to,
        subject,
        html,
      }),
    });
  } catch (err) {
    console.error("Email send failed:", err);
  }
}

export async function notifyUser(
  userId: number,
  title: string,
  message: string,
  email?: string | null
) {
  try {
    await db.insert(notifications).values({ userId, title, message });
    if (email) {
      await sendEmail(
        email,
        `DC MALL — ${title}`,
        `<div style="font-family:sans-serif"><h2>DC MALL</h2><p>${message}</p><p style="color:#64748b;font-size:12px">Your Trusted Online Shopping Mall</p></div>`
      );
    }
  } catch (err) {
    console.error("Notification failed:", err);
  }
}
