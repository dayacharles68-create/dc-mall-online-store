import { db } from "@/db";
import { settings } from "@/db/schema";

export const DEFAULT_SETTINGS: Record<string, string> = {
  mall_name: "DC MALL",
  tagline: "Your Trusted Online Shopping Mall",
  contact_phone: "+233 54 531 5419",
  contact_email: "support@dcmall.com.gh",
  business_address: "Accra, Ghana",
  payment_number: "+233 54 531 5419",
  payment_account_name: "DC MALL",
  currency: "GHS",
  delivery_fee_default: "45",
  delivery_fee_accra: "25",
  low_stock_threshold: "5",
  order_prefix: "DCM",
  notify_email_enabled: "1",
};

export type MallSettings = Record<string, string>;

export async function getSettings(): Promise<MallSettings> {
  try {
    const rows = await db.select().from(settings);
    const map: MallSettings = { ...DEFAULT_SETTINGS };
    for (const row of rows) map[row.key] = row.value;
    return map;
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export function deliveryFeeFor(region: string, s: MallSettings): number {
  if (region === "Greater Accra") return Number(s.delivery_fee_accra) || 25;
  return Number(s.delivery_fee_default) || 45;
}
