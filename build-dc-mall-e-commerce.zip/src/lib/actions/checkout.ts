"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { and, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { cartItems, orders, orderItems, orderTracking, payments, productImages, products } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { notifyUser } from "@/lib/notify";
import { deliveryFeeFor, getSettings } from "@/lib/settings";
import { effectivePrice, GHANA_REGIONS } from "@/lib/utils";
import type { FormState } from "./auth";

async function generateOrderNumber(prefix: string): Promise<string> {
  const now = new Date();
  const ymd = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}${String(
    now.getDate()
  ).padStart(2, "0")}`;
  const dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const [row] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(orders)
    .where(gte(orders.createdAt, dayStart));
  const seq = (row?.count || 0) + 1 + Math.floor(Math.random() * 3);
  return `${prefix}-${ymd}-${String(seq).padStart(4, "0")}`;
}

export async function placeOrderAction(_prev: FormState, formData: FormData): Promise<FormState> {
  const user = await getSessionUser();
  if (!user) redirect("/login?next=/checkout");

  const name = String(formData.get("name") || "").trim();
  const phone = String(formData.get("phone") || "").trim();
  const email = String(formData.get("email") || "").trim().toLowerCase();
  const address = String(formData.get("address") || "").trim();
  const city = String(formData.get("city") || "").trim();
  const region = String(formData.get("region") || "").trim();
  const instructions = String(formData.get("instructions") || "").trim() || null;

  if (name.length < 2) return { error: "Please enter the recipient's full name." };
  if (!/^\+?[0-9 ()-]{9,16}$/.test(phone)) return { error: "Please enter a valid delivery phone number." };
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { error: "Please enter a valid email address." };
  if (address.length < 5) return { error: "Please enter a complete delivery address." };
  if (!city) return { error: "Please enter your town/city." };
  if (!GHANA_REGIONS.includes(region)) return { error: "Please select a valid region." };

  const items = await db
    .select({
      cartId: cartItems.id,
      quantity: cartItems.quantity,
      product: products,
    })
    .from(cartItems)
    .innerJoin(products, eq(cartItems.productId, products.id))
    .where(eq(cartItems.userId, user.id));

  if (items.length === 0) return { error: "Your cart is empty." };

  for (const it of items) {
    if (it.product.status !== "active")
      return { error: `"${it.product.name}" is no longer available. Please remove it from your cart.` };
    if (it.product.stock < it.quantity)
      return {
        error: `Insufficient stock for "${it.product.name}". Only ${it.product.stock} left. Please adjust the quantity.`,
      };
  }

  const settings = await getSettings();
  const subtotal = items.reduce((s, it) => s + effectivePrice(it.product) * it.quantity, 0);
  const deliveryFee = deliveryFeeFor(region, settings);
  const total = Math.round((subtotal + deliveryFee) * 100) / 100;
  const orderNumber = await generateOrderNumber(settings.order_prefix || "DCM");

  let orderId = 0;
  try {
    await db.transaction(async (tx) => {
      // Reserve stock atomically — prevents overselling
      for (const it of items) {
        const updated = await tx
          .update(products)
          .set({ stock: sql`${products.stock} - ${it.quantity}`, updatedAt: new Date() })
          .where(and(eq(products.id, it.product.id), gte(products.stock, it.quantity)))
          .returning({ id: products.id });
        if (updated.length === 0) throw new Error(`STOCK:${it.product.name}`);
      }

      const [order] = await tx
        .insert(orders)
        .values({
          orderNumber,
          userId: user.id,
          subtotal,
          deliveryFee,
          total,
          paymentStatus: "pending",
          orderStatus: "placed",
          deliveryName: name,
          deliveryPhone: phone,
          deliveryEmail: email,
          deliveryAddress: address,
          city,
          region,
          instructions,
        })
        .returning({ id: orders.id });
      orderId = order.id;

      for (const it of items) {
        const [img] = await tx
          .select({ url: productImages.imageUrl })
          .from(productImages)
          .where(eq(productImages.productId, it.product.id))
          .orderBy(productImages.sortOrder)
          .limit(1);
        await tx.insert(orderItems).values({
          orderId,
          productId: it.product.id,
          productName: it.product.name,
          productImage: img?.url || null,
          quantity: it.quantity,
          price: effectivePrice(it.product),
        });
      }

      await tx.insert(orderTracking).values({
        orderId,
        status: "placed",
        description: "Your order has been received by DC MALL.",
      });
      await tx.insert(payments).values({
        orderId,
        amount: total,
        paymentMethod: "momo",
        paymentStatus: "pending",
      });
      await tx.delete(cartItems).where(eq(cartItems.userId, user.id));
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "";
    if (msg.startsWith("STOCK:"))
      return { error: `Insufficient stock for "${msg.slice(6)}". Please adjust your cart.` };
    console.error("Order placement failed:", err);
    return { error: "We could not place your order right now. Please try again." };
  }

  await notifyUser(
    user.id,
    "Order received",
    `Your DC MALL order ${orderNumber} has been received. Total: GHS ${total.toFixed(2)}. Please complete payment to begin processing.`,
    email
  );

  revalidatePath("/", "layout");
  redirect(`/pay/${orderNumber}`);
}

export async function submitPaymentReferenceAction(
  _prev: FormState,
  formData: FormData
): Promise<FormState> {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const orderId = Number(formData.get("orderId"));
  const reference = String(formData.get("reference") || "").trim();
  if (reference.length < 4)
    return { error: "Please enter the MoMo transaction ID / reference from your payment receipt." };

  const [order] = await db
    .select()
    .from(orders)
    .where(and(eq(orders.id, orderId), eq(orders.userId, user.id)))
    .limit(1);
  if (!order) return { error: "Order not found." };
  if (order.paymentStatus === "paid") return { error: "This order has already been paid." };

  await db
    .update(payments)
    .set({ paymentReference: reference, paymentStatus: "processing", paymentMethod: "momo_manual", updatedAt: new Date() })
    .where(eq(payments.orderId, orderId));
  await db
    .update(orders)
    .set({ paymentStatus: "processing", updatedAt: new Date() })
    .where(eq(orders.id, orderId));
  await db.insert(orderTracking).values({
    orderId,
    status: "payment_processing",
    description: `Payment reference submitted (${reference}). Awaiting verification by DC MALL.`,
  });
  await notifyUser(
    user.id,
    "Payment reference received",
    `We received your payment reference for order ${order.orderNumber}. Our team will verify it shortly.`,
    order.deliveryEmail
  );

  revalidatePath("/", "layout");
  return {
    success:
      "Thank you! Your payment reference has been submitted. DC MALL will verify the transaction and confirm your payment shortly.",
  };
}
