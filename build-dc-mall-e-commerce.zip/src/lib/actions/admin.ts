"use server";

import { randomBytes } from "crypto";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  auditLogs,
  categories,
  orders,
  orderItems,
  orderTracking,
  payments,
  productImages,
  products,
  reviews,
  sessions,
  settings,
  users,
} from "@/db/schema";
import { createSession, requireAdmin, type SessionUser } from "@/lib/auth";
import { notifyUser } from "@/lib/notify";
import { hashPassword } from "@/lib/password";
import { ORDER_STATUS_LABELS, slugify } from "@/lib/utils";
import type { FormState } from "./auth";

async function audit(admin: SessionUser, action: string, details: string) {
  await db.insert(auditLogs).values({ adminId: admin.id, adminName: admin.name, action, details });
}

function revalidateAll() {
  revalidatePath("/", "layout");
}

/* ---------------- First admin setup ---------------- */

export async function createFirstAdminAction(_prev: FormState, formData: FormData): Promise<FormState> {
  const [row] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(users)
    .where(eq(users.role, "admin"));
  if ((row?.count || 0) > 0)
    return { error: "An administrator account already exists. Please log in instead." };

  const setupKey = process.env.ADMIN_SETUP_KEY;
  if (setupKey && String(formData.get("setupKey") || "") !== setupKey)
    return { error: "Invalid setup key. Check the ADMIN_SETUP_KEY environment variable." };

  const name = String(formData.get("name") || "").trim();
  const email = String(formData.get("email") || "").trim().toLowerCase();
  const phone = String(formData.get("phone") || "").trim() || "+233 54 531 5419";
  const password = String(formData.get("password") || "");
  if (name.length < 2) return { error: "Please enter the administrator's name." };
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { error: "Please enter a valid email." };
  if (password.length < 10)
    return { error: "Administrator password must be at least 10 characters." };

  const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
  if (existing[0]) return { error: "A user with this email already exists." };

  const [admin] = await db
    .insert(users)
    .values({ name, email, phone, passwordHash: hashPassword(password), role: "admin" })
    .returning({ id: users.id });
  await db.insert(auditLogs).values({
    adminId: admin.id,
    adminName: name,
    action: "admin_setup",
    details: "Initial administrator account created",
  });
  await createSession(admin.id, true);
  redirect("/admin");
}

/* ---------------- Products ---------------- */

export async function saveProductAction(_prev: FormState, formData: FormData): Promise<FormState> {
  const admin = await requireAdmin();
  const id = Number(formData.get("id")) || 0;
  const name = String(formData.get("name") || "").trim();
  const description = String(formData.get("description") || "").trim();
  const price = Number(formData.get("price"));
  const discountRaw = String(formData.get("discountPrice") || "").trim();
  const discountPrice = discountRaw ? Number(discountRaw) : null;
  const categoryId = Number(formData.get("categoryId")) || null;
  const brand = String(formData.get("brand") || "").trim() || null;
  const sku = String(formData.get("sku") || "").trim() || null;
  const stock = Math.max(0, Number(formData.get("stock")) || 0);
  const status = String(formData.get("status") || "active");
  const specifications = String(formData.get("specifications") || "").trim() || null;
  const seoTitle = String(formData.get("seoTitle") || "").trim() || null;
  const seoDescription = String(formData.get("seoDescription") || "").trim() || null;
  const imageUrls = String(formData.get("images") || "")
    .split("\n")
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 8);

  if (name.length < 2) return { error: "Product name is required." };
  if (!Number.isFinite(price) || price <= 0) return { error: "Please enter a valid price." };
  if (discountPrice !== null && (!Number.isFinite(discountPrice) || discountPrice <= 0 || discountPrice >= price))
    return { error: "Discount price must be lower than the regular price." };
  if (!["active", "inactive", "out_of_stock", "draft"].includes(status))
    return { error: "Invalid product status." };

  let slug = slugify(name);
  const clash = await db
    .select({ id: products.id })
    .from(products)
    .where(eq(products.slug, slug))
    .limit(1);
  if (clash[0] && clash[0].id !== id) slug = `${slug}-${randomBytes(3).toString("hex")}`;

  let productId = id;
  if (id) {
    await db
      .update(products)
      .set({
        name, slug, description, price, discountPrice, categoryId, brand, sku, stock, status,
        specifications, seoTitle, seoDescription, updatedAt: new Date(),
      })
      .where(eq(products.id, id));
    await db.delete(productImages).where(eq(productImages.productId, id));
    await audit(admin, "product_edited", `Edited product #${id} — ${name}`);
  } else {
    const [p] = await db
      .insert(products)
      .values({
        name, slug, description, price, discountPrice, categoryId, brand, sku, stock, status,
        specifications, seoTitle, seoDescription,
      })
      .returning({ id: products.id });
    productId = p.id;
    await audit(admin, "product_added", `Added product #${productId} — ${name}`);
  }
  if (imageUrls.length) {
    await db.insert(productImages).values(
      imageUrls.map((url, i) => ({ productId, imageUrl: url, sortOrder: i }))
    );
  }
  revalidateAll();
  redirect("/admin/products?saved=1");
}

export async function deleteProductAction(formData: FormData) {
  const admin = await requireAdmin();
  const id = Number(formData.get("id"));
  const [p] = await db.select({ name: products.name }).from(products).where(eq(products.id, id)).limit(1);
  await db.delete(products).where(eq(products.id, id));
  await audit(admin, "product_deleted", `Deleted product #${id} — ${p?.name || "unknown"}`);
  revalidateAll();
  redirect("/admin/products?deleted=1");
}

export async function updateStockAction(formData: FormData) {
  const admin = await requireAdmin();
  const id = Number(formData.get("id"));
  const stock = Math.max(0, Number(formData.get("stock")) || 0);
  await db.update(products).set({ stock, updatedAt: new Date() }).where(eq(products.id, id));
  await audit(admin, "stock_updated", `Set stock of product #${id} to ${stock}`);
  revalidateAll();
  redirect("/admin/inventory?saved=1");
}

/* ---------------- Categories ---------------- */

export async function saveCategoryAction(_prev: FormState, formData: FormData): Promise<FormState> {
  const admin = await requireAdmin();
  const id = Number(formData.get("id")) || 0;
  const name = String(formData.get("name") || "").trim();
  const description = String(formData.get("description") || "").trim() || null;
  const image = String(formData.get("image") || "").trim() || null;
  const status = formData.get("status") === "inactive" ? "inactive" : "active";
  if (name.length < 2) return { error: "Category name is required." };

  let slug = slugify(name);
  const clash = await db.select({ id: categories.id }).from(categories).where(eq(categories.slug, slug)).limit(1);
  if (clash[0] && clash[0].id !== id) slug = `${slug}-${randomBytes(2).toString("hex")}`;

  if (id) {
    await db.update(categories).set({ name, slug, description, image, status }).where(eq(categories.id, id));
    await audit(admin, "category_edited", `Edited category #${id} — ${name}`);
  } else {
    await db.insert(categories).values({ name, slug, description, image, status });
    await audit(admin, "category_added", `Added category — ${name}`);
  }
  revalidateAll();
  redirect("/admin/categories?saved=1");
}

export async function deleteCategoryAction(formData: FormData) {
  const admin = await requireAdmin();
  const id = Number(formData.get("id"));
  const [c] = await db.select({ name: categories.name }).from(categories).where(eq(categories.id, id)).limit(1);
  await db.delete(categories).where(eq(categories.id, id));
  await audit(admin, "category_deleted", `Deleted category #${id} — ${c?.name || ""}`);
  revalidateAll();
  redirect("/admin/categories?deleted=1");
}

/* ---------------- Orders ---------------- */

export async function updateOrderStatusAction(formData: FormData) {
  const admin = await requireAdmin();
  const orderId = Number(formData.get("orderId"));
  const status = String(formData.get("status") || "");
  const trackingNumber = String(formData.get("trackingNumber") || "").trim() || null;
  const deliveryNotes = String(formData.get("deliveryNotes") || "").trim() || null;

  const valid = ["placed", "processing", "packed", "shipped", "out_for_delivery", "delivered", "cancelled", "refunded"];
  if (!valid.includes(status)) redirect(`/admin/orders/${orderId}?error=invalid-status`);

  const [order] = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
  if (!order) redirect("/admin/orders");

  const updates: Record<string, unknown> = { orderStatus: status, updatedAt: new Date() };
  if (trackingNumber) updates.trackingNumber = trackingNumber;
  if (deliveryNotes) updates.deliveryNotes = deliveryNotes;

  // Cancelling restores reserved stock (once)
  if (status === "cancelled" && order.orderStatus !== "cancelled") {
    const items = await db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
    for (const it of items) {
      if (it.productId)
        await db
          .update(products)
          .set({ stock: sql`${products.stock} + ${it.quantity}` })
          .where(eq(products.id, it.productId));
    }
    if (order.paymentStatus === "pending" || order.paymentStatus === "processing")
      updates.paymentStatus = "cancelled";
  }
  if (status === "refunded") {
    updates.paymentStatus = "refunded";
    await db
      .update(payments)
      .set({ paymentStatus: "refunded", updatedAt: new Date() })
      .where(eq(payments.orderId, orderId));
  }

  await db.update(orders).set(updates).where(eq(orders.id, orderId));
  await db.insert(orderTracking).values({
    orderId,
    status,
    description:
      deliveryNotes ||
      `Order status updated to ${ORDER_STATUS_LABELS[status] || status} by DC MALL.` +
        (trackingNumber ? ` Tracking number: ${trackingNumber}` : ""),
  });

  const messages: Record<string, string> = {
    processing: `Your DC MALL order ${order.orderNumber} is now being processed.`,
    packed: `Your DC MALL order ${order.orderNumber} has been packed.`,
    shipped: `Your DC MALL order ${order.orderNumber} has been shipped.`,
    out_for_delivery: `Your DC MALL order ${order.orderNumber} is out for delivery.`,
    delivered: `Your DC MALL order ${order.orderNumber} has been delivered. Thank you for shopping with us!`,
    cancelled: `Your DC MALL order ${order.orderNumber} has been cancelled.`,
    refunded: `Your DC MALL order ${order.orderNumber} has been refunded.`,
  };
  if (messages[status])
    await notifyUser(order.userId, ORDER_STATUS_LABELS[status] || "Order update", messages[status], order.deliveryEmail);

  await audit(admin, "order_status_changed", `Order ${order.orderNumber} → ${status}`);
  revalidateAll();
  redirect(`/admin/orders/${orderId}?saved=1`);
}

export async function verifyPaymentAction(formData: FormData) {
  const admin = await requireAdmin();
  const orderId = Number(formData.get("orderId"));
  const decision = String(formData.get("decision") || "");
  let transactionId = String(formData.get("transactionId") || "").trim();

  const [order] = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
  if (!order) redirect("/admin/orders");
  if (order.paymentStatus === "paid") redirect(`/admin/orders/${orderId}?error=already-paid`);

  if (decision === "approve") {
    if (!transactionId) transactionId = `TXN-${randomBytes(5).toString("hex").toUpperCase()}`;
    await db
      .update(payments)
      .set({ paymentStatus: "paid", transactionId, updatedAt: new Date() })
      .where(eq(payments.orderId, orderId));
    await db
      .update(orders)
      .set({
        paymentStatus: "paid",
        orderStatus: order.orderStatus === "placed" ? "processing" : order.orderStatus,
        updatedAt: new Date(),
      })
      .where(eq(orders.id, orderId));
    // Record confirmed sales against products
    const items = await db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
    for (const it of items) {
      if (it.productId)
        await db
          .update(products)
          .set({ sold: sql`${products.sold} + ${it.quantity}` })
          .where(eq(products.id, it.productId));
    }
    await db.insert(orderTracking).values({
      orderId,
      status: "payment_confirmed",
      description: `Payment confirmed by DC MALL. Transaction ID: ${transactionId}`,
    });
    if (order.orderStatus === "placed")
      await db.insert(orderTracking).values({
        orderId,
        status: "processing",
        description: "Your order has moved to processing.",
      });
    await notifyUser(
      order.userId,
      "Payment confirmed",
      `Payment for order ${order.orderNumber} has been confirmed. Your order is now being processed.`,
      order.deliveryEmail
    );
    await audit(admin, "payment_verified", `Payment approved for order ${order.orderNumber} (${transactionId})`);
  } else {
    await db
      .update(payments)
      .set({ paymentStatus: "failed", updatedAt: new Date() })
      .where(eq(payments.orderId, orderId));
    await db.update(orders).set({ paymentStatus: "failed", updatedAt: new Date() }).where(eq(orders.id, orderId));
    await db.insert(orderTracking).values({
      orderId,
      status: "payment_failed",
      description: "Payment could not be verified. Please contact DC MALL support or retry payment.",
    });
    await notifyUser(
      order.userId,
      "Payment verification failed",
      `We could not verify the payment for order ${order.orderNumber}. Please check the reference and try again, or contact support.`,
      order.deliveryEmail
    );
    await audit(admin, "payment_rejected", `Payment rejected for order ${order.orderNumber}`);
  }
  revalidateAll();
  redirect(`/admin/orders/${orderId}?saved=1`);
}

/* ---------------- Customers ---------------- */

export async function toggleCustomerStatusAction(formData: FormData) {
  const admin = await requireAdmin();
  const id = Number(formData.get("id"));
  const [customer] = await db.select().from(users).where(eq(users.id, id)).limit(1);
  if (!customer || customer.role === "admin") redirect("/admin/customers");
  const newStatus = customer.status === "active" ? "disabled" : "active";
  await db.update(users).set({ status: newStatus }).where(eq(users.id, id));
  if (newStatus === "disabled") await db.delete(sessions).where(eq(sessions.userId, id));
  await audit(admin, newStatus === "disabled" ? "customer_disabled" : "customer_reactivated", `Customer #${id} — ${customer.email}`);
  revalidateAll();
  redirect("/admin/customers?saved=1");
}

/* ---------------- Reviews ---------------- */

export async function moderateReviewAction(formData: FormData) {
  const admin = await requireAdmin();
  const id = Number(formData.get("id"));
  const action = String(formData.get("action") || "");
  if (action === "delete") {
    await db.delete(reviews).where(eq(reviews.id, id));
  } else {
    await db.update(reviews).set({ status: action === "hide" ? "hidden" : "visible" }).where(eq(reviews.id, id));
  }
  await audit(admin, "review_moderated", `Review #${id} — ${action}`);
  revalidateAll();
  redirect("/admin/reviews?saved=1");
}

/* ---------------- Settings ---------------- */

const SETTING_KEYS = [
  "mall_name", "tagline", "contact_phone", "contact_email", "business_address",
  "payment_number", "payment_account_name", "currency", "delivery_fee_default",
  "delivery_fee_accra", "low_stock_threshold", "order_prefix", "notify_email_enabled",
];

export async function saveSettingsAction(_prev: FormState, formData: FormData): Promise<FormState> {
  const admin = await requireAdmin();
  for (const key of SETTING_KEYS) {
    const value = formData.get(key);
    if (value === null) continue;
    await db
      .insert(settings)
      .values({ key, value: String(value) })
      .onConflictDoUpdate({ target: settings.key, set: { value: String(value) } });
  }
  await audit(admin, "settings_updated", "Store settings updated");
  revalidateAll();
  return { success: "Settings saved successfully." };
}

/* ---------------- Order tracking lookup (public, verified) ---------------- */

export async function trackOrderLookup(orderNumber: string, contact: string) {
  const cleanNumber = orderNumber.trim().toUpperCase();
  const cleanContact = contact.trim().toLowerCase();
  if (!cleanNumber || !cleanContact) return null;
  const [order] = await db.select().from(orders).where(eq(orders.orderNumber, cleanNumber)).limit(1);
  if (!order) return null;
  const phoneDigits = (s: string) => s.replace(/\D/g, "").slice(-9);
  const matches =
    order.deliveryEmail.toLowerCase() === cleanContact ||
    (phoneDigits(cleanContact).length >= 9 && phoneDigits(order.deliveryPhone) === phoneDigits(cleanContact));
  if (!matches) return null;
  const events = await db
    .select()
    .from(orderTracking)
    .where(eq(orderTracking.orderId, order.id))
    .orderBy(orderTracking.createdAt);
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));
  return { order, events, items };
}
