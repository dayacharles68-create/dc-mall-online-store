"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { cartItems, products } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";

export async function addToCartAction(formData: FormData) {
  const productId = Number(formData.get("productId"));
  const quantity = Math.max(1, Math.min(99, Number(formData.get("quantity")) || 1));
  const buyNow = formData.get("buyNow") === "1";
  const backTo = String(formData.get("backTo") || "/cart");

  const user = await getSessionUser();
  if (!user) redirect(`/login?next=${encodeURIComponent(backTo)}&msg=login-to-shop`);

  const [product] = await db.select().from(products).where(eq(products.id, productId)).limit(1);
  if (!product || product.status !== "active") redirect(`${backTo}?error=unavailable`);
  if (product.stock < 1) redirect(`${backTo}?error=out-of-stock`);

  const existing = await db
    .select()
    .from(cartItems)
    .where(and(eq(cartItems.userId, user.id), eq(cartItems.productId, productId)))
    .limit(1);

  const newQty = Math.min(product.stock, (existing[0]?.quantity || 0) + quantity);
  if (existing[0]) {
    await db.update(cartItems).set({ quantity: newQty }).where(eq(cartItems.id, existing[0].id));
  } else {
    await db.insert(cartItems).values({ userId: user.id, productId, quantity: newQty });
  }
  revalidatePath("/", "layout");
  redirect(buyNow ? "/checkout" : `${backTo}?added=1`);
}

export async function setCartQtyAction(formData: FormData) {
  const user = await getSessionUser();
  if (!user) redirect("/login?next=/cart");
  const itemId = Number(formData.get("itemId"));
  const qty = Number(formData.get("quantity"));

  const rows = await db
    .select({
      id: cartItems.id,
      quantity: cartItems.quantity,
      stock: products.stock,
    })
    .from(cartItems)
    .innerJoin(products, eq(cartItems.productId, products.id))
    .where(and(eq(cartItems.id, itemId), eq(cartItems.userId, user.id)))
    .limit(1);
  const item = rows[0];
  if (!item) redirect("/cart");

  if (qty <= 0) {
    await db.delete(cartItems).where(eq(cartItems.id, item.id));
  } else {
    await db
      .update(cartItems)
      .set({ quantity: Math.min(qty, Math.max(1, item.stock)) })
      .where(eq(cartItems.id, item.id));
  }
  revalidatePath("/", "layout");
  redirect("/cart");
}

export async function removeCartItemAction(formData: FormData) {
  const user = await getSessionUser();
  if (!user) redirect("/login?next=/cart");
  const itemId = Number(formData.get("itemId"));
  await db.delete(cartItems).where(and(eq(cartItems.id, itemId), eq(cartItems.userId, user.id)));
  revalidatePath("/", "layout");
  redirect("/cart");
}

export async function getCartCount(userId: number): Promise<number> {
  const rows = await db
    .select({ count: sql<number>`coalesce(sum(${cartItems.quantity}), 0)::int` })
    .from(cartItems)
    .where(eq(cartItems.userId, userId));
  return rows[0]?.count || 0;
}
