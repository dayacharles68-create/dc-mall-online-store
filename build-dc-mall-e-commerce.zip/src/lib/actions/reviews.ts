"use server";

import { revalidatePath } from "next/cache";
import { and, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { orderItems, orders, reviews } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import type { FormState } from "./auth";

export async function submitReviewAction(_prev: FormState, formData: FormData): Promise<FormState> {
  const user = await getSessionUser();
  if (!user) return { error: "Please log in to leave a review." };

  const productId = Number(formData.get("productId"));
  const rating = Number(formData.get("rating"));
  const text = String(formData.get("review") || "").trim();
  const slug = String(formData.get("slug") || "");

  if (!Number.isInteger(rating) || rating < 1 || rating > 5)
    return { error: "Please choose a star rating between 1 and 5." };
  if (text.length > 2000) return { error: "Review is too long (max 2000 characters)." };

  // Verified purchase = the customer has a paid or delivered order containing this product
  const purchased = await db
    .select({ id: orderItems.id })
    .from(orderItems)
    .innerJoin(orders, eq(orderItems.orderId, orders.id))
    .where(
      and(
        eq(orders.userId, user.id),
        eq(orderItems.productId, productId),
        inArray(orders.paymentStatus, ["paid", "refunded"])
      )
    )
    .limit(1);

  const verified = purchased.length > 0;
  if (!verified)
    return {
      error:
        "Only customers who have purchased this product (with confirmed payment) can leave a review.",
    };

  await db
    .insert(reviews)
    .values({ productId, userId: user.id, rating, review: text, verifiedPurchase: true })
    .onConflictDoUpdate({
      target: [reviews.productId, reviews.userId],
      set: { rating, review: text, verifiedPurchase: true, status: "visible", createdAt: sql`now()` },
    });

  revalidatePath(`/product/${slug}`);
  return { success: "Thank you! Your review has been published." };
}
