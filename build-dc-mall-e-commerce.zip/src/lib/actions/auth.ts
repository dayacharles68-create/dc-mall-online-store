"use server";

import { randomBytes } from "crypto";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { passwordResets, users } from "@/db/schema";
import { createSession, destroySession, findUserByIdentifier, getSessionUser } from "@/lib/auth";
import { sendEmail } from "@/lib/notify";
import { hashPassword, verifyPassword } from "@/lib/password";
import { rateLimit } from "@/lib/ratelimit";

export type FormState = { error?: string; success?: string } | null;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

async function clientIp() {
  const h = await headers();
  return h.get("x-forwarded-for")?.split(",")[0]?.trim() || "local";
}

export async function registerAction(_prev: FormState, formData: FormData): Promise<FormState> {
  const name = String(formData.get("name") || "").trim();
  const email = String(formData.get("email") || "").trim().toLowerCase();
  const phone = String(formData.get("phone") || "").trim();
  const password = String(formData.get("password") || "");
  const confirm = String(formData.get("confirm") || "");
  const address = String(formData.get("address") || "").trim() || null;
  const city = String(formData.get("city") || "").trim() || null;
  const region = String(formData.get("region") || "").trim() || null;
  const next = String(formData.get("next") || "/account");

  if (name.length < 2) return { error: "Please enter your full name." };
  if (!EMAIL_RE.test(email)) return { error: "Please enter a valid email address." };
  if (!/^\+?[0-9 ()-]{9,16}$/.test(phone)) return { error: "Please enter a valid phone number." };
  if (password.length < 8) return { error: "Password must be at least 8 characters." };
  if (password !== confirm) return { error: "Passwords do not match." };

  if (!rateLimit(`register:${await clientIp()}`, 10, 60 * 60 * 1000))
    return { error: "Too many attempts. Please try again later." };

  const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
  if (existing[0]) return { error: "An account with this email already exists. Please log in." };

  const [user] = await db
    .insert(users)
    .values({
      name,
      email,
      phone,
      passwordHash: hashPassword(password),
      role: "customer", // admin role can never be obtained through public registration
      address,
      city,
      region,
    })
    .returning({ id: users.id });

  await createSession(user.id, true);
  redirect(next.startsWith("/") ? next : "/account");
}

export async function loginAction(_prev: FormState, formData: FormData): Promise<FormState> {
  const identifier = String(formData.get("identifier") || "").trim();
  const password = String(formData.get("password") || "");
  const remember = formData.get("remember") === "on";
  const next = String(formData.get("next") || "");
  const adminPortal = formData.get("portal") === "admin";

  if (!identifier || !password) return { error: "Please enter your email/phone and password." };
  if (!rateLimit(`login:${await clientIp()}:${identifier.toLowerCase()}`, 8, 15 * 60 * 1000))
    return { error: "Too many failed attempts. Please wait 15 minutes and try again." };

  const user = await findUserByIdentifier(identifier);
  if (!user || !verifyPassword(password, user.passwordHash))
    return { error: "Invalid credentials. Please check your details and try again." };
  if (user.status !== "active")
    return { error: "This account has been disabled. Please contact DC MALL support." };
  if (adminPortal && user.role !== "admin")
    return { error: "This account does not have administrator access." };

  await createSession(user.id, remember || adminPortal);
  if (user.role === "admin" && adminPortal) redirect("/admin");
  redirect(next.startsWith("/") ? next : user.role === "admin" ? "/admin" : "/account");
}

export async function logoutAction() {
  await destroySession();
  redirect("/");
}

export async function forgotPasswordAction(_prev: FormState, formData: FormData): Promise<FormState> {
  const email = String(formData.get("email") || "").trim().toLowerCase();
  if (!EMAIL_RE.test(email)) return { error: "Please enter a valid email address." };
  if (!rateLimit(`forgot:${await clientIp()}`, 5, 60 * 60 * 1000))
    return { error: "Too many requests. Please try again later." };

  const found = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (found[0]) {
    const token = randomBytes(32).toString("hex");
    await db.insert(passwordResets).values({
      token,
      userId: found[0].id,
      expiresAt: new Date(Date.now() + 60 * 60 * 1000),
    });
    const base = process.env.NEXT_PUBLIC_APP_URL || "";
    await sendEmail(
      email,
      "DC MALL — Reset your password",
      `<p>Click the link below to reset your DC MALL password (valid for 1 hour):</p><p><a href="${base}/reset-password/${token}">Reset Password</a></p>`
    );
  }
  return {
    success:
      "If an account exists for this email, a password reset link has been sent. Please check your inbox.",
  };
}

export async function resetPasswordAction(_prev: FormState, formData: FormData): Promise<FormState> {
  const token = String(formData.get("token") || "");
  const password = String(formData.get("password") || "");
  const confirm = String(formData.get("confirm") || "");
  if (password.length < 8) return { error: "Password must be at least 8 characters." };
  if (password !== confirm) return { error: "Passwords do not match." };

  const rows = await db.select().from(passwordResets).where(eq(passwordResets.token, token)).limit(1);
  const reset = rows[0];
  if (!reset || reset.used || reset.expiresAt < new Date())
    return { error: "This reset link is invalid or has expired. Please request a new one." };

  await db.update(users).set({ passwordHash: hashPassword(password) }).where(eq(users.id, reset.userId));
  await db.update(passwordResets).set({ used: true }).where(eq(passwordResets.token, token));
  return { success: "Your password has been reset. You can now log in with your new password." };
}

export async function updateProfileAction(_prev: FormState, formData: FormData): Promise<FormState> {
  const user = await getSessionUser();
  if (!user) return { error: "Your session has expired. Please log in again." };
  const name = String(formData.get("name") || "").trim();
  const phone = String(formData.get("phone") || "").trim();
  const address = String(formData.get("address") || "").trim() || null;
  const city = String(formData.get("city") || "").trim() || null;
  const region = String(formData.get("region") || "").trim() || null;
  if (name.length < 2) return { error: "Please enter your full name." };
  if (!/^\+?[0-9 ()-]{9,16}$/.test(phone)) return { error: "Please enter a valid phone number." };
  await db.update(users).set({ name, phone, address, city, region }).where(eq(users.id, user.id));
  return { success: "Profile updated successfully." };
}
